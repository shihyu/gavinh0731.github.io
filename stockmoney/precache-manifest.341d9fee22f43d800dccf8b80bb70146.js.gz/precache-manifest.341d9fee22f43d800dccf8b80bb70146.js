self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "20fab5c9acb1e4d6cd8f8d15f6fc92a9",
    "url": "/stockmoney/index.html"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json/.dummy"
  },
  {
    "revision": "3d7f842e1ab2cd23f8b6e86d835b64b9",
    "url": "/stockmoney/json/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json/basic_4season_cols.json"
  },
  {
    "revision": "76e8222a21c668830d34709eed9962f3",
    "url": "/stockmoney/json/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json/basic_asset_cols.json"
  },
  {
    "revision": "00a7f5d2792633da7b507e8f4e1aa9c1",
    "url": "/stockmoney/json/basic_cash.json"
  },
  {
    "revision": "858aae519e24fcff6fabac206522b979",
    "url": "/stockmoney/json/basic_cash_cols.json"
  },
  {
    "revision": "8cc7d43ccee18f9c86c0e3de413cf2c6",
    "url": "/stockmoney/json/basic_debt.json"
  },
  {
    "revision": "b6b02cc0e5412577bc453b83c6f4ee03",
    "url": "/stockmoney/json/basic_debt_cols.json"
  },
  {
    "revision": "95ccf4891c8e40ee52f47267da7a35bd",
    "url": "/stockmoney/json/basic_eps.json"
  },
  {
    "revision": "c0577d851fa66b398ad224bdebadaa51",
    "url": "/stockmoney/json/basic_eps_cols.json"
  },
  {
    "revision": "7363dbd86dcb6887cf0c5a28161afc76",
    "url": "/stockmoney/json/basic_gross.json"
  },
  {
    "revision": "a29e7548cc41edb2779248de0637f807",
    "url": "/stockmoney/json/basic_gross_cols.json"
  },
  {
    "revision": "ec5b881f9a803300e4116b947e088302",
    "url": "/stockmoney/json/basic_info.json"
  },
  {
    "revision": "4a01d4330b10e31c6048acfe2d9dde98",
    "url": "/stockmoney/json/basic_info_cols.json"
  },
  {
    "revision": "2de1af9108be2561be5aaafb09a980c1",
    "url": "/stockmoney/json/basic_net.json"
  },
  {
    "revision": "c2f69f6f29c13fc163e89e9dbeb6ee03",
    "url": "/stockmoney/json/basic_net_cols.json"
  },
  {
    "revision": "87e0cf328a8c48f9f0a6e7bc16f22fcc",
    "url": "/stockmoney/json/basic_noi.json"
  },
  {
    "revision": "890be2cdbc1433db838efd9357f15f3f",
    "url": "/stockmoney/json/basic_noi_cols.json"
  },
  {
    "revision": "5718f3e5ed001d9c6077a42f12d132ce",
    "url": "/stockmoney/json/basic_opm.json"
  },
  {
    "revision": "c17a26096e21bc416037e1c1146ace26",
    "url": "/stockmoney/json/basic_opm_cols.json"
  },
  {
    "revision": "4dbcafad29f02cdc6fe5de0604ff617c",
    "url": "/stockmoney/json/basic_opp.json"
  },
  {
    "revision": "f98e46c7ed0ada475a9cfafb50973de2",
    "url": "/stockmoney/json/basic_opp_cols.json"
  },
  {
    "revision": "02e7d0181af60add46589d1532ac0853",
    "url": "/stockmoney/json/basic_roe.json"
  },
  {
    "revision": "a1d0bf8c5ecc05dfd2dd12c6bd0f3e96",
    "url": "/stockmoney/json/basic_roe_cols.json"
  },
  {
    "revision": "3a2a56b1c9b8cba5c7ae6b1898b8982c",
    "url": "/stockmoney/json/basic_rvn.json"
  },
  {
    "revision": "59e854d5c197bb75573e9fdbbf4e738e",
    "url": "/stockmoney/json/basic_rvn_cols.json"
  },
  {
    "revision": "21a816ad539700d675e4075f02c4d526",
    "url": "/stockmoney/json/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json/basic_yearw_cols.json"
  },
  {
    "revision": "e6f6a1717adc6c6a89d4be6f4a6b0af3",
    "url": "/stockmoney/json/chip_borrow.json"
  },
  {
    "revision": "b9d898714914df8c330d1f25fd728bd4",
    "url": "/stockmoney/json/chip_borrow_cols.json"
  },
  {
    "revision": "33d5e7e29b25f54bee69938940f3e9b9",
    "url": "/stockmoney/json/chip_broker.json"
  },
  {
    "revision": "a07c8fc77597992396e367fa482d0b4b",
    "url": "/stockmoney/json/chip_director.json"
  },
  {
    "revision": "a3855cd3916138bb576eab6bf29daf45",
    "url": "/stockmoney/json/chip_director1.json"
  },
  {
    "revision": "9245b933efe32254018a0a6e9a6c8613",
    "url": "/stockmoney/json/chip_director1_cols.json"
  },
  {
    "revision": "a67dcb2fff8f8515b4a20d0af6391918",
    "url": "/stockmoney/json/chip_director3.json"
  },
  {
    "revision": "b856d752ee7572bba69b5bfefbe9e41b",
    "url": "/stockmoney/json/chip_director3_cols.json"
  },
  {
    "revision": "15a56fc4a9126dcda797ccea8f2058d5",
    "url": "/stockmoney/json/chip_director5.json"
  },
  {
    "revision": "825ba91683006403a96e4ead7ebc2e2c",
    "url": "/stockmoney/json/chip_director5_cols.json"
  },
  {
    "revision": "9bbbf6600d4c03482470ae7a8ed48118",
    "url": "/stockmoney/json/chip_director_cols.json"
  },
  {
    "revision": "21efebab2d58871efab50981d5997165",
    "url": "/stockmoney/json/chip_foreign.json"
  },
  {
    "revision": "1f66416e66912403af00c4d2366c2741",
    "url": "/stockmoney/json/chip_foreign_cols.json"
  },
  {
    "revision": "104a141d9c19308b76c02efbe5a376fd",
    "url": "/stockmoney/json/chip_holder.json"
  },
  {
    "revision": "672717b58db691e5c491065fd3720da4",
    "url": "/stockmoney/json/chip_holder_cols.json"
  },
  {
    "revision": "57841fd216c51b1e85100720f525c3ca",
    "url": "/stockmoney/json/chip_legal.json"
  },
  {
    "revision": "60a82514c04d8b46e234b6c3b7db8a4c",
    "url": "/stockmoney/json/chip_legal_cols.json"
  },
  {
    "revision": "5ec652d12573fdec0326502bc5a796f4",
    "url": "/stockmoney/json/chip_loan.json"
  },
  {
    "revision": "f9dc3e02b8b829e17677de08ed985401",
    "url": "/stockmoney/json/chip_loan_cols.json"
  },
  {
    "revision": "c4a78193affe9beab5e0871c1ee8f74c",
    "url": "/stockmoney/json/chip_trust.json"
  },
  {
    "revision": "0453c094ec1578d8b609550d9e477938",
    "url": "/stockmoney/json/chip_trust_cols.json"
  },
  {
    "revision": "34e5a720479ea354aff686d6cd0c9cb2",
    "url": "/stockmoney/json/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json/deal_pct_cols.json"
  },
  {
    "revision": "6b259d9ad6b1bb81c3e679a8fb3424db",
    "url": "/stockmoney/json/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json/deal_vol_cols.json"
  },
  {
    "revision": "e35f7b837b848ff7079210f4200ebbe9",
    "url": "/stockmoney/json/dividend_cont.json"
  },
  {
    "revision": "3e8dc99836816cdedc952a126db1fa79",
    "url": "/stockmoney/json/dividend_cont_cols.json"
  },
  {
    "revision": "6940531470a8b82185a50aa2dfa51562",
    "url": "/stockmoney/json/dividend_stat.json"
  },
  {
    "revision": "118ff1437c382a3b5334d359b0246dca",
    "url": "/stockmoney/json/dividend_stat_2015.json"
  },
  {
    "revision": "008c79d526737b517a9a742b04502b20",
    "url": "/stockmoney/json/dividend_stat_2015_cols.json"
  },
  {
    "revision": "928cce3982f1bf072341635b9ec0b8a5",
    "url": "/stockmoney/json/dividend_stat_2016.json"
  },
  {
    "revision": "ec5a0a94673998b0bb4a63db93d08f4a",
    "url": "/stockmoney/json/dividend_stat_2016_cols.json"
  },
  {
    "revision": "525c7e1a9090b516e0f62457f7c3c6e9",
    "url": "/stockmoney/json/dividend_stat_2017.json"
  },
  {
    "revision": "e37fc91cd72912b24657ed675d9f1c8b",
    "url": "/stockmoney/json/dividend_stat_2017_cols.json"
  },
  {
    "revision": "f49e2f1e42805294e66d14f54f494128",
    "url": "/stockmoney/json/dividend_stat_2018.json"
  },
  {
    "revision": "38050d84b8d337ce366fb397e8e206f7",
    "url": "/stockmoney/json/dividend_stat_2018_cols.json"
  },
  {
    "revision": "8078e9b4e16b00bed2c64b4990b00eb0",
    "url": "/stockmoney/json/dividend_stat_2019.json"
  },
  {
    "revision": "7ec66cdc30aa0d150bc4f797bdc131c4",
    "url": "/stockmoney/json/dividend_stat_2019_cols.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json/dividend_stat_cols.json"
  },
  {
    "revision": "96331f71031a7e1731637d02f0111c21",
    "url": "/stockmoney/json/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json/dividend_yield_cols.json"
  },
  {
    "revision": "fb77ed466b0a6eba7d5ec5196693160f",
    "url": "/stockmoney/json/dk_dies.json"
  },
  {
    "revision": "0842de8223abec6d0d02135b89168710",
    "url": "/stockmoney/json/dk_dies_cols.json"
  },
  {
    "revision": "8ee5cbd92f7cbd6af5bddef886567285",
    "url": "/stockmoney/json/export_director.json"
  },
  {
    "revision": "89100efeca7bfb4d95efdab07df62a48",
    "url": "/stockmoney/json/export_director_cols.json"
  },
  {
    "revision": "f2d0156d47c4c32fc479e15c4b423864",
    "url": "/stockmoney/json/export_incomerate.json"
  },
  {
    "revision": "8a782513b99c4e31cf07aca4745c38e4",
    "url": "/stockmoney/json/export_incomerate_cols.json"
  },
  {
    "revision": "58b2817fc4305ccbf421ed3e49aa1e23",
    "url": "/stockmoney/json/export_stockfish.json"
  },
  {
    "revision": "24c365c317bd950273a6bbe79b14d791",
    "url": "/stockmoney/json/export_stockfish_cols.json"
  },
  {
    "revision": "d8870586865663c92d740351aba55c50",
    "url": "/stockmoney/json/export_triplerate.json"
  },
  {
    "revision": "29e0c2731cf0823c503af4580b581346",
    "url": "/stockmoney/json/export_triplerate_cols.json"
  },
  {
    "revision": "e3806a94c6071f6d00887b0ea1a1aded",
    "url": "/stockmoney/json/export_water.json"
  },
  {
    "revision": "1743dc326779ed0d0955118930c2fdc1",
    "url": "/stockmoney/json/export_water_cols.json"
  },
  {
    "revision": "ed1dc6ffd45d72e443e309574512acf6",
    "url": "/stockmoney/json/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json/export_yield_cols.json"
  },
  {
    "revision": "354e8787490f158232ad6adb887be3e0",
    "url": "/stockmoney/json/my_basic.json"
  },
  {
    "revision": "295c360491ab2ad27aa285e780073787",
    "url": "/stockmoney/json/my_basic_cols.json"
  },
  {
    "revision": "9585c78f1f1abfaad7b6184779f3b080",
    "url": "/stockmoney/json/my_chip.json"
  },
  {
    "revision": "4591748299e5053668af84371363907d",
    "url": "/stockmoney/json/my_chip_cols.json"
  },
  {
    "revision": "f39093623b2d3728d75eab4c9dcda1d8",
    "url": "/stockmoney/json/my_eps.json"
  },
  {
    "revision": "87b98bb7ccff2628d43fe83db7362e93",
    "url": "/stockmoney/json/my_eps_cols.json"
  },
  {
    "revision": "fc5a4a0dd72a47928544fd39caf27688",
    "url": "/stockmoney/json/my_tech.json"
  },
  {
    "revision": "8a19cc05a24dcd177b9df5db81ec28b3",
    "url": "/stockmoney/json/my_tech_cols.json"
  },
  {
    "revision": "98be38b0821f33d5ca088a50785d7fb1",
    "url": "/stockmoney/json/price_dpct.json"
  },
  {
    "revision": "111c1063358cf2cce62d1c4c3cf2a601",
    "url": "/stockmoney/json/price_dpct_cols.json"
  },
  {
    "revision": "3e38e517e5842b8cd3e79d3d33459c76",
    "url": "/stockmoney/json/price_high.json"
  },
  {
    "revision": "8f986523f915cd6a9dae0cd5f54f5d7f",
    "url": "/stockmoney/json/price_high_cols.json"
  },
  {
    "revision": "e58c014e64523ac17f195ae55b74755e",
    "url": "/stockmoney/json/price_mpct.json"
  },
  {
    "revision": "19f8b091eacff631ac486f7a35596c56",
    "url": "/stockmoney/json/price_mpct_cols.json"
  },
  {
    "revision": "45dab845fea2b0e7bc9029c8197d433c",
    "url": "/stockmoney/json/price_wpct.json"
  },
  {
    "revision": "06e2f207dffd568d93360a54eff1629d",
    "url": "/stockmoney/json/price_wpct_cols.json"
  },
  {
    "revision": "5deca7ac1e4e972fcb8fa8e56a6401cd",
    "url": "/stockmoney/json/tech_bch.json"
  },
  {
    "revision": "56d227c0fc6a9c5a25f2502cc26148ab",
    "url": "/stockmoney/json/tech_bch_cols.json"
  },
  {
    "revision": "eb20d2a1335af27dfbe1a63a3b34f411",
    "url": "/stockmoney/json/tech_beta.json"
  },
  {
    "revision": "8f09f6a30643cd54d5275425bea06c52",
    "url": "/stockmoney/json/tech_beta_cols.json"
  },
  {
    "revision": "468167fd609e112b4195e42a5bd8238f",
    "url": "/stockmoney/json/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json/tech_kd_cols.json"
  },
  {
    "revision": "f15a0415c0320ebc15264968be4f240b",
    "url": "/stockmoney/json/tech_ma.json"
  },
  {
    "revision": "5c125157702e4475325fc62420500833",
    "url": "/stockmoney/json/tech_ma_cols.json"
  },
  {
    "revision": "06b7f9ef7b6646c13579ee5cfe468343",
    "url": "/stockmoney/json/tech_makink.json"
  },
  {
    "revision": "f95de82f9706f0ab7fbcddef3c0742ee",
    "url": "/stockmoney/json/tech_makink_cols.json"
  },
  {
    "revision": "482461fb9a31cfd582414c0ab1fabea6",
    "url": "/stockmoney/json/triplerate_gross.json"
  },
  {
    "revision": "9af5e57be12f93381dc329d9536ea79e",
    "url": "/stockmoney/json/triplerate_gross_cols.json"
  },
  {
    "revision": "836c2ab2964531000aa8817b5c144f1a",
    "url": "/stockmoney/json/triplerate_net.json"
  },
  {
    "revision": "4e9c6d33d2149c8bc28817f1b959abbe",
    "url": "/stockmoney/json/triplerate_net_cols.json"
  },
  {
    "revision": "52ff05c2b471a3927de191dae1fd0ed7",
    "url": "/stockmoney/json/triplerate_opp.json"
  },
  {
    "revision": "93dd645879845ff63248845999f63573",
    "url": "/stockmoney/json/triplerate_opp_cols.json"
  },
  {
    "revision": "154df088be3635af5e898fb5cbd5b0f0",
    "url": "/stockmoney/json/year_eps.json"
  },
  {
    "revision": "cacbc10e54ca592af7bfd4a49dda2141",
    "url": "/stockmoney/json/year_eps_cols.json"
  },
  {
    "revision": "35cfeddad5c72b682133464e41ce3bb1",
    "url": "/stockmoney/json/year_roe.json"
  },
  {
    "revision": "5417a11638f3b50d12837856857dd221",
    "url": "/stockmoney/json/year_roe_cols.json"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json_otc/.dummy"
  },
  {
    "revision": "7c1d1d3853059516e09cd32662a035cc",
    "url": "/stockmoney/json_otc/basic_4season.json"
  },
  {
    "revision": "5af8e03d5ac2fd4ca03652dd2b98f6f0",
    "url": "/stockmoney/json_otc/basic_4season_cols.json"
  },
  {
    "revision": "bc9caba03c831a65235f32aa3d76560a",
    "url": "/stockmoney/json_otc/basic_asset.json"
  },
  {
    "revision": "b38212d12f678a74ad6a6565339df931",
    "url": "/stockmoney/json_otc/basic_asset_cols.json"
  },
  {
    "revision": "74a9c878d87fa59820c078eaf7259121",
    "url": "/stockmoney/json_otc/basic_cash.json"
  },
  {
    "revision": "70388e0de9a6b1bba0069a8c62b0641b",
    "url": "/stockmoney/json_otc/basic_cash_cols.json"
  },
  {
    "revision": "52ac6f7c257e99e2afc008f56fd24dda",
    "url": "/stockmoney/json_otc/basic_debt.json"
  },
  {
    "revision": "e3f9cecd08d28c46c5992fa91ae2ace7",
    "url": "/stockmoney/json_otc/basic_debt_cols.json"
  },
  {
    "revision": "0f64d8f65d77257a849d8f963669e4fc",
    "url": "/stockmoney/json_otc/basic_eps.json"
  },
  {
    "revision": "a424d13f1940bfd9c0703f816b5f0474",
    "url": "/stockmoney/json_otc/basic_eps_cols.json"
  },
  {
    "revision": "1dbeeb6f774fa67aa088338df0e57fb5",
    "url": "/stockmoney/json_otc/basic_gross.json"
  },
  {
    "revision": "ef9e1e7c0e670d931d881364f6ad5a01",
    "url": "/stockmoney/json_otc/basic_gross_cols.json"
  },
  {
    "revision": "5aae1ae82ae7b13b396c269162916dd7",
    "url": "/stockmoney/json_otc/basic_info.json"
  },
  {
    "revision": "6f99a8a60e35b64e93e4e87ccbc4e5dd",
    "url": "/stockmoney/json_otc/basic_info_cols.json"
  },
  {
    "revision": "5fb44e128e9ba07a630aaf9a5234e88b",
    "url": "/stockmoney/json_otc/basic_net.json"
  },
  {
    "revision": "cfbba58c9990df0f0f2ba485afc775ae",
    "url": "/stockmoney/json_otc/basic_net_cols.json"
  },
  {
    "revision": "a729df5b0370689d05ce5d533a109f69",
    "url": "/stockmoney/json_otc/basic_noi.json"
  },
  {
    "revision": "df4cfd73f02d9ded54e37a09223b9c58",
    "url": "/stockmoney/json_otc/basic_noi_cols.json"
  },
  {
    "revision": "1b49a013449fdd4482f5171664636357",
    "url": "/stockmoney/json_otc/basic_opm.json"
  },
  {
    "revision": "2d4de22eb67086a84eb2f630af4f5e6e",
    "url": "/stockmoney/json_otc/basic_opm_cols.json"
  },
  {
    "revision": "bde5628b88ddcebee3809533bfa62970",
    "url": "/stockmoney/json_otc/basic_opp.json"
  },
  {
    "revision": "27011304748e38032998c76aa97b7fc3",
    "url": "/stockmoney/json_otc/basic_opp_cols.json"
  },
  {
    "revision": "86b5d306e221caf72f7a5e6bf91bf561",
    "url": "/stockmoney/json_otc/basic_roe.json"
  },
  {
    "revision": "43660ce25371a5843a0fd7dedbc4fa78",
    "url": "/stockmoney/json_otc/basic_roe_cols.json"
  },
  {
    "revision": "4e872baf4115321a37fe01da4fc0b46f",
    "url": "/stockmoney/json_otc/basic_rvn.json"
  },
  {
    "revision": "96aec8557726ad2a8764a4ee6a1ae2d3",
    "url": "/stockmoney/json_otc/basic_rvn_cols.json"
  },
  {
    "revision": "1645d2b98230bf756940bc304aff16ed",
    "url": "/stockmoney/json_otc/basic_yearw.json"
  },
  {
    "revision": "37afed6bf332938bf457759590f15e20",
    "url": "/stockmoney/json_otc/basic_yearw_cols.json"
  },
  {
    "revision": "799791bf0816304876f24bc4bb188ef7",
    "url": "/stockmoney/json_otc/chip_borrow.json"
  },
  {
    "revision": "5a8bd57521f8a67e6f158eda3faacf21",
    "url": "/stockmoney/json_otc/chip_borrow_cols.json"
  },
  {
    "revision": "506d59409aa3c0703ffffb039dafaa41",
    "url": "/stockmoney/json_otc/chip_director.json"
  },
  {
    "revision": "5d23148c707411d004af22bf3139001f",
    "url": "/stockmoney/json_otc/chip_director1.json"
  },
  {
    "revision": "8e7a0bacff28aa1cf9f5825c7712c937",
    "url": "/stockmoney/json_otc/chip_director1_cols.json"
  },
  {
    "revision": "f6fdbdbabb2d8d88c4c3061a65ebff98",
    "url": "/stockmoney/json_otc/chip_director3.json"
  },
  {
    "revision": "cb725822bf310830ac86771e76bbf7e5",
    "url": "/stockmoney/json_otc/chip_director3_cols.json"
  },
  {
    "revision": "ba0e805efb85acc07c054b4d4ff080d6",
    "url": "/stockmoney/json_otc/chip_director5.json"
  },
  {
    "revision": "9e1f67c918b55fd9c2153dc91b5ea992",
    "url": "/stockmoney/json_otc/chip_director5_cols.json"
  },
  {
    "revision": "79dce6a98cc61675f28207bb8ee66d68",
    "url": "/stockmoney/json_otc/chip_director_cols.json"
  },
  {
    "revision": "706153125439674579a73e31c2add724",
    "url": "/stockmoney/json_otc/chip_foreign.json"
  },
  {
    "revision": "e59f62dd4b9a788009bac352d7e91c12",
    "url": "/stockmoney/json_otc/chip_foreign_cols.json"
  },
  {
    "revision": "4020a7605ce8abd9d82abfd51e304738",
    "url": "/stockmoney/json_otc/chip_holder.json"
  },
  {
    "revision": "0d80a0b66a710be5c8449613ed1abad2",
    "url": "/stockmoney/json_otc/chip_holder_cols.json"
  },
  {
    "revision": "620d692ccc85ae9f4950aa85ab73f044",
    "url": "/stockmoney/json_otc/chip_legal.json"
  },
  {
    "revision": "56a5a51151871b1624874a4fe5a82f83",
    "url": "/stockmoney/json_otc/chip_legal_cols.json"
  },
  {
    "revision": "149c3e20570d58a3edfd160981ed4cf0",
    "url": "/stockmoney/json_otc/chip_loan.json"
  },
  {
    "revision": "ee402593614d4650e99e562d17e63538",
    "url": "/stockmoney/json_otc/chip_loan_cols.json"
  },
  {
    "revision": "527cb592bcedaf33139c39bd264142d1",
    "url": "/stockmoney/json_otc/chip_trust.json"
  },
  {
    "revision": "4466ee075166bd957824b4a6d6c6ddbe",
    "url": "/stockmoney/json_otc/chip_trust_cols.json"
  },
  {
    "revision": "ada799c6dc7aa579a28c03d7f479c649",
    "url": "/stockmoney/json_otc/deal_pct.json"
  },
  {
    "revision": "6aa4eed51cba9dc1dc746762256d9659",
    "url": "/stockmoney/json_otc/deal_pct_cols.json"
  },
  {
    "revision": "55383947c29ea08a3721707fc5e3539f",
    "url": "/stockmoney/json_otc/deal_vol.json"
  },
  {
    "revision": "b27cd4bd88359e51326cd3dab8215f69",
    "url": "/stockmoney/json_otc/deal_vol_cols.json"
  },
  {
    "revision": "5f0a1eb08f46982798769f9701dcce2c",
    "url": "/stockmoney/json_otc/dividend_cont.json"
  },
  {
    "revision": "d770b65af07d9d64a25e81b34c57086f",
    "url": "/stockmoney/json_otc/dividend_cont_cols.json"
  },
  {
    "revision": "1819f5deb2e53e4a514b4665f680256a",
    "url": "/stockmoney/json_otc/dividend_stat.json"
  },
  {
    "revision": "bafb3fb186f9b5a9ac7072f45130aefc",
    "url": "/stockmoney/json_otc/dividend_stat_2015.json"
  },
  {
    "revision": "cbec2feb676f6a6aa3b239e88e6d6a2c",
    "url": "/stockmoney/json_otc/dividend_stat_2015_cols.json"
  },
  {
    "revision": "a6afbdcc10a479714ee56c562f18de13",
    "url": "/stockmoney/json_otc/dividend_stat_2016.json"
  },
  {
    "revision": "6e18d58a36f9fc2a33f01cedfe00600b",
    "url": "/stockmoney/json_otc/dividend_stat_2016_cols.json"
  },
  {
    "revision": "0aebf07c3a8c2dbe3cda4f890f6178f2",
    "url": "/stockmoney/json_otc/dividend_stat_2017.json"
  },
  {
    "revision": "297d5aebd0f10fcde9bb1a0e4ac5182e",
    "url": "/stockmoney/json_otc/dividend_stat_2017_cols.json"
  },
  {
    "revision": "cd8b078981c8d18261bca91810875882",
    "url": "/stockmoney/json_otc/dividend_stat_2018.json"
  },
  {
    "revision": "260b5376813e3734a06dab71d8b9bd8a",
    "url": "/stockmoney/json_otc/dividend_stat_2018_cols.json"
  },
  {
    "revision": "9f8c70e5b741694c0d1676ce83140a88",
    "url": "/stockmoney/json_otc/dividend_stat_2019.json"
  },
  {
    "revision": "6050c49dcd02fe1bf54be9c00f3014eb",
    "url": "/stockmoney/json_otc/dividend_stat_2019_cols.json"
  },
  {
    "revision": "9b4c4be9545c11e770cbe8be386f94cb",
    "url": "/stockmoney/json_otc/dividend_stat_cols.json"
  },
  {
    "revision": "321d7d8b929293e890616eaa7110c85a",
    "url": "/stockmoney/json_otc/dividend_yield.json"
  },
  {
    "revision": "ecb2998fde71d849b8992a7b6c4e2e3d",
    "url": "/stockmoney/json_otc/dividend_yield_cols.json"
  },
  {
    "revision": "7070d461fca9f57f911b200dd2fc5bd8",
    "url": "/stockmoney/json_otc/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json_otc/export_director_cols.json"
  },
  {
    "revision": "bf4091968a9416ed62033f7746eeee19",
    "url": "/stockmoney/json_otc/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json_otc/export_incomerate_cols.json"
  },
  {
    "revision": "cd31b8a4e6ae79c8381334b713671557",
    "url": "/stockmoney/json_otc/export_stockfish.json"
  },
  {
    "revision": "192fef50d1b0b739db62b78e28521927",
    "url": "/stockmoney/json_otc/export_stockfish_cols.json"
  },
  {
    "revision": "06644a4d0d24006b9520f689110d209f",
    "url": "/stockmoney/json_otc/export_triplerate.json"
  },
  {
    "revision": "a625f25eee5bf1c3f165bc86c455ce79",
    "url": "/stockmoney/json_otc/export_triplerate_cols.json"
  },
  {
    "revision": "962233c053e6db9fe7b8fc8ba435e819",
    "url": "/stockmoney/json_otc/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json_otc/export_water_cols.json"
  },
  {
    "revision": "c55c440719a695161addc6d1fe124f60",
    "url": "/stockmoney/json_otc/export_yield.json"
  },
  {
    "revision": "49e7cdd201cc3d5a6cd680c3a5aa3c7f",
    "url": "/stockmoney/json_otc/my_basic.json"
  },
  {
    "revision": "12af128c5c8cb61ac4c2042aefe1f0cf",
    "url": "/stockmoney/json_otc/my_eps.json"
  },
  {
    "revision": "ee41870e2a556afa1b4a4cb967744e6d",
    "url": "/stockmoney/json_otc/my_eps_cols.json"
  },
  {
    "revision": "82fe3609734f1af293aa0d4a608455ca",
    "url": "/stockmoney/json_otc/price_dpct.json"
  },
  {
    "revision": "4a8550ef29380c4fa8d8ac437919bf01",
    "url": "/stockmoney/json_otc/price_dpct_cols.json"
  },
  {
    "revision": "aaf41104a1f50cc6bc5af8e0ad5ed583",
    "url": "/stockmoney/json_otc/price_mpct.json"
  },
  {
    "revision": "f49e4c8c592ee192541945e62871c3d3",
    "url": "/stockmoney/json_otc/price_mpct_cols.json"
  },
  {
    "revision": "0a392b000d157a7010eddab5b1d0a821",
    "url": "/stockmoney/json_otc/price_wpct.json"
  },
  {
    "revision": "5274839ff9361763e75b70bb12e266d6",
    "url": "/stockmoney/json_otc/price_wpct_cols.json"
  },
  {
    "revision": "6ec935e5208c3de0ed02ca1d5eedeacb",
    "url": "/stockmoney/json_otc/tech_bch.json"
  },
  {
    "revision": "1f3501a7241684346326f6b20fef29ab",
    "url": "/stockmoney/json_otc/tech_bch_cols.json"
  },
  {
    "revision": "f3fb0d0947a76d805d6115aac16d154e",
    "url": "/stockmoney/json_otc/tech_beta.json"
  },
  {
    "revision": "1d1993c61608814513697231793da5ff",
    "url": "/stockmoney/json_otc/tech_beta_cols.json"
  },
  {
    "revision": "1e1ecd975cd00f6c62d71fa6a6ee0d82",
    "url": "/stockmoney/json_otc/tech_kd.json"
  },
  {
    "revision": "4f5d6ca8656dd449a555f2892c29746e",
    "url": "/stockmoney/json_otc/tech_kd_cols.json"
  },
  {
    "revision": "68d740608a6dbbd7697d9cb795838dad",
    "url": "/stockmoney/json_otc/triplerate_gross.json"
  },
  {
    "revision": "154cbf336702171df95dd99cc630431b",
    "url": "/stockmoney/json_otc/triplerate_gross_cols.json"
  },
  {
    "revision": "2d151d01e16e5017f50895c8f7a5ff68",
    "url": "/stockmoney/json_otc/triplerate_net.json"
  },
  {
    "revision": "f14954dd1a9d00f89dfc046516b159c3",
    "url": "/stockmoney/json_otc/triplerate_net_cols.json"
  },
  {
    "revision": "c0a943f4f71c3b9f8b4ab028aa2f2681",
    "url": "/stockmoney/json_otc/triplerate_opp.json"
  },
  {
    "revision": "22e3b22d78956c4986709c08ce1e3469",
    "url": "/stockmoney/json_otc/triplerate_opp_cols.json"
  },
  {
    "revision": "8518f8e3ccb03bb7507e75ba45476ccc",
    "url": "/stockmoney/json_otc/year_eps.json"
  },
  {
    "revision": "d29fd0443a18bb7d68c7f98296fced87",
    "url": "/stockmoney/json_otc/year_eps_cols.json"
  },
  {
    "revision": "332295a4c46fdbf738bb6971ce61aa3a",
    "url": "/stockmoney/json_otc/year_roe.json"
  },
  {
    "revision": "7ed4aeab9677a5ede6e8d2429fc6e696",
    "url": "/stockmoney/json_otc/year_roe_cols.json"
  },
  {
    "revision": "b96e0d5a5df171b63ae60164bac0e3af",
    "url": "/stockmoney/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/stockmoney/robots.txt"
  },
  {
    "revision": "1af86bcf7567eafa87b0",
    "url": "/stockmoney/static/css/app.144a22eb.css"
  },
  {
    "revision": "a7bd39673262647df6da",
    "url": "/stockmoney/static/css/chunk-vendors.eae4093c.css"
  },
  {
    "revision": "ecb3bfc03db10b6f9d6e23e710d5c953",
    "url": "/stockmoney/static/img/logo.ecb3bfc0.png"
  },
  {
    "revision": "658800e4ddcdedaaa231",
    "url": "/stockmoney/static/js/about.6cc0e21f.js"
  },
  {
    "revision": "1af86bcf7567eafa87b0",
    "url": "/stockmoney/static/js/app.ef89e036.js"
  },
  {
    "revision": "a7bd39673262647df6da",
    "url": "/stockmoney/static/js/chunk-vendors.1f857820.js"
  }
]);