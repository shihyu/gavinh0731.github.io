self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "90b6a88d3fa60d662134d6d66d4a2cc5",
    "url": "/stockmoney/index.html"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json/.dummy"
  },
  {
    "revision": "5d54e254b65ce3aeaaa1c4568c8562ca",
    "url": "/stockmoney/json/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json/basic_4season_cols.json"
  },
  {
    "revision": "eea564004268140d8c1f222bcd7ddc1a",
    "url": "/stockmoney/json/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json/basic_asset_cols.json"
  },
  {
    "revision": "f8fcb10a7b0f08a8cb3aed854b8d6226",
    "url": "/stockmoney/json/basic_cash.json"
  },
  {
    "revision": "25c59d70c2df2274179826a175008845",
    "url": "/stockmoney/json/basic_cash_cols.json"
  },
  {
    "revision": "8a20bb18f640c174a97b18b903c5d2af",
    "url": "/stockmoney/json/basic_debt.json"
  },
  {
    "revision": "8b1a708625ff812bc9a5267299e88455",
    "url": "/stockmoney/json/basic_debt_cols.json"
  },
  {
    "revision": "5d560322275eb0725b992a811f413b5a",
    "url": "/stockmoney/json/basic_eps.json"
  },
  {
    "revision": "1bb63736012030d63677396b11170de0",
    "url": "/stockmoney/json/basic_eps_cols.json"
  },
  {
    "revision": "18f32367cfd329d8614bc147bcf50c3d",
    "url": "/stockmoney/json/basic_gross.json"
  },
  {
    "revision": "fa50418ae9e872117b4fb1ca1c6f3f4b",
    "url": "/stockmoney/json/basic_gross_cols.json"
  },
  {
    "revision": "afa4c30d2218a70978d30407e6be9986",
    "url": "/stockmoney/json/basic_info.json"
  },
  {
    "revision": "13e705f89a2b21a1bed5151ba2614a3a",
    "url": "/stockmoney/json/basic_info_cols.json"
  },
  {
    "revision": "cc2e078f2273b11a78f2c8a4c9b87c13",
    "url": "/stockmoney/json/basic_net.json"
  },
  {
    "revision": "fd7590f9c413f9def618926669585586",
    "url": "/stockmoney/json/basic_net_cols.json"
  },
  {
    "revision": "83411b8d08eb211edb6bf636eb757e75",
    "url": "/stockmoney/json/basic_noi.json"
  },
  {
    "revision": "afaca8c305adb66855fe5c49115dc506",
    "url": "/stockmoney/json/basic_noi_cols.json"
  },
  {
    "revision": "5c75212b8c7010c4effb0110407c2e91",
    "url": "/stockmoney/json/basic_opm.json"
  },
  {
    "revision": "811d6f85eb415dbeeb3ebfa5e2874f66",
    "url": "/stockmoney/json/basic_opm_cols.json"
  },
  {
    "revision": "a579d0ad89127ca13168d951e43db7ff",
    "url": "/stockmoney/json/basic_opp.json"
  },
  {
    "revision": "ead616d06f1cfaa65ca2f156374cb537",
    "url": "/stockmoney/json/basic_opp_cols.json"
  },
  {
    "revision": "88569913644342d0e508cbb5b9faf81d",
    "url": "/stockmoney/json/basic_roe.json"
  },
  {
    "revision": "4fa53a72eb46864d5827005ac8fb015d",
    "url": "/stockmoney/json/basic_roe_cols.json"
  },
  {
    "revision": "216a9ed9d5aa715e4f79890683d962d8",
    "url": "/stockmoney/json/basic_rvn.json"
  },
  {
    "revision": "944bab5df12c4710960ad0125f4985cc",
    "url": "/stockmoney/json/basic_rvn_cols.json"
  },
  {
    "revision": "e8f2af89f9ba9c4427c06ba201d44117",
    "url": "/stockmoney/json/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json/basic_yearw_cols.json"
  },
  {
    "revision": "00631c5396da1d65bc7eff5355a8ac40",
    "url": "/stockmoney/json/chip_director.json"
  },
  {
    "revision": "a65e87ff73d4782cd96ecf756b138b5f",
    "url": "/stockmoney/json/chip_director1.json"
  },
  {
    "revision": "9245b933efe32254018a0a6e9a6c8613",
    "url": "/stockmoney/json/chip_director1_cols.json"
  },
  {
    "revision": "e81ed88b79d07729622941ea4ce607a8",
    "url": "/stockmoney/json/chip_director3.json"
  },
  {
    "revision": "b856d752ee7572bba69b5bfefbe9e41b",
    "url": "/stockmoney/json/chip_director3_cols.json"
  },
  {
    "revision": "3fd65feaf9ed847fd924846eb5d9e620",
    "url": "/stockmoney/json/chip_director5.json"
  },
  {
    "revision": "825ba91683006403a96e4ead7ebc2e2c",
    "url": "/stockmoney/json/chip_director5_cols.json"
  },
  {
    "revision": "9bbbf6600d4c03482470ae7a8ed48118",
    "url": "/stockmoney/json/chip_director_cols.json"
  },
  {
    "revision": "2d67cee76e27d36ba2ca88794d06f32f",
    "url": "/stockmoney/json/chip_legal.json"
  },
  {
    "revision": "d7e02491040240f9cb7da3e58c364e5d",
    "url": "/stockmoney/json/chip_legal_cols.json"
  },
  {
    "revision": "246f2aaa46e4fa45fde0c24836810b39",
    "url": "/stockmoney/json/chip_trust.json"
  },
  {
    "revision": "5fd5d28bcd216b4388792d1f1ca56305",
    "url": "/stockmoney/json/chip_trust_cols.json"
  },
  {
    "revision": "552ac8488d5c206cd7b88eb1ff3362d1",
    "url": "/stockmoney/json/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json/deal_pct_cols.json"
  },
  {
    "revision": "8ce8a98484a537402f430487f0c77350",
    "url": "/stockmoney/json/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json/deal_vol_cols.json"
  },
  {
    "revision": "fc2bce89ff71b8c4dbfb96ae51e95a3a",
    "url": "/stockmoney/json/dividend_cont.json"
  },
  {
    "revision": "e98f37eaa810fd912b66473ef4aec297",
    "url": "/stockmoney/json/dividend_cont_cols.json"
  },
  {
    "revision": "f42b98747582fe0c7efe8b1458424fb1",
    "url": "/stockmoney/json/dividend_stat.json"
  },
  {
    "revision": "196b89472224ad3a4e0e30a0928224ba",
    "url": "/stockmoney/json/dividend_stat_2015.json"
  },
  {
    "revision": "008c79d526737b517a9a742b04502b20",
    "url": "/stockmoney/json/dividend_stat_2015_cols.json"
  },
  {
    "revision": "4c82d560d8b0221e4c3bb533ab62ac97",
    "url": "/stockmoney/json/dividend_stat_2016.json"
  },
  {
    "revision": "ec5a0a94673998b0bb4a63db93d08f4a",
    "url": "/stockmoney/json/dividend_stat_2016_cols.json"
  },
  {
    "revision": "29935c9714cd0416e655ef5c1bc10917",
    "url": "/stockmoney/json/dividend_stat_2017.json"
  },
  {
    "revision": "e37fc91cd72912b24657ed675d9f1c8b",
    "url": "/stockmoney/json/dividend_stat_2017_cols.json"
  },
  {
    "revision": "eade50f7f4b3014c389e64d8d5ae218d",
    "url": "/stockmoney/json/dividend_stat_2018.json"
  },
  {
    "revision": "38050d84b8d337ce366fb397e8e206f7",
    "url": "/stockmoney/json/dividend_stat_2018_cols.json"
  },
  {
    "revision": "175374a209fdeb9cfc755d20333c0833",
    "url": "/stockmoney/json/dividend_stat_2019.json"
  },
  {
    "revision": "7ec66cdc30aa0d150bc4f797bdc131c4",
    "url": "/stockmoney/json/dividend_stat_2019_cols.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json/dividend_stat_cols.json"
  },
  {
    "revision": "f124fb7fd8a9e4d85bbf2bb30f7c846b",
    "url": "/stockmoney/json/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json/dividend_yield_cols.json"
  },
  {
    "revision": "de0a21d6d87b68961891553bf8397557",
    "url": "/stockmoney/json/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json/export_director_cols.json"
  },
  {
    "revision": "3035a07fb58a8e205f1d3225485d8b18",
    "url": "/stockmoney/json/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json/export_incomerate_cols.json"
  },
  {
    "revision": "a963f5f2f8747d2040831d01f61bae73",
    "url": "/stockmoney/json/export_stockfish.json"
  },
  {
    "revision": "aa76bf1d9931072a3fe9c3e216868eac",
    "url": "/stockmoney/json/export_stockfish_cols.json"
  },
  {
    "revision": "3b84e04b7628a63eb0ce309671eb1386",
    "url": "/stockmoney/json/export_triplerate.json"
  },
  {
    "revision": "2f91c73c151fa60608962f562b8d2bc9",
    "url": "/stockmoney/json/export_triplerate_cols.json"
  },
  {
    "revision": "15f2046e2a9d400a99096c7821638264",
    "url": "/stockmoney/json/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json/export_water_cols.json"
  },
  {
    "revision": "df452a2b1314e15db0fea997b9da2e99",
    "url": "/stockmoney/json/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json/export_yield_cols.json"
  },
  {
    "revision": "28381be3edbaf3e40e4925da1d682b66",
    "url": "/stockmoney/json/my_eps.json"
  },
  {
    "revision": "87b98bb7ccff2628d43fe83db7362e93",
    "url": "/stockmoney/json/my_eps_cols.json"
  },
  {
    "revision": "e623ff8537793c56f137dd9ce880f60d",
    "url": "/stockmoney/json/tech_bch.json"
  },
  {
    "revision": "4ceab57a8c9a6cd7e19f2b097e934cc2",
    "url": "/stockmoney/json/tech_bch_cols.json"
  },
  {
    "revision": "a21782a7f429e2d572f3d77c400c5bbf",
    "url": "/stockmoney/json/tech_beta.json"
  },
  {
    "revision": "8f09f6a30643cd54d5275425bea06c52",
    "url": "/stockmoney/json/tech_beta_cols.json"
  },
  {
    "revision": "0120b0f2ec52855db2188f53b133232e",
    "url": "/stockmoney/json/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json/tech_kd_cols.json"
  },
  {
    "revision": "631935f899deedfaf07f75b6127d14a1",
    "url": "/stockmoney/json/tech_ma.json"
  },
  {
    "revision": "0312283011ee3335e1c1333e9725ace1",
    "url": "/stockmoney/json/tech_ma_cols.json"
  },
  {
    "revision": "8ce2b920541b4b4617d07ccd7c1d1f72",
    "url": "/stockmoney/json/triplerate_gross.json"
  },
  {
    "revision": "5125f58e1c5e3e2a4c52a4c1f8465e9c",
    "url": "/stockmoney/json/triplerate_gross_cols.json"
  },
  {
    "revision": "3d040715705e517a9f67dc0af161ebe7",
    "url": "/stockmoney/json/triplerate_net.json"
  },
  {
    "revision": "828d5cd5162e7b74b4d731befafb9cb7",
    "url": "/stockmoney/json/triplerate_net_cols.json"
  },
  {
    "revision": "7613e053e19b23fb04c3b32a3e88948c",
    "url": "/stockmoney/json/triplerate_opp.json"
  },
  {
    "revision": "5a9cd6a16ab195540aab234f242fb9bf",
    "url": "/stockmoney/json/triplerate_opp_cols.json"
  },
  {
    "revision": "99b860f67f328a3f645c560396e686a9",
    "url": "/stockmoney/json/year_eps.json"
  },
  {
    "revision": "4485abe80a71279b08bd788b4ed42714",
    "url": "/stockmoney/json/year_eps_cols.json"
  },
  {
    "revision": "ae15e53c8ae198af42ba5771e248e163",
    "url": "/stockmoney/json/year_roe.json"
  },
  {
    "revision": "5c74bc7ec2e684f8e5d786f9a61784a5",
    "url": "/stockmoney/json/year_roe_cols.json"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json_otc/.dummy"
  },
  {
    "revision": "72df6215bd8ffde44ec9f3a584e93d96",
    "url": "/stockmoney/json_otc/basic_4season.json"
  },
  {
    "revision": "5af8e03d5ac2fd4ca03652dd2b98f6f0",
    "url": "/stockmoney/json_otc/basic_4season_cols.json"
  },
  {
    "revision": "cea365aa4c453dcd1135a616c2bd692e",
    "url": "/stockmoney/json_otc/basic_asset.json"
  },
  {
    "revision": "b38212d12f678a74ad6a6565339df931",
    "url": "/stockmoney/json_otc/basic_asset_cols.json"
  },
  {
    "revision": "6155a9cae6ae331eb1ce956c96188b82",
    "url": "/stockmoney/json_otc/basic_cash.json"
  },
  {
    "revision": "7c7baa4d720b834749fe3c5c76d3042f",
    "url": "/stockmoney/json_otc/basic_cash_cols.json"
  },
  {
    "revision": "91f2fc3ba18290b9cfc2f0e7f2db1d02",
    "url": "/stockmoney/json_otc/basic_debt.json"
  },
  {
    "revision": "10227ad30d86420118a1ed183f57affb",
    "url": "/stockmoney/json_otc/basic_debt_cols.json"
  },
  {
    "revision": "c6d0a84c237986e60e5b8ba4bf755306",
    "url": "/stockmoney/json_otc/basic_eps.json"
  },
  {
    "revision": "4cabdf6dee99726c4ab83271caa9e653",
    "url": "/stockmoney/json_otc/basic_eps_cols.json"
  },
  {
    "revision": "17a03c2eae7fd55623ca0f4f2e25101e",
    "url": "/stockmoney/json_otc/basic_gross.json"
  },
  {
    "revision": "b14e0e875d067dbed2235494ee83658a",
    "url": "/stockmoney/json_otc/basic_gross_cols.json"
  },
  {
    "revision": "1a0ab20fae0c089cf812b8c703b88a44",
    "url": "/stockmoney/json_otc/basic_info.json"
  },
  {
    "revision": "6f99a8a60e35b64e93e4e87ccbc4e5dd",
    "url": "/stockmoney/json_otc/basic_info_cols.json"
  },
  {
    "revision": "3c317118793acddf6b785d70db7251f5",
    "url": "/stockmoney/json_otc/basic_net.json"
  },
  {
    "revision": "0be8a58bdde2d78a38b72c5c89fedcdc",
    "url": "/stockmoney/json_otc/basic_net_cols.json"
  },
  {
    "revision": "6eb9fe869c0ad868fd55b40e1b6bb7ad",
    "url": "/stockmoney/json_otc/basic_noi.json"
  },
  {
    "revision": "d2f1cc47fbbaab552f3fc006e45787d1",
    "url": "/stockmoney/json_otc/basic_noi_cols.json"
  },
  {
    "revision": "e9b604bf1c39be534606c7fbb96c1f96",
    "url": "/stockmoney/json_otc/basic_opm.json"
  },
  {
    "revision": "190d22e79d2144a486a0143df22f65da",
    "url": "/stockmoney/json_otc/basic_opm_cols.json"
  },
  {
    "revision": "8b0228aabe1ff80c8313617c5955eda9",
    "url": "/stockmoney/json_otc/basic_opp.json"
  },
  {
    "revision": "d17491d4b41556a5fb4a2b0a004893f0",
    "url": "/stockmoney/json_otc/basic_opp_cols.json"
  },
  {
    "revision": "2f8f5dac036500e89ebb6123c36d0b48",
    "url": "/stockmoney/json_otc/basic_roe.json"
  },
  {
    "revision": "b306f3901c2a2ebc864266afae15f77c",
    "url": "/stockmoney/json_otc/basic_roe_cols.json"
  },
  {
    "revision": "3650cfa3a6d4b6026ec3be45b3cf1205",
    "url": "/stockmoney/json_otc/basic_rvn.json"
  },
  {
    "revision": "8bd20b027d21fd75b82d9a9781908341",
    "url": "/stockmoney/json_otc/basic_rvn_cols.json"
  },
  {
    "revision": "d763654aca2d5498e137d2ded80f1e83",
    "url": "/stockmoney/json_otc/basic_yearw.json"
  },
  {
    "revision": "37afed6bf332938bf457759590f15e20",
    "url": "/stockmoney/json_otc/basic_yearw_cols.json"
  },
  {
    "revision": "1d58b0900190302900f69bd14d2845da",
    "url": "/stockmoney/json_otc/chip_director.json"
  },
  {
    "revision": "df811d38e491d95ccec666a96aece193",
    "url": "/stockmoney/json_otc/chip_director1.json"
  },
  {
    "revision": "8e7a0bacff28aa1cf9f5825c7712c937",
    "url": "/stockmoney/json_otc/chip_director1_cols.json"
  },
  {
    "revision": "b510b2b7bbe787f38040bd0529443d9b",
    "url": "/stockmoney/json_otc/chip_director3.json"
  },
  {
    "revision": "cb725822bf310830ac86771e76bbf7e5",
    "url": "/stockmoney/json_otc/chip_director3_cols.json"
  },
  {
    "revision": "6158702c234820e773828c6dc7f458ca",
    "url": "/stockmoney/json_otc/chip_director5.json"
  },
  {
    "revision": "9e1f67c918b55fd9c2153dc91b5ea992",
    "url": "/stockmoney/json_otc/chip_director5_cols.json"
  },
  {
    "revision": "79dce6a98cc61675f28207bb8ee66d68",
    "url": "/stockmoney/json_otc/chip_director_cols.json"
  },
  {
    "revision": "7525752d6a5bdda06286a2ddf094501f",
    "url": "/stockmoney/json_otc/chip_legal.json"
  },
  {
    "revision": "56a5a51151871b1624874a4fe5a82f83",
    "url": "/stockmoney/json_otc/chip_legal_cols.json"
  },
  {
    "revision": "a8eb9e67fd0653e53f77de5e5d838a02",
    "url": "/stockmoney/json_otc/chip_trust.json"
  },
  {
    "revision": "4466ee075166bd957824b4a6d6c6ddbe",
    "url": "/stockmoney/json_otc/chip_trust_cols.json"
  },
  {
    "revision": "1a03ce40a123a0d8bdb539b6785e16f2",
    "url": "/stockmoney/json_otc/deal_pct.json"
  },
  {
    "revision": "6aa4eed51cba9dc1dc746762256d9659",
    "url": "/stockmoney/json_otc/deal_pct_cols.json"
  },
  {
    "revision": "1dd2f42927a5512ee7fa6d25d6fe7898",
    "url": "/stockmoney/json_otc/deal_vol.json"
  },
  {
    "revision": "b27cd4bd88359e51326cd3dab8215f69",
    "url": "/stockmoney/json_otc/deal_vol_cols.json"
  },
  {
    "revision": "986d0fd3700e7c949556caeaaa68aa2c",
    "url": "/stockmoney/json_otc/dividend_cont.json"
  },
  {
    "revision": "d770b65af07d9d64a25e81b34c57086f",
    "url": "/stockmoney/json_otc/dividend_cont_cols.json"
  },
  {
    "revision": "054d47d3d138e1af8219e9cf798a3460",
    "url": "/stockmoney/json_otc/dividend_stat.json"
  },
  {
    "revision": "b2c4e4d38b095a63661913d62cbdda4c",
    "url": "/stockmoney/json_otc/dividend_stat_2015.json"
  },
  {
    "revision": "cbec2feb676f6a6aa3b239e88e6d6a2c",
    "url": "/stockmoney/json_otc/dividend_stat_2015_cols.json"
  },
  {
    "revision": "e0c31b1d1ddb328af9d9d17a7bb41a91",
    "url": "/stockmoney/json_otc/dividend_stat_2016.json"
  },
  {
    "revision": "6e18d58a36f9fc2a33f01cedfe00600b",
    "url": "/stockmoney/json_otc/dividend_stat_2016_cols.json"
  },
  {
    "revision": "1f2099eeaf160a1528ef9539da5d8fd7",
    "url": "/stockmoney/json_otc/dividend_stat_2017.json"
  },
  {
    "revision": "297d5aebd0f10fcde9bb1a0e4ac5182e",
    "url": "/stockmoney/json_otc/dividend_stat_2017_cols.json"
  },
  {
    "revision": "74c4be3853966c5a91d33d9afb043d93",
    "url": "/stockmoney/json_otc/dividend_stat_2018.json"
  },
  {
    "revision": "260b5376813e3734a06dab71d8b9bd8a",
    "url": "/stockmoney/json_otc/dividend_stat_2018_cols.json"
  },
  {
    "revision": "8e94b516b8fe50dbccb7edb638442d82",
    "url": "/stockmoney/json_otc/dividend_stat_2019.json"
  },
  {
    "revision": "6050c49dcd02fe1bf54be9c00f3014eb",
    "url": "/stockmoney/json_otc/dividend_stat_2019_cols.json"
  },
  {
    "revision": "9b4c4be9545c11e770cbe8be386f94cb",
    "url": "/stockmoney/json_otc/dividend_stat_cols.json"
  },
  {
    "revision": "44ec36d03e207de104ce54101a62d479",
    "url": "/stockmoney/json_otc/dividend_yield.json"
  },
  {
    "revision": "ecb2998fde71d849b8992a7b6c4e2e3d",
    "url": "/stockmoney/json_otc/dividend_yield_cols.json"
  },
  {
    "revision": "e0d5098e04e328f67218e5ade7731715",
    "url": "/stockmoney/json_otc/export_director.json"
  },
  {
    "revision": "9852c077db53cfc7015379bed56f951d",
    "url": "/stockmoney/json_otc/export_incomerate.json"
  },
  {
    "revision": "7e91f864d0a0cfbadd8342655bc42c30",
    "url": "/stockmoney/json_otc/export_stockfish.json"
  },
  {
    "revision": "42d4d4e7dca53474accce8490053532d",
    "url": "/stockmoney/json_otc/export_triplerate.json"
  },
  {
    "revision": "2ad013a00aadf07694ed2879762fbc84",
    "url": "/stockmoney/json_otc/export_water.json"
  },
  {
    "revision": "e82ba94d34334bd3aaf56aa174ef96de",
    "url": "/stockmoney/json_otc/export_yield.json"
  },
  {
    "revision": "8cebdb453dba3d38d95df85b67151bb5",
    "url": "/stockmoney/json_otc/my_eps.json"
  },
  {
    "revision": "56f969d20aa1655565fd2cb2cb16433d",
    "url": "/stockmoney/json_otc/tech_bch.json"
  },
  {
    "revision": "1f3501a7241684346326f6b20fef29ab",
    "url": "/stockmoney/json_otc/tech_bch_cols.json"
  },
  {
    "revision": "eb9d6921680b7b509451d2c770d607c1",
    "url": "/stockmoney/json_otc/tech_beta.json"
  },
  {
    "revision": "1d1993c61608814513697231793da5ff",
    "url": "/stockmoney/json_otc/tech_beta_cols.json"
  },
  {
    "revision": "26e1e9cf187859817d5f29d0a67622b9",
    "url": "/stockmoney/json_otc/tech_kd.json"
  },
  {
    "revision": "4f5d6ca8656dd449a555f2892c29746e",
    "url": "/stockmoney/json_otc/tech_kd_cols.json"
  },
  {
    "revision": "398807837420a1e7c1c566ae02329809",
    "url": "/stockmoney/json_otc/tech_ma.json"
  },
  {
    "revision": "d6c2c2c917b71f3b85765373cb229222",
    "url": "/stockmoney/json_otc/tech_ma_cols.json"
  },
  {
    "revision": "d6078e21792eb9484a08345ac87cb3dc",
    "url": "/stockmoney/json_otc/triplerate_gross.json"
  },
  {
    "revision": "0ab649571f2016fcb3f0ffd101a46420",
    "url": "/stockmoney/json_otc/triplerate_gross_cols.json"
  },
  {
    "revision": "54ff0ddfcc60303cb73239d46fdab68a",
    "url": "/stockmoney/json_otc/triplerate_net.json"
  },
  {
    "revision": "f31e36e19d15f2b8d7375afa45098c99",
    "url": "/stockmoney/json_otc/triplerate_net_cols.json"
  },
  {
    "revision": "d888a06ceaa5709ba52cb786384b987a",
    "url": "/stockmoney/json_otc/triplerate_opp.json"
  },
  {
    "revision": "c0c9dd787dc2367ce6e883999ba19f9b",
    "url": "/stockmoney/json_otc/triplerate_opp_cols.json"
  },
  {
    "revision": "39360d11eb04274cd79bc2d1b8998a9a",
    "url": "/stockmoney/json_otc/year_eps.json"
  },
  {
    "revision": "a33f46c232d01134bf1db285a735d2b4",
    "url": "/stockmoney/json_otc/year_eps_cols.json"
  },
  {
    "revision": "7a6e96dffffeff85b635c319df57ea26",
    "url": "/stockmoney/json_otc/year_roe.json"
  },
  {
    "revision": "75027b96328136074b32aab5efe75432",
    "url": "/stockmoney/json_otc/year_roe_cols.json"
  },
  {
    "revision": "b96e0d5a5df171b63ae60164bac0e3af",
    "url": "/stockmoney/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/stockmoney/robots.txt"
  },
  {
    "revision": "c4248bc0084375b29054",
    "url": "/stockmoney/static/css/app.79de8fd1.css"
  },
  {
    "revision": "0b67f49ecef966899a76",
    "url": "/stockmoney/static/css/chunk-vendors.eae4093c.css"
  },
  {
    "revision": "ecb3bfc03db10b6f9d6e23e710d5c953",
    "url": "/stockmoney/static/img/logo.ecb3bfc0.png"
  },
  {
    "revision": "658800e4ddcdedaaa231",
    "url": "/stockmoney/static/js/about.6cc0e21f.js"
  },
  {
    "revision": "c4248bc0084375b29054",
    "url": "/stockmoney/static/js/app.10dc9857.js"
  },
  {
    "revision": "0b67f49ecef966899a76",
    "url": "/stockmoney/static/js/chunk-vendors.e64b16c7.js"
  }
]);