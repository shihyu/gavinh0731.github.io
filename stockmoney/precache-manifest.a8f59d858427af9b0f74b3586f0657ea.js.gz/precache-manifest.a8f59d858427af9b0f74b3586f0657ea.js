self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "46b99bb34bc8eb485c28918996dcd520",
    "url": "/stockmoney/index.html"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json/.dummy"
  },
  {
    "revision": "e0172f86eff618b283aaa004e9b204c6",
    "url": "/stockmoney/json/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json/basic_4season_cols.json"
  },
  {
    "revision": "e2f8828db2df3fcdaa08fdaabdec8df3",
    "url": "/stockmoney/json/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json/basic_asset_cols.json"
  },
  {
    "revision": "e528e8d568ed5ccf6f2a4759fb994143",
    "url": "/stockmoney/json/basic_cash.json"
  },
  {
    "revision": "bd56d2c5b763f7596f4f57a2036cb955",
    "url": "/stockmoney/json/basic_cash_cols.json"
  },
  {
    "revision": "3406127c598a4444a491dacc8be3bc59",
    "url": "/stockmoney/json/basic_debt.json"
  },
  {
    "revision": "53c839ec3080905295fad0c1112c1511",
    "url": "/stockmoney/json/basic_debt_cols.json"
  },
  {
    "revision": "984637b0ff6dbd11fff6ccbe35ab10a1",
    "url": "/stockmoney/json/basic_eps.json"
  },
  {
    "revision": "e15b7187a1a0d20b2291dbb9140f316a",
    "url": "/stockmoney/json/basic_eps_cols.json"
  },
  {
    "revision": "97e1ccd16b57e081e7826baf414e60a2",
    "url": "/stockmoney/json/basic_gross.json"
  },
  {
    "revision": "78091bdb8be60034bceed28ce6ec7490",
    "url": "/stockmoney/json/basic_gross_cols.json"
  },
  {
    "revision": "644562025a2f922e8255ac4794464c6d",
    "url": "/stockmoney/json/basic_info.json"
  },
  {
    "revision": "2dbdaa83e5d85419907f0945a8bbb99d",
    "url": "/stockmoney/json/basic_info_cols.json"
  },
  {
    "revision": "09c7a3131cf3a8bf29bc7ef3e046c3f0",
    "url": "/stockmoney/json/basic_noi.json"
  },
  {
    "revision": "3bed754b01539b84010a7138d4bc1284",
    "url": "/stockmoney/json/basic_noi_cols.json"
  },
  {
    "revision": "33cf7661e7453209371f1262b23b6dc8",
    "url": "/stockmoney/json/basic_opm.json"
  },
  {
    "revision": "ef1b214a3ba1d3e9257ad23ee14fe5fd",
    "url": "/stockmoney/json/basic_opm_cols.json"
  },
  {
    "revision": "0b03bf9f57405847cad8e0ccdac14c54",
    "url": "/stockmoney/json/basic_opp.json"
  },
  {
    "revision": "d797dd721d955262993240fae6f33cdb",
    "url": "/stockmoney/json/basic_opp_cols.json"
  },
  {
    "revision": "585b745b07428ae642819e650f2fae25",
    "url": "/stockmoney/json/basic_roe.json"
  },
  {
    "revision": "f35772329ca03672b8f21ceba59be083",
    "url": "/stockmoney/json/basic_roe_cols.json"
  },
  {
    "revision": "a8238c0594a80f2c847e6cc343ac5691",
    "url": "/stockmoney/json/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json/basic_yearw_cols.json"
  },
  {
    "revision": "fe070acd2c5878f67227919c6e3fda5f",
    "url": "/stockmoney/json/chip_director.json"
  },
  {
    "revision": "b5b64783dc5e59d8306be8decc756596",
    "url": "/stockmoney/json/chip_director1.json"
  },
  {
    "revision": "9245b933efe32254018a0a6e9a6c8613",
    "url": "/stockmoney/json/chip_director1_cols.json"
  },
  {
    "revision": "26f7380ab45160ce3cfdf549f08da434",
    "url": "/stockmoney/json/chip_director3.json"
  },
  {
    "revision": "b856d752ee7572bba69b5bfefbe9e41b",
    "url": "/stockmoney/json/chip_director3_cols.json"
  },
  {
    "revision": "a2ada3ef9c34d092c106eeef11993a69",
    "url": "/stockmoney/json/chip_director5.json"
  },
  {
    "revision": "825ba91683006403a96e4ead7ebc2e2c",
    "url": "/stockmoney/json/chip_director5_cols.json"
  },
  {
    "revision": "9bbbf6600d4c03482470ae7a8ed48118",
    "url": "/stockmoney/json/chip_director_cols.json"
  },
  {
    "revision": "f5def21bd29caf2f8c552a300bcedbc5",
    "url": "/stockmoney/json/chip_legal.json"
  },
  {
    "revision": "d7e02491040240f9cb7da3e58c364e5d",
    "url": "/stockmoney/json/chip_legal_cols.json"
  },
  {
    "revision": "fa976860133f23f8224d14b0355a8800",
    "url": "/stockmoney/json/chip_trust.json"
  },
  {
    "revision": "5fd5d28bcd216b4388792d1f1ca56305",
    "url": "/stockmoney/json/chip_trust_cols.json"
  },
  {
    "revision": "bcdabfe35882f081f2eb7d5c9f0e5c8b",
    "url": "/stockmoney/json/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json/deal_pct_cols.json"
  },
  {
    "revision": "2631ded3ee9c371e958a5aaad92c91cb",
    "url": "/stockmoney/json/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json/deal_vol_cols.json"
  },
  {
    "revision": "f5fee274d9e24a8acc7eee933fc4d16d",
    "url": "/stockmoney/json/dividend_cont.json"
  },
  {
    "revision": "e98f37eaa810fd912b66473ef4aec297",
    "url": "/stockmoney/json/dividend_cont_cols.json"
  },
  {
    "revision": "d46b7f3cb056a0531cc798a4bc194ddb",
    "url": "/stockmoney/json/dividend_stat.json"
  },
  {
    "revision": "7b46c4ee9490fee469b1dd6e9cead7ea",
    "url": "/stockmoney/json/dividend_stat_2015.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2015_cols.json"
  },
  {
    "revision": "9dc9e7653404fe35351614cc426e0a05",
    "url": "/stockmoney/json/dividend_stat_2016.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2016_cols.json"
  },
  {
    "revision": "64a07dcec42af1d887d8facc88dd1f17",
    "url": "/stockmoney/json/dividend_stat_2017.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2017_cols.json"
  },
  {
    "revision": "c667fbd731d2df0a7b2e8ec4675446d9",
    "url": "/stockmoney/json/dividend_stat_2018.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2018_cols.json"
  },
  {
    "revision": "db776db8b9a98d7176be931a5da92dee",
    "url": "/stockmoney/json/dividend_stat_2019.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2019_cols.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json/dividend_stat_cols.json"
  },
  {
    "revision": "f19f121d230db6dcbe7496b97ac603b0",
    "url": "/stockmoney/json/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json/dividend_yield_cols.json"
  },
  {
    "revision": "5425eb0718e82a9f6ecd6aed6c7d159a",
    "url": "/stockmoney/json/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json/export_director_cols.json"
  },
  {
    "revision": "601389e3c26ed8b928126976fb091810",
    "url": "/stockmoney/json/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json/export_incomerate_cols.json"
  },
  {
    "revision": "fd80ade0865218add52dd9ae05a15427",
    "url": "/stockmoney/json/export_stockfish.json"
  },
  {
    "revision": "32911b54153344868aa71b078b98f046",
    "url": "/stockmoney/json/export_stockfish_cols.json"
  },
  {
    "revision": "19965080d7db700461d3449ca4eb5eab",
    "url": "/stockmoney/json/export_triplerate.json"
  },
  {
    "revision": "a625f25eee5bf1c3f165bc86c455ce79",
    "url": "/stockmoney/json/export_triplerate_cols.json"
  },
  {
    "revision": "33c6d7f296ebe6a9939b740c85ddfdaa",
    "url": "/stockmoney/json/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json/export_water_cols.json"
  },
  {
    "revision": "a1741278e4f00c9866de6db03b0f674d",
    "url": "/stockmoney/json/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json/export_yield_cols.json"
  },
  {
    "revision": "e476b1fd147d7278f3eb6245cf505b88",
    "url": "/stockmoney/json/my_eps.json"
  },
  {
    "revision": "28cd60fb03c2df50655952e1f4c173ac",
    "url": "/stockmoney/json/my_eps_cols.json"
  },
  {
    "revision": "cd030db6dabd85530679a1ecc1345c53",
    "url": "/stockmoney/json/tech_bch.json"
  },
  {
    "revision": "4ceab57a8c9a6cd7e19f2b097e934cc2",
    "url": "/stockmoney/json/tech_bch_cols.json"
  },
  {
    "revision": "48fa2cf791ba947926ec117d6a968a25",
    "url": "/stockmoney/json/tech_beta.json"
  },
  {
    "revision": "8f09f6a30643cd54d5275425bea06c52",
    "url": "/stockmoney/json/tech_beta_cols.json"
  },
  {
    "revision": "c80e2e54ef55d0e9ef4f984a524230b0",
    "url": "/stockmoney/json/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json/tech_kd_cols.json"
  },
  {
    "revision": "b6c4276d43f1c14b0212e8e35ece0407",
    "url": "/stockmoney/json/tech_ma.json"
  },
  {
    "revision": "0312283011ee3335e1c1333e9725ace1",
    "url": "/stockmoney/json/tech_ma_cols.json"
  },
  {
    "revision": "7bec2129ac79cee3a1a6344feae46cc1",
    "url": "/stockmoney/json/triplerate_gross.json"
  },
  {
    "revision": "853fe4b3fba9ce6daf8524185db3099f",
    "url": "/stockmoney/json/triplerate_gross_cols.json"
  },
  {
    "revision": "45a301b7248084bb3bf1334bd6052aa6",
    "url": "/stockmoney/json/triplerate_net.json"
  },
  {
    "revision": "13c0283da8aa6c0e4c627727e52a1227",
    "url": "/stockmoney/json/triplerate_net_cols.json"
  },
  {
    "revision": "354d704ae6e03ef18604f14c052db335",
    "url": "/stockmoney/json/triplerate_opp.json"
  },
  {
    "revision": "744633f1c9fdf1bc186d87aabe2beeab",
    "url": "/stockmoney/json/triplerate_opp_cols.json"
  },
  {
    "revision": "a69a1a0cb34fc051f01f8845b9caaef2",
    "url": "/stockmoney/json/year_eps.json"
  },
  {
    "revision": "79084138066e3517f29bc2f9f397900a",
    "url": "/stockmoney/json/year_eps_cols.json"
  },
  {
    "revision": "c4e29b043dff5742146d085e9ae1629d",
    "url": "/stockmoney/json/year_roe.json"
  },
  {
    "revision": "cc56152991c1268f3d2cd101b817a672",
    "url": "/stockmoney/json/year_roe_cols.json"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json_otc/.dummy"
  },
  {
    "revision": "648574bbadbee72d4889b3c021f95178",
    "url": "/stockmoney/json_otc/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json_otc/basic_4season_cols.json"
  },
  {
    "revision": "0c16b9239a6eb7fc4ebb89e43604c4f7",
    "url": "/stockmoney/json_otc/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json_otc/basic_asset_cols.json"
  },
  {
    "revision": "f36688473f1f161417e8bb019be193a7",
    "url": "/stockmoney/json_otc/basic_cash.json"
  },
  {
    "revision": "a4455971258468d0c645941c9ddb563d",
    "url": "/stockmoney/json_otc/basic_cash_cols.json"
  },
  {
    "revision": "da47ef33a0e1d025f1c92704a16e39a0",
    "url": "/stockmoney/json_otc/basic_debt.json"
  },
  {
    "revision": "2d18c95983a90e358b25f11b7cdb51d7",
    "url": "/stockmoney/json_otc/basic_debt_cols.json"
  },
  {
    "revision": "e623a83837a47b53c6ebf17dc584e5e8",
    "url": "/stockmoney/json_otc/basic_eps.json"
  },
  {
    "revision": "f9a32ef3e725d3ee7e76645ab53c2628",
    "url": "/stockmoney/json_otc/basic_eps_cols.json"
  },
  {
    "revision": "2230223aba0b693e870059fd03e3a485",
    "url": "/stockmoney/json_otc/basic_gross.json"
  },
  {
    "revision": "8be0efd746dc3fdbf94faf89866051bb",
    "url": "/stockmoney/json_otc/basic_gross_cols.json"
  },
  {
    "revision": "68125c43f0528aeb8276dc22d20ed7fd",
    "url": "/stockmoney/json_otc/basic_info.json"
  },
  {
    "revision": "2dbdaa83e5d85419907f0945a8bbb99d",
    "url": "/stockmoney/json_otc/basic_info_cols.json"
  },
  {
    "revision": "029b397c270af5f47cc4b0eafd41d757",
    "url": "/stockmoney/json_otc/basic_noi.json"
  },
  {
    "revision": "8ef7a6a545f6a086fd48ea280b89fa2e",
    "url": "/stockmoney/json_otc/basic_noi_cols.json"
  },
  {
    "revision": "7086233bf516e9d3e32a0d10273a5cea",
    "url": "/stockmoney/json_otc/basic_opm.json"
  },
  {
    "revision": "21b4c262a72b429cdd63698ea32b0b9d",
    "url": "/stockmoney/json_otc/basic_opm_cols.json"
  },
  {
    "revision": "d5c93943ee76d294a9e04773fc79134e",
    "url": "/stockmoney/json_otc/basic_opp.json"
  },
  {
    "revision": "28a853be0f7c102d00719fdb9937c611",
    "url": "/stockmoney/json_otc/basic_opp_cols.json"
  },
  {
    "revision": "916c5f937ba98048f6a7a97e072b4b87",
    "url": "/stockmoney/json_otc/basic_roe.json"
  },
  {
    "revision": "86a08a2769585d71da50eaada0393009",
    "url": "/stockmoney/json_otc/basic_roe_cols.json"
  },
  {
    "revision": "02f8a8cf4bfa49b45457fa149df5201a",
    "url": "/stockmoney/json_otc/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json_otc/basic_yearw_cols.json"
  },
  {
    "revision": "cdfbdd52268a70e092f4f63decb0eb77",
    "url": "/stockmoney/json_otc/chip_director.json"
  },
  {
    "revision": "7c074316cb8303234c453f0eaefa3a2f",
    "url": "/stockmoney/json_otc/chip_director1.json"
  },
  {
    "revision": "f9146b966dfd77db0815d4d76be2f95a",
    "url": "/stockmoney/json_otc/chip_director1_cols.json"
  },
  {
    "revision": "3868091e5572e699dfd19657ebdd357b",
    "url": "/stockmoney/json_otc/chip_director3.json"
  },
  {
    "revision": "2443007c508c710095c9852dcfbcbf90",
    "url": "/stockmoney/json_otc/chip_director3_cols.json"
  },
  {
    "revision": "b13b1225303cb2bb7b35bd26b6be46d7",
    "url": "/stockmoney/json_otc/chip_director5.json"
  },
  {
    "revision": "2899f8c6ca20e9574aeb80f81a52a0d4",
    "url": "/stockmoney/json_otc/chip_director5_cols.json"
  },
  {
    "revision": "51e09fcd7a526fc9bf57bd6136d0da91",
    "url": "/stockmoney/json_otc/chip_director_cols.json"
  },
  {
    "revision": "f5b5f6e2879ddc8837c36c98ac784d5e",
    "url": "/stockmoney/json_otc/chip_legal.json"
  },
  {
    "revision": "d7e02491040240f9cb7da3e58c364e5d",
    "url": "/stockmoney/json_otc/chip_legal_cols.json"
  },
  {
    "revision": "a5a0ed33c4c96af91ae7b8ae07e84901",
    "url": "/stockmoney/json_otc/chip_trust.json"
  },
  {
    "revision": "fecc398de2cf4696c3d156dd0da35961",
    "url": "/stockmoney/json_otc/chip_trust_cols.json"
  },
  {
    "revision": "086398ce9032c4c334cc1d75c5e3043a",
    "url": "/stockmoney/json_otc/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json_otc/deal_pct_cols.json"
  },
  {
    "revision": "cc4894ef204672f3579ff55807611237",
    "url": "/stockmoney/json_otc/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json_otc/deal_vol_cols.json"
  },
  {
    "revision": "c96453a9649fc0813dc02b7b8851f1b6",
    "url": "/stockmoney/json_otc/dividend_cont.json"
  },
  {
    "revision": "e98f37eaa810fd912b66473ef4aec297",
    "url": "/stockmoney/json_otc/dividend_cont_cols.json"
  },
  {
    "revision": "bb0b59018f8badcda42df1ced13b4ae2",
    "url": "/stockmoney/json_otc/dividend_stat.json"
  },
  {
    "revision": "21c6d862c4542447ccccfd08ff51bce9",
    "url": "/stockmoney/json_otc/dividend_stat_2015.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2015_cols.json"
  },
  {
    "revision": "d6c9d1101ef9f25794f0467f67dd9a17",
    "url": "/stockmoney/json_otc/dividend_stat_2016.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2016_cols.json"
  },
  {
    "revision": "531e4b866bc78364065f34d415dc117f",
    "url": "/stockmoney/json_otc/dividend_stat_2017.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2017_cols.json"
  },
  {
    "revision": "96fb1225ec93dfa7421a9d369ee8de90",
    "url": "/stockmoney/json_otc/dividend_stat_2018.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2018_cols.json"
  },
  {
    "revision": "2c47c220e75f515787167b98f504246d",
    "url": "/stockmoney/json_otc/dividend_stat_2019.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2019_cols.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json_otc/dividend_stat_cols.json"
  },
  {
    "revision": "64650da6c521d5702a6b16b6f0a61953",
    "url": "/stockmoney/json_otc/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json_otc/dividend_yield_cols.json"
  },
  {
    "revision": "1b2ca5018737516a13ef54f882935b72",
    "url": "/stockmoney/json_otc/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json_otc/export_director_cols.json"
  },
  {
    "revision": "5f819f02079a89578afb20b44ef7e545",
    "url": "/stockmoney/json_otc/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json_otc/export_incomerate_cols.json"
  },
  {
    "revision": "d1930ce2324052911cbd4d0ce0f0acfe",
    "url": "/stockmoney/json_otc/export_stockfish.json"
  },
  {
    "revision": "32911b54153344868aa71b078b98f046",
    "url": "/stockmoney/json_otc/export_stockfish_cols.json"
  },
  {
    "revision": "693e6eab771df8b2bf173b6923187c87",
    "url": "/stockmoney/json_otc/export_triplerate.json"
  },
  {
    "revision": "a625f25eee5bf1c3f165bc86c455ce79",
    "url": "/stockmoney/json_otc/export_triplerate_cols.json"
  },
  {
    "revision": "8b9b0fdbab35fb42587052af8f279f18",
    "url": "/stockmoney/json_otc/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json_otc/export_water_cols.json"
  },
  {
    "revision": "495167dc4674a4ac6d6d8d5038dbef97",
    "url": "/stockmoney/json_otc/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json_otc/export_yield_cols.json"
  },
  {
    "revision": "da20246a29f6c6a5e3482fc8b1b2451c",
    "url": "/stockmoney/json_otc/my_eps.json"
  },
  {
    "revision": "28cd60fb03c2df50655952e1f4c173ac",
    "url": "/stockmoney/json_otc/my_eps_cols.json"
  },
  {
    "revision": "b31f07643298f08361b6805d66ddf903",
    "url": "/stockmoney/json_otc/tech_bch.json"
  },
  {
    "revision": "4ceab57a8c9a6cd7e19f2b097e934cc2",
    "url": "/stockmoney/json_otc/tech_bch_cols.json"
  },
  {
    "revision": "7f4560c58c8d9454e3c1e1c8fe2dadfc",
    "url": "/stockmoney/json_otc/tech_beta.json"
  },
  {
    "revision": "4bb937eaf819207728fd1032030d72a4",
    "url": "/stockmoney/json_otc/tech_beta_cols.json"
  },
  {
    "revision": "603f111540760c5ae860cdc22390ec78",
    "url": "/stockmoney/json_otc/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json_otc/tech_kd_cols.json"
  },
  {
    "revision": "0312283011ee3335e1c1333e9725ace1",
    "url": "/stockmoney/json_otc/tech_ma_cols.json"
  },
  {
    "revision": "e26474cfa7adf795eaadb9175d8741ed",
    "url": "/stockmoney/json_otc/triplerate_gross.json"
  },
  {
    "revision": "a4d65c83681155bd962581c6667564a0",
    "url": "/stockmoney/json_otc/triplerate_gross_cols.json"
  },
  {
    "revision": "08b904b7c781c1257bf511556553063d",
    "url": "/stockmoney/json_otc/triplerate_net.json"
  },
  {
    "revision": "50b759261adf373bb576af0f2882b4d2",
    "url": "/stockmoney/json_otc/triplerate_net_cols.json"
  },
  {
    "revision": "abde9f31bbe7724e679ab90ae4d8ffb6",
    "url": "/stockmoney/json_otc/triplerate_opp.json"
  },
  {
    "revision": "0c78ca0d35d4faf6548260a0c26a3797",
    "url": "/stockmoney/json_otc/triplerate_opp_cols.json"
  },
  {
    "revision": "799fd8738aad33dca54c18ff2d50115c",
    "url": "/stockmoney/json_otc/year_eps.json"
  },
  {
    "revision": "d0e50d5c0d38cf143a3664f74ac1e585",
    "url": "/stockmoney/json_otc/year_eps_cols.json"
  },
  {
    "revision": "904b7d4e1737cc1bb5a925b108c55d01",
    "url": "/stockmoney/json_otc/year_roe.json"
  },
  {
    "revision": "9a071d5d69651297aaf6a7ba816b18c8",
    "url": "/stockmoney/json_otc/year_roe_cols.json"
  },
  {
    "revision": "b96e0d5a5df171b63ae60164bac0e3af",
    "url": "/stockmoney/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/stockmoney/robots.txt"
  },
  {
    "revision": "db476e39070b98ed6e92",
    "url": "/stockmoney/static/css/app.4956b565.css"
  },
  {
    "revision": "00a14ddebf3604813825",
    "url": "/stockmoney/static/css/chunk-vendors.eae4093c.css"
  },
  {
    "revision": "ecb3bfc03db10b6f9d6e23e710d5c953",
    "url": "/stockmoney/static/img/logo.ecb3bfc0.png"
  },
  {
    "revision": "85ce6e4334a2eeb8390e",
    "url": "/stockmoney/static/js/about.3644c617.js"
  },
  {
    "revision": "db476e39070b98ed6e92",
    "url": "/stockmoney/static/js/app.7e9511d9.js"
  },
  {
    "revision": "00a14ddebf3604813825",
    "url": "/stockmoney/static/js/chunk-vendors.2d8e5b65.js"
  }
]);