self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "919e6eb777af7b96b71e4e9e7087d955",
    "url": "/stockmoney/index.html"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json/.dummy"
  },
  {
    "revision": "1fc6710b1c44a60027758013f0a4c7c0",
    "url": "/stockmoney/json/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json/basic_4season_cols.json"
  },
  {
    "revision": "c3559243b0f4bb011bd22168398b0eef",
    "url": "/stockmoney/json/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json/basic_asset_cols.json"
  },
  {
    "revision": "8b8b69b35680b06d5c739f2112d1ce33",
    "url": "/stockmoney/json/basic_cash.json"
  },
  {
    "revision": "03366738ade78149313398c17e2b3a98",
    "url": "/stockmoney/json/basic_cash_cols.json"
  },
  {
    "revision": "b7a3af6bc7caa57685f9fb26a273d2aa",
    "url": "/stockmoney/json/basic_debt.json"
  },
  {
    "revision": "7cf33f130b4c16dec6b7cf372d55b6c5",
    "url": "/stockmoney/json/basic_debt_cols.json"
  },
  {
    "revision": "64ba173d85b319490c97f4599487cf9f",
    "url": "/stockmoney/json/basic_eps.json"
  },
  {
    "revision": "587a3836bc6f9d6cfadb884eada71c7e",
    "url": "/stockmoney/json/basic_eps_cols.json"
  },
  {
    "revision": "7def5c1e4449a28def6849014f148ec1",
    "url": "/stockmoney/json/basic_gross.json"
  },
  {
    "revision": "c58a3d49a51e6bd4e8e34391b3d63c8a",
    "url": "/stockmoney/json/basic_gross_cols.json"
  },
  {
    "revision": "bc60f1b9cce0b791314daeb991ef2cea",
    "url": "/stockmoney/json/basic_info.json"
  },
  {
    "revision": "2dbdaa83e5d85419907f0945a8bbb99d",
    "url": "/stockmoney/json/basic_info_cols.json"
  },
  {
    "revision": "4940aad4d034d33863f9b8fc72186c2c",
    "url": "/stockmoney/json/basic_noi.json"
  },
  {
    "revision": "4d85422361c13d085f9bd6acc34cf44c",
    "url": "/stockmoney/json/basic_noi_cols.json"
  },
  {
    "revision": "4b52447aa0a92f216f447ab42d7be7df",
    "url": "/stockmoney/json/basic_opm.json"
  },
  {
    "revision": "23876ba79105d97ffaee9f9342d7dd6a",
    "url": "/stockmoney/json/basic_opm_cols.json"
  },
  {
    "revision": "7d54348f3f738ff1e77db5abc79f551b",
    "url": "/stockmoney/json/basic_opp.json"
  },
  {
    "revision": "cd5e1981364e5ab21acb32ee82608e2d",
    "url": "/stockmoney/json/basic_opp_cols.json"
  },
  {
    "revision": "1f7f90dffd09a9292a244e2b679fcbae",
    "url": "/stockmoney/json/basic_roe.json"
  },
  {
    "revision": "85d4d37bd034934f337afa69f77fb0c1",
    "url": "/stockmoney/json/basic_roe_cols.json"
  },
  {
    "revision": "aa11da17d8a50373431eef755729ec7b",
    "url": "/stockmoney/json/basic_rvn.json"
  },
  {
    "revision": "b72c43c0d922029b7aa6122b7ddfdfc6",
    "url": "/stockmoney/json/basic_rvn_cols.json"
  },
  {
    "revision": "57ac7b065f89e2c59b5dce28dd12e1f7",
    "url": "/stockmoney/json/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json/basic_yearw_cols.json"
  },
  {
    "revision": "0acd44365b747644f6f33c75658f83ac",
    "url": "/stockmoney/json/chip_director.json"
  },
  {
    "revision": "2c4787978576eb6c0499e51818437962",
    "url": "/stockmoney/json/chip_director1.json"
  },
  {
    "revision": "9245b933efe32254018a0a6e9a6c8613",
    "url": "/stockmoney/json/chip_director1_cols.json"
  },
  {
    "revision": "c4d4f6ad27815682372c5295e4f4f519",
    "url": "/stockmoney/json/chip_director3.json"
  },
  {
    "revision": "b856d752ee7572bba69b5bfefbe9e41b",
    "url": "/stockmoney/json/chip_director3_cols.json"
  },
  {
    "revision": "c001934ccf77b58a9a28cc929eb9cc6e",
    "url": "/stockmoney/json/chip_director5.json"
  },
  {
    "revision": "825ba91683006403a96e4ead7ebc2e2c",
    "url": "/stockmoney/json/chip_director5_cols.json"
  },
  {
    "revision": "9bbbf6600d4c03482470ae7a8ed48118",
    "url": "/stockmoney/json/chip_director_cols.json"
  },
  {
    "revision": "923ff2700c3a4924e12c9aa3e61ea15c",
    "url": "/stockmoney/json/chip_legal.json"
  },
  {
    "revision": "d7e02491040240f9cb7da3e58c364e5d",
    "url": "/stockmoney/json/chip_legal_cols.json"
  },
  {
    "revision": "b80afdd7fb55edaa3f461111a5afbcc6",
    "url": "/stockmoney/json/chip_trust.json"
  },
  {
    "revision": "5fd5d28bcd216b4388792d1f1ca56305",
    "url": "/stockmoney/json/chip_trust_cols.json"
  },
  {
    "revision": "12b1403e9a71b0c65f0e91acbbaf90b3",
    "url": "/stockmoney/json/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json/deal_pct_cols.json"
  },
  {
    "revision": "42b075ff1831a444bf643c9ce2ab9942",
    "url": "/stockmoney/json/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json/deal_vol_cols.json"
  },
  {
    "revision": "26d1eaa64b4418bf1d9ae7c8f7e48458",
    "url": "/stockmoney/json/dividend_cont.json"
  },
  {
    "revision": "e98f37eaa810fd912b66473ef4aec297",
    "url": "/stockmoney/json/dividend_cont_cols.json"
  },
  {
    "revision": "2f3f234fe7f2d12e1a3b660223fe2669",
    "url": "/stockmoney/json/dividend_stat.json"
  },
  {
    "revision": "7b46c4ee9490fee469b1dd6e9cead7ea",
    "url": "/stockmoney/json/dividend_stat_2015.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2015_cols.json"
  },
  {
    "revision": "9dc9e7653404fe35351614cc426e0a05",
    "url": "/stockmoney/json/dividend_stat_2016.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2016_cols.json"
  },
  {
    "revision": "64a07dcec42af1d887d8facc88dd1f17",
    "url": "/stockmoney/json/dividend_stat_2017.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2017_cols.json"
  },
  {
    "revision": "c667fbd731d2df0a7b2e8ec4675446d9",
    "url": "/stockmoney/json/dividend_stat_2018.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2018_cols.json"
  },
  {
    "revision": "db776db8b9a98d7176be931a5da92dee",
    "url": "/stockmoney/json/dividend_stat_2019.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2019_cols.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json/dividend_stat_cols.json"
  },
  {
    "revision": "eb5c646fc321d4ef0921e4039c31201f",
    "url": "/stockmoney/json/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json/dividend_yield_cols.json"
  },
  {
    "revision": "9d5f36b3361c7e8ef950d0d7e7efe1c2",
    "url": "/stockmoney/json/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json/export_director_cols.json"
  },
  {
    "revision": "671eabc6c2eda8b28b06eb7b9ff573f1",
    "url": "/stockmoney/json/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json/export_incomerate_cols.json"
  },
  {
    "revision": "eca4df06ab90f2032e25f2311cc96498",
    "url": "/stockmoney/json/export_stockfish.json"
  },
  {
    "revision": "aa76bf1d9931072a3fe9c3e216868eac",
    "url": "/stockmoney/json/export_stockfish_cols.json"
  },
  {
    "revision": "d7defe94c09ed3d7ca6e5e28fe41899a",
    "url": "/stockmoney/json/export_triplerate.json"
  },
  {
    "revision": "a625f25eee5bf1c3f165bc86c455ce79",
    "url": "/stockmoney/json/export_triplerate_cols.json"
  },
  {
    "revision": "ab1dca3458375868519c0c6d9680c8f9",
    "url": "/stockmoney/json/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json/export_water_cols.json"
  },
  {
    "revision": "a1741278e4f00c9866de6db03b0f674d",
    "url": "/stockmoney/json/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json/export_yield_cols.json"
  },
  {
    "revision": "ffa785ae8a73d337c5d2317439b93f1e",
    "url": "/stockmoney/json/my_eps.json"
  },
  {
    "revision": "87b98bb7ccff2628d43fe83db7362e93",
    "url": "/stockmoney/json/my_eps_cols.json"
  },
  {
    "revision": "2843ec94485121548a45f917b429169b",
    "url": "/stockmoney/json/tech_bch.json"
  },
  {
    "revision": "4ceab57a8c9a6cd7e19f2b097e934cc2",
    "url": "/stockmoney/json/tech_bch_cols.json"
  },
  {
    "revision": "fb4a118bc45f2a32ada91f2435741eaa",
    "url": "/stockmoney/json/tech_beta.json"
  },
  {
    "revision": "8f09f6a30643cd54d5275425bea06c52",
    "url": "/stockmoney/json/tech_beta_cols.json"
  },
  {
    "revision": "daa23e17d33b27715f2d20193fdd93fc",
    "url": "/stockmoney/json/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json/tech_kd_cols.json"
  },
  {
    "revision": "13644d3019c847d13e2344015148c099",
    "url": "/stockmoney/json/tech_ma.json"
  },
  {
    "revision": "0312283011ee3335e1c1333e9725ace1",
    "url": "/stockmoney/json/tech_ma_cols.json"
  },
  {
    "revision": "e90d707eb5dd151f505bb5ccf92fa12b",
    "url": "/stockmoney/json/triplerate_gross.json"
  },
  {
    "revision": "f187f31a3cf9a0f7f23fd4ef6e929bbb",
    "url": "/stockmoney/json/triplerate_gross_cols.json"
  },
  {
    "revision": "4082d386afb243185be6efb79b4174be",
    "url": "/stockmoney/json/triplerate_net.json"
  },
  {
    "revision": "1e6ba9421da78bcdaa2562ba1ee5b9ce",
    "url": "/stockmoney/json/triplerate_net_cols.json"
  },
  {
    "revision": "64d45933a5ad442f71f534e3be4600b6",
    "url": "/stockmoney/json/triplerate_opp.json"
  },
  {
    "revision": "c0b894f81b456245516216f770a04f8d",
    "url": "/stockmoney/json/triplerate_opp_cols.json"
  },
  {
    "revision": "775f6e25cc923af13fa093d65c6c1bf3",
    "url": "/stockmoney/json/year_eps.json"
  },
  {
    "revision": "5cea8ac811397ff60594e76537b7d0f8",
    "url": "/stockmoney/json/year_eps_cols.json"
  },
  {
    "revision": "5012504aa429ce279fbf395dce178a38",
    "url": "/stockmoney/json/year_roe.json"
  },
  {
    "revision": "ddd33b8c50c05299aaa7b2d15c0bcefa",
    "url": "/stockmoney/json/year_roe_cols.json"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json_otc/.dummy"
  },
  {
    "revision": "68ca5410900bc476bc6ea54fc15b6782",
    "url": "/stockmoney/json_otc/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json_otc/basic_4season_cols.json"
  },
  {
    "revision": "bbd9172fee63bc0e0f13590cc6e98fa9",
    "url": "/stockmoney/json_otc/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json_otc/basic_asset_cols.json"
  },
  {
    "revision": "fc95ebdc9fe7873c86a1dc75d54faa1a",
    "url": "/stockmoney/json_otc/basic_cash.json"
  },
  {
    "revision": "8dffa07bdbc96feb13f995c845f79b54",
    "url": "/stockmoney/json_otc/basic_cash_cols.json"
  },
  {
    "revision": "122bf5f5fdc9bdc69f873b8810449629",
    "url": "/stockmoney/json_otc/basic_debt.json"
  },
  {
    "revision": "0c2de58f483220d71fa234c1766dbed7",
    "url": "/stockmoney/json_otc/basic_debt_cols.json"
  },
  {
    "revision": "af971f29500902ba182d2c399be5ee89",
    "url": "/stockmoney/json_otc/basic_eps.json"
  },
  {
    "revision": "37c5f5a5af4c6dac9153291052d4f950",
    "url": "/stockmoney/json_otc/basic_eps_cols.json"
  },
  {
    "revision": "427afe3df1ca815cef0eb12dd557e9f6",
    "url": "/stockmoney/json_otc/basic_gross.json"
  },
  {
    "revision": "c86e6c148d6e84cdd381a9df3c7ed777",
    "url": "/stockmoney/json_otc/basic_gross_cols.json"
  },
  {
    "revision": "011b06639200be8fd68cce056b450e9b",
    "url": "/stockmoney/json_otc/basic_info.json"
  },
  {
    "revision": "2dbdaa83e5d85419907f0945a8bbb99d",
    "url": "/stockmoney/json_otc/basic_info_cols.json"
  },
  {
    "revision": "69af310079baa8f577c7cd2b84d5e5b6",
    "url": "/stockmoney/json_otc/basic_noi.json"
  },
  {
    "revision": "48ecde3e8d3c005cecc5b62a6c7c8408",
    "url": "/stockmoney/json_otc/basic_noi_cols.json"
  },
  {
    "revision": "aade13eae343b83071b589de16e7d8ab",
    "url": "/stockmoney/json_otc/basic_opm.json"
  },
  {
    "revision": "cf69411cdbc8ab426b8c2f728c0012ed",
    "url": "/stockmoney/json_otc/basic_opm_cols.json"
  },
  {
    "revision": "397288231e483754af9861fce2dd96f9",
    "url": "/stockmoney/json_otc/basic_opp.json"
  },
  {
    "revision": "aae157c727380c2fa2ad5ed6bdfcd46e",
    "url": "/stockmoney/json_otc/basic_opp_cols.json"
  },
  {
    "revision": "b5a39c61b079e8033bc085b11abc53ec",
    "url": "/stockmoney/json_otc/basic_roe.json"
  },
  {
    "revision": "ea97c6b7b81ae152893c2d235fecc2f4",
    "url": "/stockmoney/json_otc/basic_roe_cols.json"
  },
  {
    "revision": "1c1201abcc20b54f8c2f607caccb1a51",
    "url": "/stockmoney/json_otc/basic_rvn.json"
  },
  {
    "revision": "b72c43c0d922029b7aa6122b7ddfdfc6",
    "url": "/stockmoney/json_otc/basic_rvn_cols.json"
  },
  {
    "revision": "5085221da6fac8eaf09f646966689b75",
    "url": "/stockmoney/json_otc/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json_otc/basic_yearw_cols.json"
  },
  {
    "revision": "e88a2dbaff3a98a88343ab7e5ae531b6",
    "url": "/stockmoney/json_otc/chip_director.json"
  },
  {
    "revision": "5e8b5fbb62db084f28f1cdc7bc25fd36",
    "url": "/stockmoney/json_otc/chip_director1.json"
  },
  {
    "revision": "f9146b966dfd77db0815d4d76be2f95a",
    "url": "/stockmoney/json_otc/chip_director1_cols.json"
  },
  {
    "revision": "0d2d9b1e503b91c71416c13cb5bf1a9f",
    "url": "/stockmoney/json_otc/chip_director3.json"
  },
  {
    "revision": "2443007c508c710095c9852dcfbcbf90",
    "url": "/stockmoney/json_otc/chip_director3_cols.json"
  },
  {
    "revision": "6b50827a97837d2bdc543df3a798c496",
    "url": "/stockmoney/json_otc/chip_director5.json"
  },
  {
    "revision": "2899f8c6ca20e9574aeb80f81a52a0d4",
    "url": "/stockmoney/json_otc/chip_director5_cols.json"
  },
  {
    "revision": "51e09fcd7a526fc9bf57bd6136d0da91",
    "url": "/stockmoney/json_otc/chip_director_cols.json"
  },
  {
    "revision": "33bdf8b5eb29f7b97c63b693ec02a515",
    "url": "/stockmoney/json_otc/chip_legal.json"
  },
  {
    "revision": "d7e02491040240f9cb7da3e58c364e5d",
    "url": "/stockmoney/json_otc/chip_legal_cols.json"
  },
  {
    "revision": "b68a87aeb539aecca5460ff8557c49bd",
    "url": "/stockmoney/json_otc/chip_trust.json"
  },
  {
    "revision": "fecc398de2cf4696c3d156dd0da35961",
    "url": "/stockmoney/json_otc/chip_trust_cols.json"
  },
  {
    "revision": "37d7c5b22028528a80061f8c90360e86",
    "url": "/stockmoney/json_otc/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json_otc/deal_pct_cols.json"
  },
  {
    "revision": "61de932f493d67b80f014ac725f41759",
    "url": "/stockmoney/json_otc/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json_otc/deal_vol_cols.json"
  },
  {
    "revision": "9fac59a02ef5a42c898fb5407b3e7fdf",
    "url": "/stockmoney/json_otc/dividend_cont.json"
  },
  {
    "revision": "e98f37eaa810fd912b66473ef4aec297",
    "url": "/stockmoney/json_otc/dividend_cont_cols.json"
  },
  {
    "revision": "67a56ffbfd81e5e660f478aa1d9016b9",
    "url": "/stockmoney/json_otc/dividend_stat.json"
  },
  {
    "revision": "21c6d862c4542447ccccfd08ff51bce9",
    "url": "/stockmoney/json_otc/dividend_stat_2015.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2015_cols.json"
  },
  {
    "revision": "d6c9d1101ef9f25794f0467f67dd9a17",
    "url": "/stockmoney/json_otc/dividend_stat_2016.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2016_cols.json"
  },
  {
    "revision": "531e4b866bc78364065f34d415dc117f",
    "url": "/stockmoney/json_otc/dividend_stat_2017.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2017_cols.json"
  },
  {
    "revision": "96fb1225ec93dfa7421a9d369ee8de90",
    "url": "/stockmoney/json_otc/dividend_stat_2018.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2018_cols.json"
  },
  {
    "revision": "2c47c220e75f515787167b98f504246d",
    "url": "/stockmoney/json_otc/dividend_stat_2019.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2019_cols.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json_otc/dividend_stat_cols.json"
  },
  {
    "revision": "b5f43a164887fcbd1ad8db5a48cb7476",
    "url": "/stockmoney/json_otc/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json_otc/dividend_yield_cols.json"
  },
  {
    "revision": "824a4e983ea8ca12e485c8dfacf28efc",
    "url": "/stockmoney/json_otc/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json_otc/export_director_cols.json"
  },
  {
    "revision": "5f4215d905687e47c3f1fc9a39aabb39",
    "url": "/stockmoney/json_otc/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json_otc/export_incomerate_cols.json"
  },
  {
    "revision": "a4808022208c1627beafb4ae386aa062",
    "url": "/stockmoney/json_otc/export_stockfish.json"
  },
  {
    "revision": "aa76bf1d9931072a3fe9c3e216868eac",
    "url": "/stockmoney/json_otc/export_stockfish_cols.json"
  },
  {
    "revision": "bd4f21576150de3c996125391235a2c1",
    "url": "/stockmoney/json_otc/export_triplerate.json"
  },
  {
    "revision": "a625f25eee5bf1c3f165bc86c455ce79",
    "url": "/stockmoney/json_otc/export_triplerate_cols.json"
  },
  {
    "revision": "47178c99616accea4d0eb6d8efc19440",
    "url": "/stockmoney/json_otc/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json_otc/export_water_cols.json"
  },
  {
    "revision": "0aa04dfa9008172e96bc8f56666fd828",
    "url": "/stockmoney/json_otc/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json_otc/export_yield_cols.json"
  },
  {
    "revision": "178ae2adad8a98584511487f46e71d7c",
    "url": "/stockmoney/json_otc/my_eps.json"
  },
  {
    "revision": "87b98bb7ccff2628d43fe83db7362e93",
    "url": "/stockmoney/json_otc/my_eps_cols.json"
  },
  {
    "revision": "fed3eeff70d45316a7678b0480ea9d90",
    "url": "/stockmoney/json_otc/tech_bch.json"
  },
  {
    "revision": "4ceab57a8c9a6cd7e19f2b097e934cc2",
    "url": "/stockmoney/json_otc/tech_bch_cols.json"
  },
  {
    "revision": "14cdb57a0f50ddfe62fe1208cfd968cc",
    "url": "/stockmoney/json_otc/tech_beta.json"
  },
  {
    "revision": "4bb937eaf819207728fd1032030d72a4",
    "url": "/stockmoney/json_otc/tech_beta_cols.json"
  },
  {
    "revision": "3461cec06dd6f774d5f53e0b8e66fdf0",
    "url": "/stockmoney/json_otc/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json_otc/tech_kd_cols.json"
  },
  {
    "revision": "e4cd97a1ee2a5f83252854da2fe8dd3b",
    "url": "/stockmoney/json_otc/tech_ma.json"
  },
  {
    "revision": "0312283011ee3335e1c1333e9725ace1",
    "url": "/stockmoney/json_otc/tech_ma_cols.json"
  },
  {
    "revision": "9e7686f16777b8cde4ea2c4ed5ffc26f",
    "url": "/stockmoney/json_otc/triplerate_gross.json"
  },
  {
    "revision": "c85cbcdef5d0c1714dedf901fc4c5120",
    "url": "/stockmoney/json_otc/triplerate_gross_cols.json"
  },
  {
    "revision": "ec965f4086c99d3401a52d93228f0ad5",
    "url": "/stockmoney/json_otc/triplerate_net.json"
  },
  {
    "revision": "41c7f74f012fc1a891cbf638cabaa4ee",
    "url": "/stockmoney/json_otc/triplerate_net_cols.json"
  },
  {
    "revision": "619203e9f251cbe414957cd7aba66c80",
    "url": "/stockmoney/json_otc/triplerate_opp.json"
  },
  {
    "revision": "59d12bf575d6213707074ce34138062d",
    "url": "/stockmoney/json_otc/triplerate_opp_cols.json"
  },
  {
    "revision": "90d550076fa6263825adb444b4ca01da",
    "url": "/stockmoney/json_otc/year_eps.json"
  },
  {
    "revision": "9f5f79b919caf1f78bfdf838a4369b96",
    "url": "/stockmoney/json_otc/year_eps_cols.json"
  },
  {
    "revision": "75d839173afc58d8a93a416759a27d57",
    "url": "/stockmoney/json_otc/year_roe.json"
  },
  {
    "revision": "6c7cf7f11183576150927da975c2f5de",
    "url": "/stockmoney/json_otc/year_roe_cols.json"
  },
  {
    "revision": "b96e0d5a5df171b63ae60164bac0e3af",
    "url": "/stockmoney/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/stockmoney/robots.txt"
  },
  {
    "revision": "2f482e79c1f322afc903",
    "url": "/stockmoney/static/css/app.62200570.css"
  },
  {
    "revision": "00a14ddebf3604813825",
    "url": "/stockmoney/static/css/chunk-vendors.eae4093c.css"
  },
  {
    "revision": "ecb3bfc03db10b6f9d6e23e710d5c953",
    "url": "/stockmoney/static/img/logo.ecb3bfc0.png"
  },
  {
    "revision": "85ce6e4334a2eeb8390e",
    "url": "/stockmoney/static/js/about.3644c617.js"
  },
  {
    "revision": "2f482e79c1f322afc903",
    "url": "/stockmoney/static/js/app.acdf79bc.js"
  },
  {
    "revision": "00a14ddebf3604813825",
    "url": "/stockmoney/static/js/chunk-vendors.2d8e5b65.js"
  }
]);