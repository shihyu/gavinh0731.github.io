self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "daa572a986082e1676ac48823a0a5b4a",
    "url": "/stockmoney/index.html"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json/.dummy"
  },
  {
    "revision": "9d45e4adce9a9ae8da7c93873f74a28f",
    "url": "/stockmoney/json/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json/basic_4season_cols.json"
  },
  {
    "revision": "243ea2762b75be69083c6bd4d4fdec10",
    "url": "/stockmoney/json/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json/basic_asset_cols.json"
  },
  {
    "revision": "9622fa6eddef315466768124d66f2660",
    "url": "/stockmoney/json/basic_cash.json"
  },
  {
    "revision": "31dabccaf0a209c3711d396106de6f78",
    "url": "/stockmoney/json/basic_cash_cols.json"
  },
  {
    "revision": "ab59cbf341aff49d34f8c60525b6fa51",
    "url": "/stockmoney/json/basic_debt.json"
  },
  {
    "revision": "3c43c47b1900fd69e6cfff2fbfe533d7",
    "url": "/stockmoney/json/basic_debt_cols.json"
  },
  {
    "revision": "ded41bdf831834b8a13b98ceb158a0bc",
    "url": "/stockmoney/json/basic_eps.json"
  },
  {
    "revision": "8812e9086012ad531f689ab85befb867",
    "url": "/stockmoney/json/basic_eps_cols.json"
  },
  {
    "revision": "259f48449978e645236d46d49c00a545",
    "url": "/stockmoney/json/basic_gross.json"
  },
  {
    "revision": "043bde7a220875da39229ce2ee42a9ff",
    "url": "/stockmoney/json/basic_gross_cols.json"
  },
  {
    "revision": "34639ae4de89d4edade4eeafd05b595b",
    "url": "/stockmoney/json/basic_info.json"
  },
  {
    "revision": "2dbdaa83e5d85419907f0945a8bbb99d",
    "url": "/stockmoney/json/basic_info_cols.json"
  },
  {
    "revision": "1ee05e3815922215d6837073acca69c1",
    "url": "/stockmoney/json/basic_noi.json"
  },
  {
    "revision": "27b34f9118420ce2a7f35294ea5c6b8d",
    "url": "/stockmoney/json/basic_noi_cols.json"
  },
  {
    "revision": "21e6390b06a07ad80a919b97bba7a416",
    "url": "/stockmoney/json/basic_opm.json"
  },
  {
    "revision": "0265e3d79d2361495191c2e418767be5",
    "url": "/stockmoney/json/basic_opm_cols.json"
  },
  {
    "revision": "1d02ed99aadd00eba1e0c924389cb915",
    "url": "/stockmoney/json/basic_opp.json"
  },
  {
    "revision": "fa7a647763c1550c5aaed832eea1685a",
    "url": "/stockmoney/json/basic_opp_cols.json"
  },
  {
    "revision": "dab1c020110e2bae238c3256455c7eb1",
    "url": "/stockmoney/json/basic_roe.json"
  },
  {
    "revision": "007e4b5fa456822f98fec85aef8114a2",
    "url": "/stockmoney/json/basic_roe_cols.json"
  },
  {
    "revision": "2aceafbf5ebe2d449afeba718d4ec80c",
    "url": "/stockmoney/json/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json/basic_yearw_cols.json"
  },
  {
    "revision": "219bebda9ed4adfabc4145f543b40eba",
    "url": "/stockmoney/json/chip_director.json"
  },
  {
    "revision": "03942d5f326141bb04fd5e876d60ce8f",
    "url": "/stockmoney/json/chip_director1.json"
  },
  {
    "revision": "9245b933efe32254018a0a6e9a6c8613",
    "url": "/stockmoney/json/chip_director1_cols.json"
  },
  {
    "revision": "4cf552e8040e048cbc075080d746748b",
    "url": "/stockmoney/json/chip_director3.json"
  },
  {
    "revision": "b856d752ee7572bba69b5bfefbe9e41b",
    "url": "/stockmoney/json/chip_director3_cols.json"
  },
  {
    "revision": "4ef16c8e102b72ace097a46bdcafa243",
    "url": "/stockmoney/json/chip_director5.json"
  },
  {
    "revision": "825ba91683006403a96e4ead7ebc2e2c",
    "url": "/stockmoney/json/chip_director5_cols.json"
  },
  {
    "revision": "9bbbf6600d4c03482470ae7a8ed48118",
    "url": "/stockmoney/json/chip_director_cols.json"
  },
  {
    "revision": "5da7b57fb6478089c7cbd48462d650ae",
    "url": "/stockmoney/json/chip_legal.json"
  },
  {
    "revision": "d7e02491040240f9cb7da3e58c364e5d",
    "url": "/stockmoney/json/chip_legal_cols.json"
  },
  {
    "revision": "9f68074e1eba76d3eb9da174dd17006b",
    "url": "/stockmoney/json/chip_trust.json"
  },
  {
    "revision": "5fd5d28bcd216b4388792d1f1ca56305",
    "url": "/stockmoney/json/chip_trust_cols.json"
  },
  {
    "revision": "07f5f305249db678bd7edddfffa2063a",
    "url": "/stockmoney/json/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json/deal_pct_cols.json"
  },
  {
    "revision": "4ea5c733a9a1519ed672000eb830b53d",
    "url": "/stockmoney/json/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json/deal_vol_cols.json"
  },
  {
    "revision": "83c66c0c3b1abd6161906c298fb726ce",
    "url": "/stockmoney/json/dividend_cont.json"
  },
  {
    "revision": "e98f37eaa810fd912b66473ef4aec297",
    "url": "/stockmoney/json/dividend_cont_cols.json"
  },
  {
    "revision": "0f54d7d2ff92c05a05240d3306026f22",
    "url": "/stockmoney/json/dividend_stat.json"
  },
  {
    "revision": "7b46c4ee9490fee469b1dd6e9cead7ea",
    "url": "/stockmoney/json/dividend_stat_2015.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2015_cols.json"
  },
  {
    "revision": "9dc9e7653404fe35351614cc426e0a05",
    "url": "/stockmoney/json/dividend_stat_2016.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2016_cols.json"
  },
  {
    "revision": "64a07dcec42af1d887d8facc88dd1f17",
    "url": "/stockmoney/json/dividend_stat_2017.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2017_cols.json"
  },
  {
    "revision": "c667fbd731d2df0a7b2e8ec4675446d9",
    "url": "/stockmoney/json/dividend_stat_2018.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2018_cols.json"
  },
  {
    "revision": "db776db8b9a98d7176be931a5da92dee",
    "url": "/stockmoney/json/dividend_stat_2019.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2019_cols.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json/dividend_stat_cols.json"
  },
  {
    "revision": "03d84bc6e5377312fc6837d8a5a2953b",
    "url": "/stockmoney/json/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json/dividend_yield_cols.json"
  },
  {
    "revision": "851ebaac4aa3a04d3885c6eaaeb7b23b",
    "url": "/stockmoney/json/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json/export_director_cols.json"
  },
  {
    "revision": "c7a9bdded05d3c32fdde088272df6c06",
    "url": "/stockmoney/json/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json/export_incomerate_cols.json"
  },
  {
    "revision": "f2f85b898c3f64205d2033dbbcd5c083",
    "url": "/stockmoney/json/export_stockfish.json"
  },
  {
    "revision": "32911b54153344868aa71b078b98f046",
    "url": "/stockmoney/json/export_stockfish_cols.json"
  },
  {
    "revision": "27d1ba127c25c6b0e20543ed46eaff9c",
    "url": "/stockmoney/json/export_triplerate.json"
  },
  {
    "revision": "a625f25eee5bf1c3f165bc86c455ce79",
    "url": "/stockmoney/json/export_triplerate_cols.json"
  },
  {
    "revision": "9e49999ff6fe66ba834da6e8611c5671",
    "url": "/stockmoney/json/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json/export_water_cols.json"
  },
  {
    "revision": "a1741278e4f00c9866de6db03b0f674d",
    "url": "/stockmoney/json/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json/export_yield_cols.json"
  },
  {
    "revision": "a3a2a4d408c739450101b315a205fe3a",
    "url": "/stockmoney/json/my_eps.json"
  },
  {
    "revision": "28cd60fb03c2df50655952e1f4c173ac",
    "url": "/stockmoney/json/my_eps_cols.json"
  },
  {
    "revision": "a18090e1be8e5ee3505950dd5853732c",
    "url": "/stockmoney/json/tech_bch.json"
  },
  {
    "revision": "4ceab57a8c9a6cd7e19f2b097e934cc2",
    "url": "/stockmoney/json/tech_bch_cols.json"
  },
  {
    "revision": "86c11ede40aa1adb040431eeedd1e2a3",
    "url": "/stockmoney/json/tech_beta.json"
  },
  {
    "revision": "8f09f6a30643cd54d5275425bea06c52",
    "url": "/stockmoney/json/tech_beta_cols.json"
  },
  {
    "revision": "b9bd4d87dc736d2e0880a9f8a69dabe3",
    "url": "/stockmoney/json/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json/tech_kd_cols.json"
  },
  {
    "revision": "c12b3d65bb777dc5b08c8df161508b70",
    "url": "/stockmoney/json/tech_ma.json"
  },
  {
    "revision": "0312283011ee3335e1c1333e9725ace1",
    "url": "/stockmoney/json/tech_ma_cols.json"
  },
  {
    "revision": "0166e2fff4a2312c118de3d156f8748b",
    "url": "/stockmoney/json/triplerate_gross.json"
  },
  {
    "revision": "f41184d670b40cace075e49d49d42e3d",
    "url": "/stockmoney/json/triplerate_gross_cols.json"
  },
  {
    "revision": "976e3873caedf016790d3778bb8ada5e",
    "url": "/stockmoney/json/triplerate_net.json"
  },
  {
    "revision": "fe16d2c9e274617d80caeb210673a51a",
    "url": "/stockmoney/json/triplerate_net_cols.json"
  },
  {
    "revision": "99386ccaf6d64af0bcb57ba59d9ec621",
    "url": "/stockmoney/json/triplerate_opp.json"
  },
  {
    "revision": "e0eed0b802f07b1baaf3df389556718f",
    "url": "/stockmoney/json/triplerate_opp_cols.json"
  },
  {
    "revision": "a8b68c705bccdc905bf6c3646d4ebc45",
    "url": "/stockmoney/json/year_eps.json"
  },
  {
    "revision": "f9abf367f118261a74838690a7d0c134",
    "url": "/stockmoney/json/year_eps_cols.json"
  },
  {
    "revision": "bab35f47f0f3f9287fcfcaf262886fad",
    "url": "/stockmoney/json/year_roe.json"
  },
  {
    "revision": "557c99f2d1516d62e1f6b9105e34cfc3",
    "url": "/stockmoney/json/year_roe_cols.json"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json_otc/.dummy"
  },
  {
    "revision": "0a5d52421e2827b5cafa1ea29d898963",
    "url": "/stockmoney/json_otc/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json_otc/basic_4season_cols.json"
  },
  {
    "revision": "2e5ca1593752775df5517122f90dedd9",
    "url": "/stockmoney/json_otc/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json_otc/basic_asset_cols.json"
  },
  {
    "revision": "f53497765f726dd59989eae6643ac2af",
    "url": "/stockmoney/json_otc/basic_cash.json"
  },
  {
    "revision": "d5c39ed748b473abbb0dedc4624f03ab",
    "url": "/stockmoney/json_otc/basic_cash_cols.json"
  },
  {
    "revision": "1052d6745d314334905848390ac168d4",
    "url": "/stockmoney/json_otc/basic_debt.json"
  },
  {
    "revision": "d3938cc1dd967d8f5cc6e9e70a8e2a0f",
    "url": "/stockmoney/json_otc/basic_debt_cols.json"
  },
  {
    "revision": "e165604230f0bbe007fbfcacd52ec892",
    "url": "/stockmoney/json_otc/basic_eps.json"
  },
  {
    "revision": "6f26eb47c57e7ad706f3c56237aa06cb",
    "url": "/stockmoney/json_otc/basic_eps_cols.json"
  },
  {
    "revision": "e10d2da9b70f5613a092d61d50392ec5",
    "url": "/stockmoney/json_otc/basic_gross.json"
  },
  {
    "revision": "b3fae3c39465ee5dab0e087ffc789e5b",
    "url": "/stockmoney/json_otc/basic_gross_cols.json"
  },
  {
    "revision": "7e196af8d5ea5633d4d52c98ad1dbad1",
    "url": "/stockmoney/json_otc/basic_info.json"
  },
  {
    "revision": "2dbdaa83e5d85419907f0945a8bbb99d",
    "url": "/stockmoney/json_otc/basic_info_cols.json"
  },
  {
    "revision": "09a64ef273329d57c9f213cbfface937",
    "url": "/stockmoney/json_otc/basic_noi.json"
  },
  {
    "revision": "f280f4cdc45de4eb6e772579bf747b60",
    "url": "/stockmoney/json_otc/basic_noi_cols.json"
  },
  {
    "revision": "6f485f9047710924478d10854df4634b",
    "url": "/stockmoney/json_otc/basic_opm.json"
  },
  {
    "revision": "321eb329af17760a3a652e4ea833623c",
    "url": "/stockmoney/json_otc/basic_opm_cols.json"
  },
  {
    "revision": "6167bb5b5c6eab3a79062b9d25d23318",
    "url": "/stockmoney/json_otc/basic_opp.json"
  },
  {
    "revision": "f41938706758e1b7c3ad995b9348af0b",
    "url": "/stockmoney/json_otc/basic_opp_cols.json"
  },
  {
    "revision": "df032ec5973d519cdfa9d46f6d19060d",
    "url": "/stockmoney/json_otc/basic_roe.json"
  },
  {
    "revision": "33b75736f5c4669bec1092f0ae290777",
    "url": "/stockmoney/json_otc/basic_roe_cols.json"
  },
  {
    "revision": "8be24d6aae66ea8d634470599ebdf5d4",
    "url": "/stockmoney/json_otc/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json_otc/basic_yearw_cols.json"
  },
  {
    "revision": "8c3885ca7afede181ddde56f9d483204",
    "url": "/stockmoney/json_otc/chip_director.json"
  },
  {
    "revision": "034ebd9edebeb620de71cca78cf5e2cc",
    "url": "/stockmoney/json_otc/chip_director1.json"
  },
  {
    "revision": "f9146b966dfd77db0815d4d76be2f95a",
    "url": "/stockmoney/json_otc/chip_director1_cols.json"
  },
  {
    "revision": "6dfd032407b48949596c1ce16611f767",
    "url": "/stockmoney/json_otc/chip_director3.json"
  },
  {
    "revision": "2443007c508c710095c9852dcfbcbf90",
    "url": "/stockmoney/json_otc/chip_director3_cols.json"
  },
  {
    "revision": "9373b975406bb15bbb2a05eb03a0190f",
    "url": "/stockmoney/json_otc/chip_director5.json"
  },
  {
    "revision": "2899f8c6ca20e9574aeb80f81a52a0d4",
    "url": "/stockmoney/json_otc/chip_director5_cols.json"
  },
  {
    "revision": "51e09fcd7a526fc9bf57bd6136d0da91",
    "url": "/stockmoney/json_otc/chip_director_cols.json"
  },
  {
    "revision": "a9a894a20a7bdc7b29188fec0fd955d1",
    "url": "/stockmoney/json_otc/chip_legal.json"
  },
  {
    "revision": "d7e02491040240f9cb7da3e58c364e5d",
    "url": "/stockmoney/json_otc/chip_legal_cols.json"
  },
  {
    "revision": "d34ebf2c3be992e94fc3ac5eeaebbf28",
    "url": "/stockmoney/json_otc/chip_trust.json"
  },
  {
    "revision": "fecc398de2cf4696c3d156dd0da35961",
    "url": "/stockmoney/json_otc/chip_trust_cols.json"
  },
  {
    "revision": "d0eeac5dbf0647728c84304a7f325417",
    "url": "/stockmoney/json_otc/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json_otc/deal_pct_cols.json"
  },
  {
    "revision": "58c869696c2ef1517b52b6eedbf2310f",
    "url": "/stockmoney/json_otc/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json_otc/deal_vol_cols.json"
  },
  {
    "revision": "fa752042ddf2933d3136da3da574abb7",
    "url": "/stockmoney/json_otc/dividend_cont.json"
  },
  {
    "revision": "e98f37eaa810fd912b66473ef4aec297",
    "url": "/stockmoney/json_otc/dividend_cont_cols.json"
  },
  {
    "revision": "e64c6b10b7636753979142a2d9209b1a",
    "url": "/stockmoney/json_otc/dividend_stat.json"
  },
  {
    "revision": "21c6d862c4542447ccccfd08ff51bce9",
    "url": "/stockmoney/json_otc/dividend_stat_2015.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2015_cols.json"
  },
  {
    "revision": "d6c9d1101ef9f25794f0467f67dd9a17",
    "url": "/stockmoney/json_otc/dividend_stat_2016.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2016_cols.json"
  },
  {
    "revision": "531e4b866bc78364065f34d415dc117f",
    "url": "/stockmoney/json_otc/dividend_stat_2017.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2017_cols.json"
  },
  {
    "revision": "96fb1225ec93dfa7421a9d369ee8de90",
    "url": "/stockmoney/json_otc/dividend_stat_2018.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2018_cols.json"
  },
  {
    "revision": "2c47c220e75f515787167b98f504246d",
    "url": "/stockmoney/json_otc/dividend_stat_2019.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2019_cols.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json_otc/dividend_stat_cols.json"
  },
  {
    "revision": "6f3ebae32a65de8d4bc756c36d1117ee",
    "url": "/stockmoney/json_otc/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json_otc/dividend_yield_cols.json"
  },
  {
    "revision": "2397dcf0056e4154bd186459ffab896e",
    "url": "/stockmoney/json_otc/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json_otc/export_director_cols.json"
  },
  {
    "revision": "d9d33e6bdf9910ad833ce1bccb74bff2",
    "url": "/stockmoney/json_otc/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json_otc/export_incomerate_cols.json"
  },
  {
    "revision": "642ad24e49b7112101f3692c21e66458",
    "url": "/stockmoney/json_otc/export_stockfish.json"
  },
  {
    "revision": "32911b54153344868aa71b078b98f046",
    "url": "/stockmoney/json_otc/export_stockfish_cols.json"
  },
  {
    "revision": "a5631749b3868cfc1bc5ccfee7780465",
    "url": "/stockmoney/json_otc/export_triplerate.json"
  },
  {
    "revision": "a625f25eee5bf1c3f165bc86c455ce79",
    "url": "/stockmoney/json_otc/export_triplerate_cols.json"
  },
  {
    "revision": "d414113c1803724f06a3a82574647600",
    "url": "/stockmoney/json_otc/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json_otc/export_water_cols.json"
  },
  {
    "revision": "495167dc4674a4ac6d6d8d5038dbef97",
    "url": "/stockmoney/json_otc/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json_otc/export_yield_cols.json"
  },
  {
    "revision": "3032b0f2bffb62bf6b4e83200d7486eb",
    "url": "/stockmoney/json_otc/my_eps.json"
  },
  {
    "revision": "28cd60fb03c2df50655952e1f4c173ac",
    "url": "/stockmoney/json_otc/my_eps_cols.json"
  },
  {
    "revision": "26d09a1f9d614a46d64ab436b20e75d7",
    "url": "/stockmoney/json_otc/tech_bch.json"
  },
  {
    "revision": "4ceab57a8c9a6cd7e19f2b097e934cc2",
    "url": "/stockmoney/json_otc/tech_bch_cols.json"
  },
  {
    "revision": "0a596f37024abf02770432bcb7590a2c",
    "url": "/stockmoney/json_otc/tech_beta.json"
  },
  {
    "revision": "4bb937eaf819207728fd1032030d72a4",
    "url": "/stockmoney/json_otc/tech_beta_cols.json"
  },
  {
    "revision": "72f7d70bdfc6e0e8e0c897480d49fc1b",
    "url": "/stockmoney/json_otc/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json_otc/tech_kd_cols.json"
  },
  {
    "revision": "6ff6584fe2c5dd0202a876fc974fdafc",
    "url": "/stockmoney/json_otc/tech_ma.json"
  },
  {
    "revision": "0312283011ee3335e1c1333e9725ace1",
    "url": "/stockmoney/json_otc/tech_ma_cols.json"
  },
  {
    "revision": "2f1cd3d732ae9af78d45362375b26309",
    "url": "/stockmoney/json_otc/triplerate_gross.json"
  },
  {
    "revision": "2c3a2bac0d838ba758608cbb9147efa5",
    "url": "/stockmoney/json_otc/triplerate_gross_cols.json"
  },
  {
    "revision": "d13eaf4fdcf3e59801de4744364211e4",
    "url": "/stockmoney/json_otc/triplerate_net.json"
  },
  {
    "revision": "d8ede74c386fd996618a982d92f157c0",
    "url": "/stockmoney/json_otc/triplerate_net_cols.json"
  },
  {
    "revision": "8276fa89ef8dff8dec71600fa51c5352",
    "url": "/stockmoney/json_otc/triplerate_opp.json"
  },
  {
    "revision": "dd9908fd20a83b4dae090948447136cb",
    "url": "/stockmoney/json_otc/triplerate_opp_cols.json"
  },
  {
    "revision": "e6f54a389b1d1f5b082ca7be200a62f2",
    "url": "/stockmoney/json_otc/year_eps.json"
  },
  {
    "revision": "1517abca93c2d49b8e3b11218d44a39e",
    "url": "/stockmoney/json_otc/year_eps_cols.json"
  },
  {
    "revision": "5fc4964c8a99e0f26dfab9dd36eddfd8",
    "url": "/stockmoney/json_otc/year_roe.json"
  },
  {
    "revision": "1474c4710b0f533572131f5e22d6ab33",
    "url": "/stockmoney/json_otc/year_roe_cols.json"
  },
  {
    "revision": "b96e0d5a5df171b63ae60164bac0e3af",
    "url": "/stockmoney/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/stockmoney/robots.txt"
  },
  {
    "revision": "70a67a864fcc29920f62",
    "url": "/stockmoney/static/css/app.2cf3b2ff.css"
  },
  {
    "revision": "00a14ddebf3604813825",
    "url": "/stockmoney/static/css/chunk-vendors.eae4093c.css"
  },
  {
    "revision": "ecb3bfc03db10b6f9d6e23e710d5c953",
    "url": "/stockmoney/static/img/logo.ecb3bfc0.png"
  },
  {
    "revision": "85ce6e4334a2eeb8390e",
    "url": "/stockmoney/static/js/about.3644c617.js"
  },
  {
    "revision": "70a67a864fcc29920f62",
    "url": "/stockmoney/static/js/app.35bce7dd.js"
  },
  {
    "revision": "00a14ddebf3604813825",
    "url": "/stockmoney/static/js/chunk-vendors.2d8e5b65.js"
  }
]);