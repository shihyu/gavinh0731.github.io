self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d1daf481ea891c317350eefab4b14e05",
    "url": "/stockmoney/index.html"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json/.dummy"
  },
  {
    "revision": "25f53f3e0d4d9d15b3cbe01cd0f9b561",
    "url": "/stockmoney/json/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json/basic_4season_cols.json"
  },
  {
    "revision": "21541f776455817174c9cadb49a58b24",
    "url": "/stockmoney/json/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json/basic_asset_cols.json"
  },
  {
    "revision": "ff5100da9937698007a6f12cae39b078",
    "url": "/stockmoney/json/basic_cash.json"
  },
  {
    "revision": "79f49477a1d4f2afe0365b00caaf2040",
    "url": "/stockmoney/json/basic_cash_cols.json"
  },
  {
    "revision": "2970a37103af8d910b41a6e3914132ae",
    "url": "/stockmoney/json/basic_debt.json"
  },
  {
    "revision": "0f8c1b1ceca9e477f1cb364999223bd1",
    "url": "/stockmoney/json/basic_debt_cols.json"
  },
  {
    "revision": "da7b2ebfa1d61c2a5e07043fae968662",
    "url": "/stockmoney/json/basic_eps.json"
  },
  {
    "revision": "6868e2a2bec9e685a16b870f1f9f11bc",
    "url": "/stockmoney/json/basic_eps_cols.json"
  },
  {
    "revision": "bfde9e4aaf0c4b85193bf14d594feaae",
    "url": "/stockmoney/json/basic_gross.json"
  },
  {
    "revision": "e1751b3eee8eeb67065de1c61d44202f",
    "url": "/stockmoney/json/basic_gross_cols.json"
  },
  {
    "revision": "bbbfbf1ad93cd58ca4af2dabe941a611",
    "url": "/stockmoney/json/basic_info.json"
  },
  {
    "revision": "13e705f89a2b21a1bed5151ba2614a3a",
    "url": "/stockmoney/json/basic_info_cols.json"
  },
  {
    "revision": "97f83d148b06291aa90e327f059147e9",
    "url": "/stockmoney/json/basic_net.json"
  },
  {
    "revision": "0555753dc16707447bc6bc1ebe1bf328",
    "url": "/stockmoney/json/basic_net_cols.json"
  },
  {
    "revision": "0ccf6d3468700fc8195fe6a9ebc85e4e",
    "url": "/stockmoney/json/basic_noi.json"
  },
  {
    "revision": "02308b60390698b1d8fc349227003ac9",
    "url": "/stockmoney/json/basic_noi_cols.json"
  },
  {
    "revision": "9824af80add05b87d4fd7cf7a993e8a8",
    "url": "/stockmoney/json/basic_opm.json"
  },
  {
    "revision": "974e8570c26f91c13b65d1f1f95a12d6",
    "url": "/stockmoney/json/basic_opm_cols.json"
  },
  {
    "revision": "d3f584ed00328e945dca7032fc1a088a",
    "url": "/stockmoney/json/basic_opp.json"
  },
  {
    "revision": "5f1ca5016f93fab8bb144b12e54a0f5a",
    "url": "/stockmoney/json/basic_opp_cols.json"
  },
  {
    "revision": "bd2e45f79f20d48beeeb2255090abee2",
    "url": "/stockmoney/json/basic_roe.json"
  },
  {
    "revision": "a79c281e63331ebed3c104833b1c9e81",
    "url": "/stockmoney/json/basic_roe_cols.json"
  },
  {
    "revision": "cc632a21cfb380cf0b3f3ddeee4ab463",
    "url": "/stockmoney/json/basic_rvn.json"
  },
  {
    "revision": "4560ded6ab63a9885eff65ab1ac17df6",
    "url": "/stockmoney/json/basic_rvn_cols.json"
  },
  {
    "revision": "b49e3389290e1b88be8e242cdb072ed9",
    "url": "/stockmoney/json/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json/basic_yearw_cols.json"
  },
  {
    "revision": "7c334a5a846d8094932296c3818c728a",
    "url": "/stockmoney/json/chip_borrow.json"
  },
  {
    "revision": "8f7d417fab3fcdcf58c95c1d93b2e10e",
    "url": "/stockmoney/json/chip_borrow_cols.json"
  },
  {
    "revision": "9f11e4e8f155b6d6932e9bda1c5c565a",
    "url": "/stockmoney/json/chip_director.json"
  },
  {
    "revision": "75747e9b1ad37264c866713933e45841",
    "url": "/stockmoney/json/chip_director1.json"
  },
  {
    "revision": "9245b933efe32254018a0a6e9a6c8613",
    "url": "/stockmoney/json/chip_director1_cols.json"
  },
  {
    "revision": "106f065131c2a2d53f10278c106d4191",
    "url": "/stockmoney/json/chip_director3.json"
  },
  {
    "revision": "b856d752ee7572bba69b5bfefbe9e41b",
    "url": "/stockmoney/json/chip_director3_cols.json"
  },
  {
    "revision": "3685c87a6a26a626e99024272633f167",
    "url": "/stockmoney/json/chip_director5.json"
  },
  {
    "revision": "825ba91683006403a96e4ead7ebc2e2c",
    "url": "/stockmoney/json/chip_director5_cols.json"
  },
  {
    "revision": "9bbbf6600d4c03482470ae7a8ed48118",
    "url": "/stockmoney/json/chip_director_cols.json"
  },
  {
    "revision": "0f18c37e1f88e2c4520e859d8c1ace47",
    "url": "/stockmoney/json/chip_foreign.json"
  },
  {
    "revision": "1f66416e66912403af00c4d2366c2741",
    "url": "/stockmoney/json/chip_foreign_cols.json"
  },
  {
    "revision": "5039b9cb0ba04fc16f1b56c3d83c60e3",
    "url": "/stockmoney/json/chip_legal.json"
  },
  {
    "revision": "60a82514c04d8b46e234b6c3b7db8a4c",
    "url": "/stockmoney/json/chip_legal_cols.json"
  },
  {
    "revision": "948b08d2117c526c84fdcba643ad1526",
    "url": "/stockmoney/json/chip_loan.json"
  },
  {
    "revision": "5396a6b60fdb18143f688500ef15b099",
    "url": "/stockmoney/json/chip_loan_cols.json"
  },
  {
    "revision": "5551cb4ca5e6e1fdc4bb3a72b6397c45",
    "url": "/stockmoney/json/chip_trust.json"
  },
  {
    "revision": "0453c094ec1578d8b609550d9e477938",
    "url": "/stockmoney/json/chip_trust_cols.json"
  },
  {
    "revision": "2edec9f169db448c0b978ae90bbd6135",
    "url": "/stockmoney/json/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json/deal_pct_cols.json"
  },
  {
    "revision": "8d7180010e8f6f03f10d7f273353e78d",
    "url": "/stockmoney/json/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json/deal_vol_cols.json"
  },
  {
    "revision": "8356fb7d5d78afb31468f9a6d62af7e9",
    "url": "/stockmoney/json/dividend_cont.json"
  },
  {
    "revision": "e98f37eaa810fd912b66473ef4aec297",
    "url": "/stockmoney/json/dividend_cont_cols.json"
  },
  {
    "revision": "ac8441545e6d839602f2a1b2700d3140",
    "url": "/stockmoney/json/dividend_stat.json"
  },
  {
    "revision": "6b09085bcb721c27eb9d5eda723d58ec",
    "url": "/stockmoney/json/dividend_stat_2015.json"
  },
  {
    "revision": "008c79d526737b517a9a742b04502b20",
    "url": "/stockmoney/json/dividend_stat_2015_cols.json"
  },
  {
    "revision": "5334753fb69f36585eb5c7b7cb375626",
    "url": "/stockmoney/json/dividend_stat_2016.json"
  },
  {
    "revision": "ec5a0a94673998b0bb4a63db93d08f4a",
    "url": "/stockmoney/json/dividend_stat_2016_cols.json"
  },
  {
    "revision": "005c9c2b12198a37dcb217a855260d66",
    "url": "/stockmoney/json/dividend_stat_2017.json"
  },
  {
    "revision": "e37fc91cd72912b24657ed675d9f1c8b",
    "url": "/stockmoney/json/dividend_stat_2017_cols.json"
  },
  {
    "revision": "5c9cc2851bb00875686f7d2c3501dd6c",
    "url": "/stockmoney/json/dividend_stat_2018.json"
  },
  {
    "revision": "38050d84b8d337ce366fb397e8e206f7",
    "url": "/stockmoney/json/dividend_stat_2018_cols.json"
  },
  {
    "revision": "a31c96f76aebb46f3ed812f4aab15dea",
    "url": "/stockmoney/json/dividend_stat_2019.json"
  },
  {
    "revision": "7ec66cdc30aa0d150bc4f797bdc131c4",
    "url": "/stockmoney/json/dividend_stat_2019_cols.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json/dividend_stat_cols.json"
  },
  {
    "revision": "8156b6970cbec80a242b6d0462a238ad",
    "url": "/stockmoney/json/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json/dividend_yield_cols.json"
  },
  {
    "revision": "1f8c2af62cc61c6ab41dd07d5dbeed47",
    "url": "/stockmoney/json/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json/export_director_cols.json"
  },
  {
    "revision": "80b72eca98eca2193e853eb00885377e",
    "url": "/stockmoney/json/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json/export_incomerate_cols.json"
  },
  {
    "revision": "795de3b658ffa176835ddfb253d55ef7",
    "url": "/stockmoney/json/export_stockfish.json"
  },
  {
    "revision": "aa76bf1d9931072a3fe9c3e216868eac",
    "url": "/stockmoney/json/export_stockfish_cols.json"
  },
  {
    "revision": "7e7f15816a9296782a3727504a4e7f55",
    "url": "/stockmoney/json/export_triplerate.json"
  },
  {
    "revision": "2f91c73c151fa60608962f562b8d2bc9",
    "url": "/stockmoney/json/export_triplerate_cols.json"
  },
  {
    "revision": "2e45546c58a8ae481f7948a00d472ffc",
    "url": "/stockmoney/json/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json/export_water_cols.json"
  },
  {
    "revision": "dc4ab0c37b678d59da69293f79ce12b0",
    "url": "/stockmoney/json/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json/export_yield_cols.json"
  },
  {
    "revision": "55d3e8cc032fa4bc805811f48052ea6a",
    "url": "/stockmoney/json/my_eps.json"
  },
  {
    "revision": "87b98bb7ccff2628d43fe83db7362e93",
    "url": "/stockmoney/json/my_eps_cols.json"
  },
  {
    "revision": "5554f332f988dd380ce181f9a05e6d37",
    "url": "/stockmoney/json/tech_bch.json"
  },
  {
    "revision": "4ceab57a8c9a6cd7e19f2b097e934cc2",
    "url": "/stockmoney/json/tech_bch_cols.json"
  },
  {
    "revision": "acf48621cc7a0d3c5ccf55bb66b199b9",
    "url": "/stockmoney/json/tech_beta.json"
  },
  {
    "revision": "8f09f6a30643cd54d5275425bea06c52",
    "url": "/stockmoney/json/tech_beta_cols.json"
  },
  {
    "revision": "fb055f2113b469b13d32a097e812b0d8",
    "url": "/stockmoney/json/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json/tech_kd_cols.json"
  },
  {
    "revision": "8d20d798c0c8b92fb8b7a33b6d7b8487",
    "url": "/stockmoney/json/tech_ma.json"
  },
  {
    "revision": "0312283011ee3335e1c1333e9725ace1",
    "url": "/stockmoney/json/tech_ma_cols.json"
  },
  {
    "revision": "37605571ba3ee231e14e20880e1350e8",
    "url": "/stockmoney/json/triplerate_gross.json"
  },
  {
    "revision": "c9f4008b9ccfb0d0e039a015c9a07ec9",
    "url": "/stockmoney/json/triplerate_gross_cols.json"
  },
  {
    "revision": "b7aa04547395a693c59874eb55f2e45e",
    "url": "/stockmoney/json/triplerate_net.json"
  },
  {
    "revision": "0efd1b0b5bf0cdac66d61c6422b09fa0",
    "url": "/stockmoney/json/triplerate_net_cols.json"
  },
  {
    "revision": "5af9a27f390a2a881ea92828caefae89",
    "url": "/stockmoney/json/triplerate_opp.json"
  },
  {
    "revision": "2e5ed946dca96dad7a3306ae3419899d",
    "url": "/stockmoney/json/triplerate_opp_cols.json"
  },
  {
    "revision": "0ff15d0163d78362d7ea57cc4846dcf4",
    "url": "/stockmoney/json/year_eps.json"
  },
  {
    "revision": "e67d1672a00930b43691f2517678806f",
    "url": "/stockmoney/json/year_eps_cols.json"
  },
  {
    "revision": "33bc345e4ac0bc2c828121d8d08849d6",
    "url": "/stockmoney/json/year_roe.json"
  },
  {
    "revision": "cd7b5cc105c709b8a97ae9447cf45196",
    "url": "/stockmoney/json/year_roe_cols.json"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json_otc/.dummy"
  },
  {
    "revision": "eb32453307f400ab4bfe7188fddbcb9c",
    "url": "/stockmoney/json_otc/basic_4season.json"
  },
  {
    "revision": "5af8e03d5ac2fd4ca03652dd2b98f6f0",
    "url": "/stockmoney/json_otc/basic_4season_cols.json"
  },
  {
    "revision": "be0d23fad98f8dfd2cc7f4d2b510fe2d",
    "url": "/stockmoney/json_otc/basic_asset.json"
  },
  {
    "revision": "b38212d12f678a74ad6a6565339df931",
    "url": "/stockmoney/json_otc/basic_asset_cols.json"
  },
  {
    "revision": "3ca03dd376513011427999f6f5bba5ae",
    "url": "/stockmoney/json_otc/basic_cash.json"
  },
  {
    "revision": "a8be5ba04be484df3276e55a8372b625",
    "url": "/stockmoney/json_otc/basic_cash_cols.json"
  },
  {
    "revision": "86e9aa0944bca405f4699ab10fa89846",
    "url": "/stockmoney/json_otc/basic_debt.json"
  },
  {
    "revision": "18f97fadd1818d70fed65edaa17edb79",
    "url": "/stockmoney/json_otc/basic_debt_cols.json"
  },
  {
    "revision": "55da0773f15bc2256f441c9df84ab1ee",
    "url": "/stockmoney/json_otc/basic_eps.json"
  },
  {
    "revision": "589ffa71064c41bc9416de87c7e26458",
    "url": "/stockmoney/json_otc/basic_eps_cols.json"
  },
  {
    "revision": "0b0c8624fe5039f4604652ca81c2c9a8",
    "url": "/stockmoney/json_otc/basic_gross.json"
  },
  {
    "revision": "25967a931b14db1812784b666df80e1c",
    "url": "/stockmoney/json_otc/basic_gross_cols.json"
  },
  {
    "revision": "c071dce4afeaca77dbbce7e7304459d2",
    "url": "/stockmoney/json_otc/basic_info.json"
  },
  {
    "revision": "6f99a8a60e35b64e93e4e87ccbc4e5dd",
    "url": "/stockmoney/json_otc/basic_info_cols.json"
  },
  {
    "revision": "83f56ca516aef5a3db0642c685ba3cf1",
    "url": "/stockmoney/json_otc/basic_net.json"
  },
  {
    "revision": "b265e2e6c45645c0444d4419ff3f4a7e",
    "url": "/stockmoney/json_otc/basic_net_cols.json"
  },
  {
    "revision": "8888585d257d9f31c0b399845893baab",
    "url": "/stockmoney/json_otc/basic_noi.json"
  },
  {
    "revision": "db9226b70bc9c155ca76231c5e7e06ac",
    "url": "/stockmoney/json_otc/basic_noi_cols.json"
  },
  {
    "revision": "f81957c2f79256a87de47fd7dde10452",
    "url": "/stockmoney/json_otc/basic_opm.json"
  },
  {
    "revision": "1fe817920f0a1ee56991dac6bbdc003c",
    "url": "/stockmoney/json_otc/basic_opm_cols.json"
  },
  {
    "revision": "254b2fc6e075b3fb66c5f5da8188fa6a",
    "url": "/stockmoney/json_otc/basic_opp.json"
  },
  {
    "revision": "41a6ae0bdd8b813abde7eb0f0ed6ad86",
    "url": "/stockmoney/json_otc/basic_opp_cols.json"
  },
  {
    "revision": "80a61833b32cbb56d7da60d2c223603f",
    "url": "/stockmoney/json_otc/basic_roe.json"
  },
  {
    "revision": "6e9caad67dd3c4c99bf0e5e6ea54ccc2",
    "url": "/stockmoney/json_otc/basic_roe_cols.json"
  },
  {
    "revision": "e069b6763c52bc680a4e24d25fb1b250",
    "url": "/stockmoney/json_otc/basic_rvn.json"
  },
  {
    "revision": "4d38909520fd9a0c7d79de8e3060340a",
    "url": "/stockmoney/json_otc/basic_rvn_cols.json"
  },
  {
    "revision": "8becfb0c355588d48207598d6f3a2c9c",
    "url": "/stockmoney/json_otc/basic_yearw.json"
  },
  {
    "revision": "37afed6bf332938bf457759590f15e20",
    "url": "/stockmoney/json_otc/basic_yearw_cols.json"
  },
  {
    "revision": "4a30330354c2f6d2bec13f978b18ebeb",
    "url": "/stockmoney/json_otc/chip_borrow.json"
  },
  {
    "revision": "8f7d417fab3fcdcf58c95c1d93b2e10e",
    "url": "/stockmoney/json_otc/chip_borrow_cols.json"
  },
  {
    "revision": "526b8eb80e480f5e97b93d171714d9fb",
    "url": "/stockmoney/json_otc/chip_director.json"
  },
  {
    "revision": "530dafd181d552b032b8c9868c32fe26",
    "url": "/stockmoney/json_otc/chip_director1.json"
  },
  {
    "revision": "8e7a0bacff28aa1cf9f5825c7712c937",
    "url": "/stockmoney/json_otc/chip_director1_cols.json"
  },
  {
    "revision": "aa633be26bf5dfe6e4ddc7130550d09f",
    "url": "/stockmoney/json_otc/chip_director3.json"
  },
  {
    "revision": "cb725822bf310830ac86771e76bbf7e5",
    "url": "/stockmoney/json_otc/chip_director3_cols.json"
  },
  {
    "revision": "4f76504bbf4fb2f914a09cbd5c633512",
    "url": "/stockmoney/json_otc/chip_director5.json"
  },
  {
    "revision": "9e1f67c918b55fd9c2153dc91b5ea992",
    "url": "/stockmoney/json_otc/chip_director5_cols.json"
  },
  {
    "revision": "79dce6a98cc61675f28207bb8ee66d68",
    "url": "/stockmoney/json_otc/chip_director_cols.json"
  },
  {
    "revision": "8d24eec034b813867ec8d472b400ce91",
    "url": "/stockmoney/json_otc/chip_foreign.json"
  },
  {
    "revision": "3bf026d11420cdb1c4f31d14d9eb734f",
    "url": "/stockmoney/json_otc/chip_foreign_cols.json"
  },
  {
    "revision": "71e56af19bfac7fe8eadd457ac834f5a",
    "url": "/stockmoney/json_otc/chip_legal.json"
  },
  {
    "revision": "56a5a51151871b1624874a4fe5a82f83",
    "url": "/stockmoney/json_otc/chip_legal_cols.json"
  },
  {
    "revision": "9df2469f595c121769cda85d748b748d",
    "url": "/stockmoney/json_otc/chip_loan.json"
  },
  {
    "revision": "5396a6b60fdb18143f688500ef15b099",
    "url": "/stockmoney/json_otc/chip_loan_cols.json"
  },
  {
    "revision": "1708199314f7d21c579554d78e8d8ab9",
    "url": "/stockmoney/json_otc/chip_trust.json"
  },
  {
    "revision": "4466ee075166bd957824b4a6d6c6ddbe",
    "url": "/stockmoney/json_otc/chip_trust_cols.json"
  },
  {
    "revision": "69226768b7f388dfe20d7977171e995f",
    "url": "/stockmoney/json_otc/deal_pct.json"
  },
  {
    "revision": "6aa4eed51cba9dc1dc746762256d9659",
    "url": "/stockmoney/json_otc/deal_pct_cols.json"
  },
  {
    "revision": "8c766ff6cff63b2513d44322780fc8c2",
    "url": "/stockmoney/json_otc/deal_vol.json"
  },
  {
    "revision": "b27cd4bd88359e51326cd3dab8215f69",
    "url": "/stockmoney/json_otc/deal_vol_cols.json"
  },
  {
    "revision": "57323bae5b2852c73db7306d2f781b43",
    "url": "/stockmoney/json_otc/dividend_cont.json"
  },
  {
    "revision": "d770b65af07d9d64a25e81b34c57086f",
    "url": "/stockmoney/json_otc/dividend_cont_cols.json"
  },
  {
    "revision": "e4e09c626c942c9b1ab713644f1e94c8",
    "url": "/stockmoney/json_otc/dividend_stat.json"
  },
  {
    "revision": "5fe7a9d93e76f0e57ed3f0f6f12ef168",
    "url": "/stockmoney/json_otc/dividend_stat_2015.json"
  },
  {
    "revision": "cbec2feb676f6a6aa3b239e88e6d6a2c",
    "url": "/stockmoney/json_otc/dividend_stat_2015_cols.json"
  },
  {
    "revision": "db05e7a777c5cd187791a42a55082fdb",
    "url": "/stockmoney/json_otc/dividend_stat_2016.json"
  },
  {
    "revision": "6e18d58a36f9fc2a33f01cedfe00600b",
    "url": "/stockmoney/json_otc/dividend_stat_2016_cols.json"
  },
  {
    "revision": "b0635c621d4cddb63883d3527776cf37",
    "url": "/stockmoney/json_otc/dividend_stat_2017.json"
  },
  {
    "revision": "297d5aebd0f10fcde9bb1a0e4ac5182e",
    "url": "/stockmoney/json_otc/dividend_stat_2017_cols.json"
  },
  {
    "revision": "be938a5acd55fe78775a18cdcc4ad303",
    "url": "/stockmoney/json_otc/dividend_stat_2018.json"
  },
  {
    "revision": "260b5376813e3734a06dab71d8b9bd8a",
    "url": "/stockmoney/json_otc/dividend_stat_2018_cols.json"
  },
  {
    "revision": "94fd13dd1f075bfe046019d8f5f6bfe0",
    "url": "/stockmoney/json_otc/dividend_stat_2019.json"
  },
  {
    "revision": "6050c49dcd02fe1bf54be9c00f3014eb",
    "url": "/stockmoney/json_otc/dividend_stat_2019_cols.json"
  },
  {
    "revision": "9b4c4be9545c11e770cbe8be386f94cb",
    "url": "/stockmoney/json_otc/dividend_stat_cols.json"
  },
  {
    "revision": "dcfb0d125aa4064e37142815dcb03eed",
    "url": "/stockmoney/json_otc/dividend_yield.json"
  },
  {
    "revision": "ecb2998fde71d849b8992a7b6c4e2e3d",
    "url": "/stockmoney/json_otc/dividend_yield_cols.json"
  },
  {
    "revision": "1314cb18e1c6b8cd03b26a31b85b3832",
    "url": "/stockmoney/json_otc/export_director.json"
  },
  {
    "revision": "5906808ba611dab591b58dc6845c87cc",
    "url": "/stockmoney/json_otc/export_incomerate.json"
  },
  {
    "revision": "17402cec81e6447a0e084fbbc5813db0",
    "url": "/stockmoney/json_otc/export_stockfish.json"
  },
  {
    "revision": "98e1b39dd695f3d1b8dfebf02b1d4bb1",
    "url": "/stockmoney/json_otc/export_triplerate.json"
  },
  {
    "revision": "0704ad5784942f344dfc6db6994ec074",
    "url": "/stockmoney/json_otc/export_water.json"
  },
  {
    "revision": "aa53cfc914eb74033f5e7b76c435748c",
    "url": "/stockmoney/json_otc/export_yield.json"
  },
  {
    "revision": "b96d89afc964f71a83823b45ea991089",
    "url": "/stockmoney/json_otc/my_eps.json"
  },
  {
    "revision": "88ce089146d9a7dd7031011dfccdd0d1",
    "url": "/stockmoney/json_otc/tech_bch.json"
  },
  {
    "revision": "1f3501a7241684346326f6b20fef29ab",
    "url": "/stockmoney/json_otc/tech_bch_cols.json"
  },
  {
    "revision": "1f5eae40294792be7cf8965c86e14d9a",
    "url": "/stockmoney/json_otc/tech_beta.json"
  },
  {
    "revision": "1d1993c61608814513697231793da5ff",
    "url": "/stockmoney/json_otc/tech_beta_cols.json"
  },
  {
    "revision": "192eee4aeb11a29caf8e48dc047c55e8",
    "url": "/stockmoney/json_otc/tech_kd.json"
  },
  {
    "revision": "4f5d6ca8656dd449a555f2892c29746e",
    "url": "/stockmoney/json_otc/tech_kd_cols.json"
  },
  {
    "revision": "c6e15fe387d1cb70b4ea6746f8c719f9",
    "url": "/stockmoney/json_otc/tech_ma.json"
  },
  {
    "revision": "d6c2c2c917b71f3b85765373cb229222",
    "url": "/stockmoney/json_otc/tech_ma_cols.json"
  },
  {
    "revision": "418508add85ec7dcc1197cd84584b32e",
    "url": "/stockmoney/json_otc/triplerate_gross.json"
  },
  {
    "revision": "d8697fa00e0d6887c4b58192598df0fc",
    "url": "/stockmoney/json_otc/triplerate_gross_cols.json"
  },
  {
    "revision": "8ecb908916fc843191e32a0959b9a681",
    "url": "/stockmoney/json_otc/triplerate_net.json"
  },
  {
    "revision": "a2f8ba9303b9329ea65644890a7170b3",
    "url": "/stockmoney/json_otc/triplerate_net_cols.json"
  },
  {
    "revision": "2daddd1f6fff5946278f4c58d16338af",
    "url": "/stockmoney/json_otc/triplerate_opp.json"
  },
  {
    "revision": "0c6e4c5e5c385975b02be6480cba9f4f",
    "url": "/stockmoney/json_otc/triplerate_opp_cols.json"
  },
  {
    "revision": "4e6b97fd210ab0ae23edb9d5d76d82be",
    "url": "/stockmoney/json_otc/year_eps.json"
  },
  {
    "revision": "a81569d9f1837e74043439e29df15fd0",
    "url": "/stockmoney/json_otc/year_eps_cols.json"
  },
  {
    "revision": "72bbdad7fa787fc9444ba7248cadd204",
    "url": "/stockmoney/json_otc/year_roe.json"
  },
  {
    "revision": "809d3a89dc7400d01edf303762ca494e",
    "url": "/stockmoney/json_otc/year_roe_cols.json"
  },
  {
    "revision": "b96e0d5a5df171b63ae60164bac0e3af",
    "url": "/stockmoney/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/stockmoney/robots.txt"
  },
  {
    "revision": "30e88d41868921b4d36d",
    "url": "/stockmoney/static/css/app.1a58d5ad.css"
  },
  {
    "revision": "0b67f49ecef966899a76",
    "url": "/stockmoney/static/css/chunk-vendors.eae4093c.css"
  },
  {
    "revision": "ecb3bfc03db10b6f9d6e23e710d5c953",
    "url": "/stockmoney/static/img/logo.ecb3bfc0.png"
  },
  {
    "revision": "658800e4ddcdedaaa231",
    "url": "/stockmoney/static/js/about.6cc0e21f.js"
  },
  {
    "revision": "30e88d41868921b4d36d",
    "url": "/stockmoney/static/js/app.017cf370.js"
  },
  {
    "revision": "0b67f49ecef966899a76",
    "url": "/stockmoney/static/js/chunk-vendors.e64b16c7.js"
  }
]);