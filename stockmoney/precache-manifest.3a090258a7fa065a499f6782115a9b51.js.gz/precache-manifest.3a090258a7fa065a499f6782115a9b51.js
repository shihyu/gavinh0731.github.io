self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ef01b61802c4e8beefc6e1d34421a69c",
    "url": "/stockmoney/index.html"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json/.dummy"
  },
  {
    "revision": "2d6dca6ee348387669142f19888d1187",
    "url": "/stockmoney/json/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json/basic_4season_cols.json"
  },
  {
    "revision": "c168630036e28b102d50f03ad8861a94",
    "url": "/stockmoney/json/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json/basic_asset_cols.json"
  },
  {
    "revision": "2fbad9e2171af8a1b10fda0c42e6e4d0",
    "url": "/stockmoney/json/basic_cash.json"
  },
  {
    "revision": "3d0aec0b8eda7d242dbc01626bd2e5d7",
    "url": "/stockmoney/json/basic_cash_cols.json"
  },
  {
    "revision": "5a8dd6a9186c886fdc1a2e7dca321685",
    "url": "/stockmoney/json/basic_debt.json"
  },
  {
    "revision": "e01c26733cac36515f92e6865e68a5e1",
    "url": "/stockmoney/json/basic_debt_cols.json"
  },
  {
    "revision": "ff51cf07db9c5c7f4368b46725a45228",
    "url": "/stockmoney/json/basic_eps.json"
  },
  {
    "revision": "12564b9e65d1fb6739205c9b872e0db2",
    "url": "/stockmoney/json/basic_eps_cols.json"
  },
  {
    "revision": "db915ab112d065209923d263543bd89e",
    "url": "/stockmoney/json/basic_gross.json"
  },
  {
    "revision": "67e439ba99276f0f48bde6ec59ac0a03",
    "url": "/stockmoney/json/basic_gross_cols.json"
  },
  {
    "revision": "e395ccea533c60908b1e71ca9e2eb164",
    "url": "/stockmoney/json/basic_info.json"
  },
  {
    "revision": "f9ea1251cb154f7fe1e82e1cb8c268a9",
    "url": "/stockmoney/json/basic_info_cols.json"
  },
  {
    "revision": "68490e45542ad3586104c14623937d94",
    "url": "/stockmoney/json/basic_noi.json"
  },
  {
    "revision": "e2b9636d8765aa439538385741073af9",
    "url": "/stockmoney/json/basic_noi_cols.json"
  },
  {
    "revision": "6922cf390e101bd4aba6750146e18623",
    "url": "/stockmoney/json/basic_opm.json"
  },
  {
    "revision": "c6915ce4a47312c9cdc1f0e7acfc6b6e",
    "url": "/stockmoney/json/basic_opm_cols.json"
  },
  {
    "revision": "31c804d5ec27db89b613677b6206a4c8",
    "url": "/stockmoney/json/basic_opp.json"
  },
  {
    "revision": "152f0ca5e5c703e471ed920379c8cdee",
    "url": "/stockmoney/json/basic_opp_cols.json"
  },
  {
    "revision": "bcb8effa6ce1f6c909a176081b19ff8b",
    "url": "/stockmoney/json/basic_roe.json"
  },
  {
    "revision": "28eb574018e78ee9f1df212bdc33ed8d",
    "url": "/stockmoney/json/basic_roe_cols.json"
  },
  {
    "revision": "815ca14c20401fa1fd2737b0d03bf68a",
    "url": "/stockmoney/json/basic_yearw.json"
  },
  {
    "revision": "c0da6716663d7d4d089e744a64d640e6",
    "url": "/stockmoney/json/basic_yearw_cols.json"
  },
  {
    "revision": "fc8b51922033371f8827e294f0be7d5b",
    "url": "/stockmoney/json/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json/deal_pct_cols.json"
  },
  {
    "revision": "823b13c8437bd73046c9d402f8c6adc1",
    "url": "/stockmoney/json/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json/deal_vol_cols.json"
  },
  {
    "revision": "b392ad98279286b296991c65de02a658",
    "url": "/stockmoney/json/dividend_cont.json"
  },
  {
    "revision": "ebc1fa13d0fe81617c77324e4d0963cb",
    "url": "/stockmoney/json/dividend_cont_cols.json"
  },
  {
    "revision": "ce4383b5a7714679c46722ba931380bc",
    "url": "/stockmoney/json/dividend_stat.json"
  },
  {
    "revision": "0ae5a2a29d64812828a5b0e7a14d3492",
    "url": "/stockmoney/json/dividend_stat_cols.json"
  },
  {
    "revision": "6f152e538a97e0d47c70bf0c5beaf942",
    "url": "/stockmoney/json/dividend_yield.json"
  },
  {
    "revision": "851da35f3ae8f71e1412f57cdcd72347",
    "url": "/stockmoney/json/dividend_yield_cols.json"
  },
  {
    "revision": "0e9873a1030a3d62862c6f5f7c77aeef",
    "url": "/stockmoney/json/export_stockfish.json"
  },
  {
    "revision": "9eea6075f0a86eff3efcec4900aeba29",
    "url": "/stockmoney/json/export_stockfish_cols.json"
  },
  {
    "revision": "a68f428098129e150ed256627b32ccb9",
    "url": "/stockmoney/json/export_triplerate.json"
  },
  {
    "revision": "39b8f7ff968f53648f9f82c6d04b4e1f",
    "url": "/stockmoney/json/export_triplerate_cols.json"
  },
  {
    "revision": "b17cd30251414ec3dc524fd4b03bb8ce",
    "url": "/stockmoney/json/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json/export_water_cols.json"
  },
  {
    "revision": "1ec54f9385973a013585bf6a69d8470c",
    "url": "/stockmoney/json/tech_bch.json"
  },
  {
    "revision": "83eae6f6acbd32c07f162f99d0261f9f",
    "url": "/stockmoney/json/tech_bch_cols.json"
  },
  {
    "revision": "096149a1632691e3598956e282ccd3dc",
    "url": "/stockmoney/json/tech_kd.json"
  },
  {
    "revision": "b6db58cdb5face5b47876347838e58c8",
    "url": "/stockmoney/json/tech_kd_cols.json"
  },
  {
    "revision": "b6c4276d43f1c14b0212e8e35ece0407",
    "url": "/stockmoney/json/tech_ma.json"
  },
  {
    "revision": "e39af345ce89699fb9e8dae055304b51",
    "url": "/stockmoney/json/tech_ma_cols.json"
  },
  {
    "revision": "6877963519a86b6914230d17d7f60059",
    "url": "/stockmoney/json/triplerate_gross.json"
  },
  {
    "revision": "ea76e0e03c789daca65b2b423f313407",
    "url": "/stockmoney/json/triplerate_gross_cols.json"
  },
  {
    "revision": "77fe77a2af22006ddc80c6f836231873",
    "url": "/stockmoney/json/triplerate_net.json"
  },
  {
    "revision": "3b9115c832336fbe59ef96a926b60082",
    "url": "/stockmoney/json/triplerate_net_cols.json"
  },
  {
    "revision": "35a0bbc9cfcc821a19adaeb849955be3",
    "url": "/stockmoney/json/triplerate_opp.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json/triplerate_opp_cols.json"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json_otc/.dummy"
  },
  {
    "revision": "5d797ad1c518d99af000e96e644e89ef",
    "url": "/stockmoney/json_otc/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json_otc/basic_4season_cols.json"
  },
  {
    "revision": "fc4456e725c3e823ff268bad91c81bfc",
    "url": "/stockmoney/json_otc/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json_otc/basic_asset_cols.json"
  },
  {
    "revision": "9cb0a01e828cd362f510354da01d58b8",
    "url": "/stockmoney/json_otc/basic_cash.json"
  },
  {
    "revision": "3d0aec0b8eda7d242dbc01626bd2e5d7",
    "url": "/stockmoney/json_otc/basic_cash_cols.json"
  },
  {
    "revision": "4f767c848041e63e80b3a9ba98697301",
    "url": "/stockmoney/json_otc/basic_debt.json"
  },
  {
    "revision": "e01c26733cac36515f92e6865e68a5e1",
    "url": "/stockmoney/json_otc/basic_debt_cols.json"
  },
  {
    "revision": "6975fd2e6fcc5a0a787aa33083bace7b",
    "url": "/stockmoney/json_otc/basic_eps.json"
  },
  {
    "revision": "12564b9e65d1fb6739205c9b872e0db2",
    "url": "/stockmoney/json_otc/basic_eps_cols.json"
  },
  {
    "revision": "e1cb92046b5ea708557bc1c11f9b63cf",
    "url": "/stockmoney/json_otc/basic_gross.json"
  },
  {
    "revision": "67e439ba99276f0f48bde6ec59ac0a03",
    "url": "/stockmoney/json_otc/basic_gross_cols.json"
  },
  {
    "revision": "c0c6ac02a19f88e596b2533a2426aba6",
    "url": "/stockmoney/json_otc/basic_info.json"
  },
  {
    "revision": "f9ea1251cb154f7fe1e82e1cb8c268a9",
    "url": "/stockmoney/json_otc/basic_info_cols.json"
  },
  {
    "revision": "66d468347b7e562051c6e648dd80d8e0",
    "url": "/stockmoney/json_otc/basic_noi.json"
  },
  {
    "revision": "e2b9636d8765aa439538385741073af9",
    "url": "/stockmoney/json_otc/basic_noi_cols.json"
  },
  {
    "revision": "caef62bfe8d5ff14e0a2edba5f58a63e",
    "url": "/stockmoney/json_otc/basic_opm.json"
  },
  {
    "revision": "c6915ce4a47312c9cdc1f0e7acfc6b6e",
    "url": "/stockmoney/json_otc/basic_opm_cols.json"
  },
  {
    "revision": "405f383de5e206aed80004ea423215d0",
    "url": "/stockmoney/json_otc/basic_opp.json"
  },
  {
    "revision": "152f0ca5e5c703e471ed920379c8cdee",
    "url": "/stockmoney/json_otc/basic_opp_cols.json"
  },
  {
    "revision": "3fa62aaa133ebe0a71380749cd2b74a2",
    "url": "/stockmoney/json_otc/basic_roe.json"
  },
  {
    "revision": "28eb574018e78ee9f1df212bdc33ed8d",
    "url": "/stockmoney/json_otc/basic_roe_cols.json"
  },
  {
    "revision": "38ccd7b2b7a6c12270d293e556b34990",
    "url": "/stockmoney/json_otc/basic_yearw.json"
  },
  {
    "revision": "c0da6716663d7d4d089e744a64d640e6",
    "url": "/stockmoney/json_otc/basic_yearw_cols.json"
  },
  {
    "revision": "d96b8ef5cbb5c32bc59d2287ed47ec9e",
    "url": "/stockmoney/json_otc/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json_otc/deal_pct_cols.json"
  },
  {
    "revision": "5d9e0c97da2d1fbdb153742bc5fe34ce",
    "url": "/stockmoney/json_otc/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json_otc/deal_vol_cols.json"
  },
  {
    "revision": "2501a8b2239b5916e696f0a4e0231c94",
    "url": "/stockmoney/json_otc/dividend_cont.json"
  },
  {
    "revision": "ebc1fa13d0fe81617c77324e4d0963cb",
    "url": "/stockmoney/json_otc/dividend_cont_cols.json"
  },
  {
    "revision": "ce9b67c6024c1e78159bb8d67a086acd",
    "url": "/stockmoney/json_otc/dividend_stat.json"
  },
  {
    "revision": "0ae5a2a29d64812828a5b0e7a14d3492",
    "url": "/stockmoney/json_otc/dividend_stat_cols.json"
  },
  {
    "revision": "7c5b41338ce4f2969ba893586f51b335",
    "url": "/stockmoney/json_otc/dividend_yield.json"
  },
  {
    "revision": "851da35f3ae8f71e1412f57cdcd72347",
    "url": "/stockmoney/json_otc/dividend_yield_cols.json"
  },
  {
    "revision": "d417b79c22643e950726b8ab75edb3c7",
    "url": "/stockmoney/json_otc/export_stockfish.json"
  },
  {
    "revision": "9eea6075f0a86eff3efcec4900aeba29",
    "url": "/stockmoney/json_otc/export_stockfish_cols.json"
  },
  {
    "revision": "722b7293c8c13712a681d87be35589d5",
    "url": "/stockmoney/json_otc/export_triplerate.json"
  },
  {
    "revision": "39b8f7ff968f53648f9f82c6d04b4e1f",
    "url": "/stockmoney/json_otc/export_triplerate_cols.json"
  },
  {
    "revision": "b6d64812a62c59251030246dc2e08b31",
    "url": "/stockmoney/json_otc/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json_otc/export_water_cols.json"
  },
  {
    "revision": "8d33743cc43aa38308f16c8f46d44e1d",
    "url": "/stockmoney/json_otc/tech_bch.json"
  },
  {
    "revision": "83eae6f6acbd32c07f162f99d0261f9f",
    "url": "/stockmoney/json_otc/tech_bch_cols.json"
  },
  {
    "revision": "413f5709f5aaa33da87fcb25f94a5275",
    "url": "/stockmoney/json_otc/tech_kd.json"
  },
  {
    "revision": "b6db58cdb5face5b47876347838e58c8",
    "url": "/stockmoney/json_otc/tech_kd_cols.json"
  },
  {
    "revision": "e39af345ce89699fb9e8dae055304b51",
    "url": "/stockmoney/json_otc/tech_ma_cols.json"
  },
  {
    "revision": "ef38244416f13d3d549b3a065ae9a12c",
    "url": "/stockmoney/json_otc/triplerate_gross.json"
  },
  {
    "revision": "ea76e0e03c789daca65b2b423f313407",
    "url": "/stockmoney/json_otc/triplerate_gross_cols.json"
  },
  {
    "revision": "11cc209c637ea6bd6d209e979637fdb1",
    "url": "/stockmoney/json_otc/triplerate_net.json"
  },
  {
    "revision": "3b9115c832336fbe59ef96a926b60082",
    "url": "/stockmoney/json_otc/triplerate_net_cols.json"
  },
  {
    "revision": "20121e778d051e4741efc8d3d16d7840",
    "url": "/stockmoney/json_otc/triplerate_opp.json"
  },
  {
    "revision": "d751713988987e9331980363e24189ce",
    "url": "/stockmoney/json_otc/triplerate_opp_cols.json"
  },
  {
    "revision": "b96e0d5a5df171b63ae60164bac0e3af",
    "url": "/stockmoney/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/stockmoney/robots.txt"
  },
  {
    "revision": "26105635a7627e9379d5",
    "url": "/stockmoney/static/css/app.1efd3c95.css"
  },
  {
    "revision": "00a14ddebf3604813825",
    "url": "/stockmoney/static/css/chunk-vendors.eae4093c.css"
  },
  {
    "revision": "ecb3bfc03db10b6f9d6e23e710d5c953",
    "url": "/stockmoney/static/img/logo.ecb3bfc0.png"
  },
  {
    "revision": "85ce6e4334a2eeb8390e",
    "url": "/stockmoney/static/js/about.3644c617.js"
  },
  {
    "revision": "26105635a7627e9379d5",
    "url": "/stockmoney/static/js/app.76af627c.js"
  },
  {
    "revision": "00a14ddebf3604813825",
    "url": "/stockmoney/static/js/chunk-vendors.2d8e5b65.js"
  }
]);