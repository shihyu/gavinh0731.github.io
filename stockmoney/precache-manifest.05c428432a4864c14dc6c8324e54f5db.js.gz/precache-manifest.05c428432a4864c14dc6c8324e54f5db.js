self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "721f3042d283766c26c04162b5b34a8e",
    "url": "/stockmoney/index.html"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json/.dummy"
  },
  {
    "revision": "feb9fa31472319a1a0a6dd821388abbd",
    "url": "/stockmoney/json/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json/basic_4season_cols.json"
  },
  {
    "revision": "68838bc013d88eac965ee11690cd47b0",
    "url": "/stockmoney/json/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json/basic_asset_cols.json"
  },
  {
    "revision": "aa40603f6d3b44db3f692548b67bb56d",
    "url": "/stockmoney/json/basic_cash.json"
  },
  {
    "revision": "ead1d8cd91923caea1b49295c613e4cf",
    "url": "/stockmoney/json/basic_cash_cols.json"
  },
  {
    "revision": "0c3e9d64c39a3534247bd45ba752e659",
    "url": "/stockmoney/json/basic_debt.json"
  },
  {
    "revision": "7307fda79e8d1e90baa525f0b5a889aa",
    "url": "/stockmoney/json/basic_debt_cols.json"
  },
  {
    "revision": "7b29b2ba006322abbf042e34ed83949e",
    "url": "/stockmoney/json/basic_eps.json"
  },
  {
    "revision": "66864955438aee55a0b17d391d8a3976",
    "url": "/stockmoney/json/basic_eps_cols.json"
  },
  {
    "revision": "4c75da5af961d75ea48f9345f4a59f33",
    "url": "/stockmoney/json/basic_gross.json"
  },
  {
    "revision": "274714bf780651303cb0d63452e7b6a4",
    "url": "/stockmoney/json/basic_gross_cols.json"
  },
  {
    "revision": "04df9c66046eb1a97febb590b23f9f1e",
    "url": "/stockmoney/json/basic_info.json"
  },
  {
    "revision": "2dbdaa83e5d85419907f0945a8bbb99d",
    "url": "/stockmoney/json/basic_info_cols.json"
  },
  {
    "revision": "f3a138c7bbf1541f1c526bb4b67a9c4e",
    "url": "/stockmoney/json/basic_noi.json"
  },
  {
    "revision": "cd56a3b87a246d6481bf93b56c04c71d",
    "url": "/stockmoney/json/basic_noi_cols.json"
  },
  {
    "revision": "b76b33d2cbfa04dbfcfa1ccdc47b39d6",
    "url": "/stockmoney/json/basic_opm.json"
  },
  {
    "revision": "ff324b172da74482fd4ca73717d41707",
    "url": "/stockmoney/json/basic_opm_cols.json"
  },
  {
    "revision": "71dda2f1fc47dc9799119eca2f7299ab",
    "url": "/stockmoney/json/basic_opp.json"
  },
  {
    "revision": "58be18968b1dbad3fdda3abc38baa1ef",
    "url": "/stockmoney/json/basic_opp_cols.json"
  },
  {
    "revision": "ec371dc2dea6dba3cc06cc1a2d96a22c",
    "url": "/stockmoney/json/basic_roe.json"
  },
  {
    "revision": "e14cfd5e43334aa70b39be9a12d07a4d",
    "url": "/stockmoney/json/basic_roe_cols.json"
  },
  {
    "revision": "5d2601cf7f0deed65659eef1c3d65dd0",
    "url": "/stockmoney/json/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json/basic_yearw_cols.json"
  },
  {
    "revision": "30eeffb533b94574571f62e6e948757e",
    "url": "/stockmoney/json/chip_director.json"
  },
  {
    "revision": "445c91556b3ba2174c23d46aeb07af79",
    "url": "/stockmoney/json/chip_director1.json"
  },
  {
    "revision": "9245b933efe32254018a0a6e9a6c8613",
    "url": "/stockmoney/json/chip_director1_cols.json"
  },
  {
    "revision": "ba685680f209bd232663c0cad36622cd",
    "url": "/stockmoney/json/chip_director3.json"
  },
  {
    "revision": "b856d752ee7572bba69b5bfefbe9e41b",
    "url": "/stockmoney/json/chip_director3_cols.json"
  },
  {
    "revision": "4fc0c4d410fcb38b86eef6b4976f6438",
    "url": "/stockmoney/json/chip_director5.json"
  },
  {
    "revision": "825ba91683006403a96e4ead7ebc2e2c",
    "url": "/stockmoney/json/chip_director5_cols.json"
  },
  {
    "revision": "9bbbf6600d4c03482470ae7a8ed48118",
    "url": "/stockmoney/json/chip_director_cols.json"
  },
  {
    "revision": "254b3dea4b04f0919426dbdd991bc26e",
    "url": "/stockmoney/json/chip_legal.json"
  },
  {
    "revision": "d7e02491040240f9cb7da3e58c364e5d",
    "url": "/stockmoney/json/chip_legal_cols.json"
  },
  {
    "revision": "48d49f0629dd70f04e6d9487a1792d91",
    "url": "/stockmoney/json/chip_trust.json"
  },
  {
    "revision": "5fd5d28bcd216b4388792d1f1ca56305",
    "url": "/stockmoney/json/chip_trust_cols.json"
  },
  {
    "revision": "e5cc6a3849dc54ca596a2fd814e69083",
    "url": "/stockmoney/json/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json/deal_pct_cols.json"
  },
  {
    "revision": "49bfa929786e26966c24b0fb7899d5a3",
    "url": "/stockmoney/json/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json/deal_vol_cols.json"
  },
  {
    "revision": "54eb5406d0d4531526f37fa3584c884a",
    "url": "/stockmoney/json/dividend_cont.json"
  },
  {
    "revision": "e98f37eaa810fd912b66473ef4aec297",
    "url": "/stockmoney/json/dividend_cont_cols.json"
  },
  {
    "revision": "57a150ad895b4c26fa4f60e353bcd382",
    "url": "/stockmoney/json/dividend_stat.json"
  },
  {
    "revision": "7b46c4ee9490fee469b1dd6e9cead7ea",
    "url": "/stockmoney/json/dividend_stat_2015.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2015_cols.json"
  },
  {
    "revision": "9dc9e7653404fe35351614cc426e0a05",
    "url": "/stockmoney/json/dividend_stat_2016.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2016_cols.json"
  },
  {
    "revision": "64a07dcec42af1d887d8facc88dd1f17",
    "url": "/stockmoney/json/dividend_stat_2017.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2017_cols.json"
  },
  {
    "revision": "c667fbd731d2df0a7b2e8ec4675446d9",
    "url": "/stockmoney/json/dividend_stat_2018.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2018_cols.json"
  },
  {
    "revision": "db776db8b9a98d7176be931a5da92dee",
    "url": "/stockmoney/json/dividend_stat_2019.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2019_cols.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json/dividend_stat_cols.json"
  },
  {
    "revision": "efa0bea59d18369c0e8d6a00cad4cc85",
    "url": "/stockmoney/json/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json/dividend_yield_cols.json"
  },
  {
    "revision": "51d38d212d7fcc374a2b4daa973c9f11",
    "url": "/stockmoney/json/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json/export_director_cols.json"
  },
  {
    "revision": "ebf2a76e7e41723ac528c71a4d596469",
    "url": "/stockmoney/json/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json/export_incomerate_cols.json"
  },
  {
    "revision": "cc30cba6204be018a76b2953f0258570",
    "url": "/stockmoney/json/export_stockfish.json"
  },
  {
    "revision": "32911b54153344868aa71b078b98f046",
    "url": "/stockmoney/json/export_stockfish_cols.json"
  },
  {
    "revision": "4466761ab1e64a65b2381b3d2bb7a451",
    "url": "/stockmoney/json/export_triplerate.json"
  },
  {
    "revision": "a625f25eee5bf1c3f165bc86c455ce79",
    "url": "/stockmoney/json/export_triplerate_cols.json"
  },
  {
    "revision": "f377a1f88cc76692dc34e8294623d588",
    "url": "/stockmoney/json/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json/export_water_cols.json"
  },
  {
    "revision": "a1741278e4f00c9866de6db03b0f674d",
    "url": "/stockmoney/json/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json/export_yield_cols.json"
  },
  {
    "revision": "b29e6fbbd97629259820a5af2d8c1a72",
    "url": "/stockmoney/json/my_eps.json"
  },
  {
    "revision": "28cd60fb03c2df50655952e1f4c173ac",
    "url": "/stockmoney/json/my_eps_cols.json"
  },
  {
    "revision": "2108657a1180943775fa47cccdd1b37f",
    "url": "/stockmoney/json/tech_bch.json"
  },
  {
    "revision": "4ceab57a8c9a6cd7e19f2b097e934cc2",
    "url": "/stockmoney/json/tech_bch_cols.json"
  },
  {
    "revision": "8bcf7ab2c2a7944fdac1e552ce276e24",
    "url": "/stockmoney/json/tech_beta.json"
  },
  {
    "revision": "8f09f6a30643cd54d5275425bea06c52",
    "url": "/stockmoney/json/tech_beta_cols.json"
  },
  {
    "revision": "984e26e5288c18e21b3111a4cb412ab4",
    "url": "/stockmoney/json/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json/tech_kd_cols.json"
  },
  {
    "revision": "ce28c96b8d8b9bffeabb7d4ce4de2692",
    "url": "/stockmoney/json/tech_ma.json"
  },
  {
    "revision": "0312283011ee3335e1c1333e9725ace1",
    "url": "/stockmoney/json/tech_ma_cols.json"
  },
  {
    "revision": "206a469e46df866b4daffa0e96ba9b03",
    "url": "/stockmoney/json/triplerate_gross.json"
  },
  {
    "revision": "5469832f0b4ae990a85072e4717595ed",
    "url": "/stockmoney/json/triplerate_gross_cols.json"
  },
  {
    "revision": "0fe9fff01e1f952954eaac761b705f9b",
    "url": "/stockmoney/json/triplerate_net.json"
  },
  {
    "revision": "7748e7d98dfc390c2eb9bc26fb672b7c",
    "url": "/stockmoney/json/triplerate_net_cols.json"
  },
  {
    "revision": "55f8dec1ce1e759ba35c1a33363df3f7",
    "url": "/stockmoney/json/triplerate_opp.json"
  },
  {
    "revision": "3b0ef50989e8a276d1190df309181591",
    "url": "/stockmoney/json/triplerate_opp_cols.json"
  },
  {
    "revision": "0f506ffb06ff1d061b6b320161761444",
    "url": "/stockmoney/json/year_eps.json"
  },
  {
    "revision": "8fb3259b3f3986610ba1061858250a49",
    "url": "/stockmoney/json/year_eps_cols.json"
  },
  {
    "revision": "a647cb5876248434e653a4ef38fd18c4",
    "url": "/stockmoney/json/year_roe.json"
  },
  {
    "revision": "90978e8f62da33b222c6023ced35e468",
    "url": "/stockmoney/json/year_roe_cols.json"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json_otc/.dummy"
  },
  {
    "revision": "0c32ab366ee38a8f4cf56bb52099018d",
    "url": "/stockmoney/json_otc/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json_otc/basic_4season_cols.json"
  },
  {
    "revision": "890d01068be6e0f06c3f8e9498835789",
    "url": "/stockmoney/json_otc/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json_otc/basic_asset_cols.json"
  },
  {
    "revision": "cc33421466743df87898f3dd9d3a6e17",
    "url": "/stockmoney/json_otc/basic_cash.json"
  },
  {
    "revision": "7d1089ee66af9674dabfe9e5e861f733",
    "url": "/stockmoney/json_otc/basic_cash_cols.json"
  },
  {
    "revision": "5cc43b3dfe641d8ded7fcd89bf52c9f2",
    "url": "/stockmoney/json_otc/basic_debt.json"
  },
  {
    "revision": "2a6b83cf334df5ae6a9e65893012e833",
    "url": "/stockmoney/json_otc/basic_debt_cols.json"
  },
  {
    "revision": "961d770b0db35725a9f8923f1273ee8e",
    "url": "/stockmoney/json_otc/basic_eps.json"
  },
  {
    "revision": "a6958b0520157a4d9ce276002f372550",
    "url": "/stockmoney/json_otc/basic_eps_cols.json"
  },
  {
    "revision": "d774bcf627a349d04cc248a8fdaa8172",
    "url": "/stockmoney/json_otc/basic_gross.json"
  },
  {
    "revision": "18da34c009fc7b46e889ec084d0b75a6",
    "url": "/stockmoney/json_otc/basic_gross_cols.json"
  },
  {
    "revision": "f8bc813737820b197477494cb49693f5",
    "url": "/stockmoney/json_otc/basic_info.json"
  },
  {
    "revision": "2dbdaa83e5d85419907f0945a8bbb99d",
    "url": "/stockmoney/json_otc/basic_info_cols.json"
  },
  {
    "revision": "ce892b25003c58d8b238a0ca31c8e316",
    "url": "/stockmoney/json_otc/basic_noi.json"
  },
  {
    "revision": "dfb553a4e4e9824bd9644f75794cb865",
    "url": "/stockmoney/json_otc/basic_noi_cols.json"
  },
  {
    "revision": "cf646860501e61522176b4d4ae80d686",
    "url": "/stockmoney/json_otc/basic_opm.json"
  },
  {
    "revision": "1d8c9ff86b5739de621e11e9c246d183",
    "url": "/stockmoney/json_otc/basic_opm_cols.json"
  },
  {
    "revision": "e57c850aa8662292f9066eae0e856204",
    "url": "/stockmoney/json_otc/basic_opp.json"
  },
  {
    "revision": "8258792256fa1699efbc9fa6dd18e3f4",
    "url": "/stockmoney/json_otc/basic_opp_cols.json"
  },
  {
    "revision": "137729fbdc02409666a89ad0783c717c",
    "url": "/stockmoney/json_otc/basic_roe.json"
  },
  {
    "revision": "5a43ea428015c489b62425f16b4924ee",
    "url": "/stockmoney/json_otc/basic_roe_cols.json"
  },
  {
    "revision": "7669561c45d210fd08c36721d55cc762",
    "url": "/stockmoney/json_otc/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json_otc/basic_yearw_cols.json"
  },
  {
    "revision": "92167ad826590a3e0baa4c461b9974a4",
    "url": "/stockmoney/json_otc/chip_director.json"
  },
  {
    "revision": "c1351bf30245ecd5209fb613f829e118",
    "url": "/stockmoney/json_otc/chip_director1.json"
  },
  {
    "revision": "f9146b966dfd77db0815d4d76be2f95a",
    "url": "/stockmoney/json_otc/chip_director1_cols.json"
  },
  {
    "revision": "dbb2a12643ee162c3c6f0dec9ff0c575",
    "url": "/stockmoney/json_otc/chip_director3.json"
  },
  {
    "revision": "2443007c508c710095c9852dcfbcbf90",
    "url": "/stockmoney/json_otc/chip_director3_cols.json"
  },
  {
    "revision": "739cce1010562e233e9366eaaba9cb27",
    "url": "/stockmoney/json_otc/chip_director5.json"
  },
  {
    "revision": "2899f8c6ca20e9574aeb80f81a52a0d4",
    "url": "/stockmoney/json_otc/chip_director5_cols.json"
  },
  {
    "revision": "51e09fcd7a526fc9bf57bd6136d0da91",
    "url": "/stockmoney/json_otc/chip_director_cols.json"
  },
  {
    "revision": "86a1e46a8603c17a2440ca98b3bb72fd",
    "url": "/stockmoney/json_otc/chip_legal.json"
  },
  {
    "revision": "d7e02491040240f9cb7da3e58c364e5d",
    "url": "/stockmoney/json_otc/chip_legal_cols.json"
  },
  {
    "revision": "9750ed7bc6f3879b9d76496120bb8787",
    "url": "/stockmoney/json_otc/chip_trust.json"
  },
  {
    "revision": "fecc398de2cf4696c3d156dd0da35961",
    "url": "/stockmoney/json_otc/chip_trust_cols.json"
  },
  {
    "revision": "d3b957a1c0f7141c64ada6bca7b344fa",
    "url": "/stockmoney/json_otc/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json_otc/deal_pct_cols.json"
  },
  {
    "revision": "dff76963485073dea0b92217d0a8e0c0",
    "url": "/stockmoney/json_otc/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json_otc/deal_vol_cols.json"
  },
  {
    "revision": "30eb0d00adfb81af95183b4d5636204c",
    "url": "/stockmoney/json_otc/dividend_cont.json"
  },
  {
    "revision": "e98f37eaa810fd912b66473ef4aec297",
    "url": "/stockmoney/json_otc/dividend_cont_cols.json"
  },
  {
    "revision": "1a432bfb9a0a9fb1897396319b3a1f66",
    "url": "/stockmoney/json_otc/dividend_stat.json"
  },
  {
    "revision": "415cfda5bedf25fe33a1861d92edfefb",
    "url": "/stockmoney/json_otc/dividend_stat_2015.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2015_cols.json"
  },
  {
    "revision": "d71a98e525129400779bffa3b2fec9cf",
    "url": "/stockmoney/json_otc/dividend_stat_2016.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2016_cols.json"
  },
  {
    "revision": "cc6bad586fb8f4d5ce783716d1d28b4f",
    "url": "/stockmoney/json_otc/dividend_stat_2017.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2017_cols.json"
  },
  {
    "revision": "6d43a5a58c19d6a27757d65f228651c2",
    "url": "/stockmoney/json_otc/dividend_stat_2018.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2018_cols.json"
  },
  {
    "revision": "a50c8da39ce7cbcdbed6e213aa61a55a",
    "url": "/stockmoney/json_otc/dividend_stat_2019.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2019_cols.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json_otc/dividend_stat_cols.json"
  },
  {
    "revision": "89ea95d05f5d33623c328d4216e51b2a",
    "url": "/stockmoney/json_otc/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json_otc/dividend_yield_cols.json"
  },
  {
    "revision": "277500d45ee84da4f87c7cbf2a08bab6",
    "url": "/stockmoney/json_otc/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json_otc/export_director_cols.json"
  },
  {
    "revision": "2434417daea48e0cce0fb10eb2a5e4c6",
    "url": "/stockmoney/json_otc/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json_otc/export_incomerate_cols.json"
  },
  {
    "revision": "c5e95e2ad9835db04b297b2ecd1ecde4",
    "url": "/stockmoney/json_otc/export_stockfish.json"
  },
  {
    "revision": "32911b54153344868aa71b078b98f046",
    "url": "/stockmoney/json_otc/export_stockfish_cols.json"
  },
  {
    "revision": "38141d08773554bbd75d39aab4cf4657",
    "url": "/stockmoney/json_otc/export_triplerate.json"
  },
  {
    "revision": "a625f25eee5bf1c3f165bc86c455ce79",
    "url": "/stockmoney/json_otc/export_triplerate_cols.json"
  },
  {
    "revision": "ff44ad8cb7fcfc05d2e8957317fca4d0",
    "url": "/stockmoney/json_otc/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json_otc/export_water_cols.json"
  },
  {
    "revision": "b7e195103e118cc9d9e3f596a27ef493",
    "url": "/stockmoney/json_otc/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json_otc/export_yield_cols.json"
  },
  {
    "revision": "c4090813e20d7e097fdd2aeefea48d20",
    "url": "/stockmoney/json_otc/my_eps.json"
  },
  {
    "revision": "28cd60fb03c2df50655952e1f4c173ac",
    "url": "/stockmoney/json_otc/my_eps_cols.json"
  },
  {
    "revision": "f8d42cf9a745ec569500b862cd82210a",
    "url": "/stockmoney/json_otc/tech_bch.json"
  },
  {
    "revision": "4ceab57a8c9a6cd7e19f2b097e934cc2",
    "url": "/stockmoney/json_otc/tech_bch_cols.json"
  },
  {
    "revision": "3390fae758547cc37fe5f41012cced68",
    "url": "/stockmoney/json_otc/tech_beta.json"
  },
  {
    "revision": "4bb937eaf819207728fd1032030d72a4",
    "url": "/stockmoney/json_otc/tech_beta_cols.json"
  },
  {
    "revision": "d57f95864ad2670c692dc2c23745767e",
    "url": "/stockmoney/json_otc/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json_otc/tech_kd_cols.json"
  },
  {
    "revision": "6e6915d0453fd9815670e0e80e5c6449",
    "url": "/stockmoney/json_otc/tech_ma.json"
  },
  {
    "revision": "0312283011ee3335e1c1333e9725ace1",
    "url": "/stockmoney/json_otc/tech_ma_cols.json"
  },
  {
    "revision": "3799e1b2d845aa237e41859f67b94f1f",
    "url": "/stockmoney/json_otc/triplerate_gross.json"
  },
  {
    "revision": "8115998c3a2d5716777f7cb8d77b0bde",
    "url": "/stockmoney/json_otc/triplerate_gross_cols.json"
  },
  {
    "revision": "c7d2a2e78fb3ce9e81f503e757721312",
    "url": "/stockmoney/json_otc/triplerate_net.json"
  },
  {
    "revision": "4427e408793e2f67812e80e691997ac9",
    "url": "/stockmoney/json_otc/triplerate_net_cols.json"
  },
  {
    "revision": "6861630e4db173934bf7f4336620e416",
    "url": "/stockmoney/json_otc/triplerate_opp.json"
  },
  {
    "revision": "6c9bc8b1fd66ca20d9da740fd507d48f",
    "url": "/stockmoney/json_otc/triplerate_opp_cols.json"
  },
  {
    "revision": "a7a869384e4c0a9ad0c52bd42e10512c",
    "url": "/stockmoney/json_otc/year_eps.json"
  },
  {
    "revision": "d9081e137cc92db2b15f6fa9daf8f045",
    "url": "/stockmoney/json_otc/year_eps_cols.json"
  },
  {
    "revision": "68cd8df916755d50ed73051d1d0d4dea",
    "url": "/stockmoney/json_otc/year_roe.json"
  },
  {
    "revision": "f9dde937031c105f668eb50c39a1395e",
    "url": "/stockmoney/json_otc/year_roe_cols.json"
  },
  {
    "revision": "b96e0d5a5df171b63ae60164bac0e3af",
    "url": "/stockmoney/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/stockmoney/robots.txt"
  },
  {
    "revision": "dedaf489001e7843eb22",
    "url": "/stockmoney/static/css/app.efe109e9.css"
  },
  {
    "revision": "00a14ddebf3604813825",
    "url": "/stockmoney/static/css/chunk-vendors.eae4093c.css"
  },
  {
    "revision": "ecb3bfc03db10b6f9d6e23e710d5c953",
    "url": "/stockmoney/static/img/logo.ecb3bfc0.png"
  },
  {
    "revision": "85ce6e4334a2eeb8390e",
    "url": "/stockmoney/static/js/about.3644c617.js"
  },
  {
    "revision": "dedaf489001e7843eb22",
    "url": "/stockmoney/static/js/app.6a3933fb.js"
  },
  {
    "revision": "00a14ddebf3604813825",
    "url": "/stockmoney/static/js/chunk-vendors.2d8e5b65.js"
  }
]);