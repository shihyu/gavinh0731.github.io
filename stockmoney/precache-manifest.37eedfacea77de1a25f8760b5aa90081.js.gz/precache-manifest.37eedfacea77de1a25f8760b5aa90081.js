self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "647353a1131bfd7506c1d1616a64391e",
    "url": "/stockmoney/index.html"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json/.dummy"
  },
  {
    "revision": "b2a2d9017920f7b8cc9d5677167519a4",
    "url": "/stockmoney/json/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json/basic_4season_cols.json"
  },
  {
    "revision": "260b322f64d251ba560ab647f8615ad8",
    "url": "/stockmoney/json/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json/basic_asset_cols.json"
  },
  {
    "revision": "3e6a84e881c7a560ae1198616091e220",
    "url": "/stockmoney/json/basic_cash.json"
  },
  {
    "revision": "b0d3f6e126b9b49b0393c4001320a703",
    "url": "/stockmoney/json/basic_cash_cols.json"
  },
  {
    "revision": "fd4a2fb5b96820904bf97b61e8ef7806",
    "url": "/stockmoney/json/basic_debt.json"
  },
  {
    "revision": "5df52f8d37e81a4c3ae52a334beba689",
    "url": "/stockmoney/json/basic_debt_cols.json"
  },
  {
    "revision": "3a62ce37c81152f51b5bc7334c2f44d4",
    "url": "/stockmoney/json/basic_eps.json"
  },
  {
    "revision": "db38baf506295201dd824346edab6fc4",
    "url": "/stockmoney/json/basic_eps_cols.json"
  },
  {
    "revision": "8d6306fd6adb85e8ca2a9ad26eb3ebda",
    "url": "/stockmoney/json/basic_gross.json"
  },
  {
    "revision": "6702c2b344cad7de41f6805808c95c6e",
    "url": "/stockmoney/json/basic_gross_cols.json"
  },
  {
    "revision": "a9655f2d0496f1eba876fdbe1ed81544",
    "url": "/stockmoney/json/basic_info.json"
  },
  {
    "revision": "2dbdaa83e5d85419907f0945a8bbb99d",
    "url": "/stockmoney/json/basic_info_cols.json"
  },
  {
    "revision": "3d172743441947e587adef77e7a71646",
    "url": "/stockmoney/json/basic_noi.json"
  },
  {
    "revision": "3f10acfde8f78f90afa40cb016c648a3",
    "url": "/stockmoney/json/basic_noi_cols.json"
  },
  {
    "revision": "e0391c709d5c7377c1ce395546c9548b",
    "url": "/stockmoney/json/basic_opm.json"
  },
  {
    "revision": "5cf2375a6fb5733084c8038628313c7a",
    "url": "/stockmoney/json/basic_opm_cols.json"
  },
  {
    "revision": "d8341cd6d328e490bf8cf5c2cf65cdf9",
    "url": "/stockmoney/json/basic_opp.json"
  },
  {
    "revision": "810ae873f6a4a6fd9b7fd7dd92feec95",
    "url": "/stockmoney/json/basic_opp_cols.json"
  },
  {
    "revision": "ab879c65094c65129f1806cccb557f07",
    "url": "/stockmoney/json/basic_roe.json"
  },
  {
    "revision": "730e8ba07b34682764beadae31102b7b",
    "url": "/stockmoney/json/basic_roe_cols.json"
  },
  {
    "revision": "577e6269f2e34bd08616d830e47acf35",
    "url": "/stockmoney/json/basic_rvn.json"
  },
  {
    "revision": "6c8f7da2dc1274d0c5612d38c84f52f9",
    "url": "/stockmoney/json/basic_rvn_cols.json"
  },
  {
    "revision": "e503264f2a9431e85f973ea02e51dd79",
    "url": "/stockmoney/json/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json/basic_yearw_cols.json"
  },
  {
    "revision": "e39b20bd57e568041c250d0cd4991b3a",
    "url": "/stockmoney/json/chip_director.json"
  },
  {
    "revision": "575bd4dd2dfb900ccb43bcf9e6d9e338",
    "url": "/stockmoney/json/chip_director1.json"
  },
  {
    "revision": "9245b933efe32254018a0a6e9a6c8613",
    "url": "/stockmoney/json/chip_director1_cols.json"
  },
  {
    "revision": "c5e92c70ce4b2cf4025f649224850a98",
    "url": "/stockmoney/json/chip_director3.json"
  },
  {
    "revision": "b856d752ee7572bba69b5bfefbe9e41b",
    "url": "/stockmoney/json/chip_director3_cols.json"
  },
  {
    "revision": "b8308d4d019c7621bdc42320a6ee4a15",
    "url": "/stockmoney/json/chip_director5.json"
  },
  {
    "revision": "825ba91683006403a96e4ead7ebc2e2c",
    "url": "/stockmoney/json/chip_director5_cols.json"
  },
  {
    "revision": "9bbbf6600d4c03482470ae7a8ed48118",
    "url": "/stockmoney/json/chip_director_cols.json"
  },
  {
    "revision": "bb643b195bc908e3bb560be4adc47d2d",
    "url": "/stockmoney/json/chip_legal.json"
  },
  {
    "revision": "d7e02491040240f9cb7da3e58c364e5d",
    "url": "/stockmoney/json/chip_legal_cols.json"
  },
  {
    "revision": "4ba956dccd3515d2689d1c1afe5af578",
    "url": "/stockmoney/json/chip_trust.json"
  },
  {
    "revision": "5fd5d28bcd216b4388792d1f1ca56305",
    "url": "/stockmoney/json/chip_trust_cols.json"
  },
  {
    "revision": "286929d8b54458f73a10aa4c805b0404",
    "url": "/stockmoney/json/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json/deal_pct_cols.json"
  },
  {
    "revision": "9a68ce06455ff62d048ab9319a24f4a9",
    "url": "/stockmoney/json/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json/deal_vol_cols.json"
  },
  {
    "revision": "ef26ff950dbe920c3e375140c464a1ab",
    "url": "/stockmoney/json/dividend_cont.json"
  },
  {
    "revision": "e98f37eaa810fd912b66473ef4aec297",
    "url": "/stockmoney/json/dividend_cont_cols.json"
  },
  {
    "revision": "760c258ea0e382e305c187600a81852f",
    "url": "/stockmoney/json/dividend_stat.json"
  },
  {
    "revision": "7b46c4ee9490fee469b1dd6e9cead7ea",
    "url": "/stockmoney/json/dividend_stat_2015.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2015_cols.json"
  },
  {
    "revision": "9dc9e7653404fe35351614cc426e0a05",
    "url": "/stockmoney/json/dividend_stat_2016.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2016_cols.json"
  },
  {
    "revision": "64a07dcec42af1d887d8facc88dd1f17",
    "url": "/stockmoney/json/dividend_stat_2017.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2017_cols.json"
  },
  {
    "revision": "c667fbd731d2df0a7b2e8ec4675446d9",
    "url": "/stockmoney/json/dividend_stat_2018.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2018_cols.json"
  },
  {
    "revision": "db776db8b9a98d7176be931a5da92dee",
    "url": "/stockmoney/json/dividend_stat_2019.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2019_cols.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json/dividend_stat_cols.json"
  },
  {
    "revision": "4c9613abc7974e008b67c4d49fe33f06",
    "url": "/stockmoney/json/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json/dividend_yield_cols.json"
  },
  {
    "revision": "840f2275912521da72d160477d567506",
    "url": "/stockmoney/json/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json/export_director_cols.json"
  },
  {
    "revision": "b8ebfe18a907a3191f8bcd857f26aece",
    "url": "/stockmoney/json/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json/export_incomerate_cols.json"
  },
  {
    "revision": "4946b9a7996b386058f3ce416da21e85",
    "url": "/stockmoney/json/export_stockfish.json"
  },
  {
    "revision": "aa76bf1d9931072a3fe9c3e216868eac",
    "url": "/stockmoney/json/export_stockfish_cols.json"
  },
  {
    "revision": "aaaa934448e0639f7708bddfb966990e",
    "url": "/stockmoney/json/export_triplerate.json"
  },
  {
    "revision": "a625f25eee5bf1c3f165bc86c455ce79",
    "url": "/stockmoney/json/export_triplerate_cols.json"
  },
  {
    "revision": "4af306830bf7029de6d56a54348c982d",
    "url": "/stockmoney/json/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json/export_water_cols.json"
  },
  {
    "revision": "a1741278e4f00c9866de6db03b0f674d",
    "url": "/stockmoney/json/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json/export_yield_cols.json"
  },
  {
    "revision": "e25d75937f8969207b3068053d40e86a",
    "url": "/stockmoney/json/my_eps.json"
  },
  {
    "revision": "87b98bb7ccff2628d43fe83db7362e93",
    "url": "/stockmoney/json/my_eps_cols.json"
  },
  {
    "revision": "57b61b0bbbf962fdd400d3ebd05e67db",
    "url": "/stockmoney/json/tech_bch.json"
  },
  {
    "revision": "4ceab57a8c9a6cd7e19f2b097e934cc2",
    "url": "/stockmoney/json/tech_bch_cols.json"
  },
  {
    "revision": "161ab6a90304dfebab856a7245607b29",
    "url": "/stockmoney/json/tech_beta.json"
  },
  {
    "revision": "8f09f6a30643cd54d5275425bea06c52",
    "url": "/stockmoney/json/tech_beta_cols.json"
  },
  {
    "revision": "af045637b431abdcfc9560a033aaf227",
    "url": "/stockmoney/json/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json/tech_kd_cols.json"
  },
  {
    "revision": "178ae436ae4db75466e7213499d6c530",
    "url": "/stockmoney/json/tech_ma.json"
  },
  {
    "revision": "0312283011ee3335e1c1333e9725ace1",
    "url": "/stockmoney/json/tech_ma_cols.json"
  },
  {
    "revision": "0af4eea872735a25021be1c1db318c67",
    "url": "/stockmoney/json/triplerate_gross.json"
  },
  {
    "revision": "c181b21f6163624682d326d39e21b21c",
    "url": "/stockmoney/json/triplerate_gross_cols.json"
  },
  {
    "revision": "2b48f34becd504e0a44106a04516e900",
    "url": "/stockmoney/json/triplerate_net.json"
  },
  {
    "revision": "5fc192c1b0cdd48c05f982785f8423f8",
    "url": "/stockmoney/json/triplerate_net_cols.json"
  },
  {
    "revision": "ed67b17916999f2cd3681278c50c6de7",
    "url": "/stockmoney/json/triplerate_opp.json"
  },
  {
    "revision": "2b664b4f7933d132c9b55ac7e0f9c78a",
    "url": "/stockmoney/json/triplerate_opp_cols.json"
  },
  {
    "revision": "a3b8c69c4d9ac7d0e91fd18c61dd9b96",
    "url": "/stockmoney/json/year_eps.json"
  },
  {
    "revision": "d8754011067821cacac05d90b2dffdd9",
    "url": "/stockmoney/json/year_eps_cols.json"
  },
  {
    "revision": "735e2f8021125ad0d2899b1999434d6b",
    "url": "/stockmoney/json/year_roe.json"
  },
  {
    "revision": "066ff2e2d6cd4902d9892c9acce8195b",
    "url": "/stockmoney/json/year_roe_cols.json"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json_otc/.dummy"
  },
  {
    "revision": "0ee994e9dcdf83e36c6406d62ef0aa1a",
    "url": "/stockmoney/json_otc/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json_otc/basic_4season_cols.json"
  },
  {
    "revision": "800f2e69b35b287c08bb80eab648c80d",
    "url": "/stockmoney/json_otc/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json_otc/basic_asset_cols.json"
  },
  {
    "revision": "dd671cf902d0df075bc6063fa9bfd941",
    "url": "/stockmoney/json_otc/basic_cash.json"
  },
  {
    "revision": "ae919b9b8f7c25e34b351a5e3eb6e79c",
    "url": "/stockmoney/json_otc/basic_cash_cols.json"
  },
  {
    "revision": "b37c2d064c0676d4c25591d6e1fb625a",
    "url": "/stockmoney/json_otc/basic_debt.json"
  },
  {
    "revision": "25b05bb6efbd426961fc86e6319e0e80",
    "url": "/stockmoney/json_otc/basic_debt_cols.json"
  },
  {
    "revision": "af2c3fd0b8e6fa3c20146675a97a5c70",
    "url": "/stockmoney/json_otc/basic_eps.json"
  },
  {
    "revision": "4dafb238d0868357e1321efa27dda649",
    "url": "/stockmoney/json_otc/basic_eps_cols.json"
  },
  {
    "revision": "ef6f494aafe03c2cfad271744bdb5255",
    "url": "/stockmoney/json_otc/basic_gross.json"
  },
  {
    "revision": "45080f599285d7939c556fb9622e635b",
    "url": "/stockmoney/json_otc/basic_gross_cols.json"
  },
  {
    "revision": "b337551f7fd0c8aa977271f4e66665f0",
    "url": "/stockmoney/json_otc/basic_info.json"
  },
  {
    "revision": "2dbdaa83e5d85419907f0945a8bbb99d",
    "url": "/stockmoney/json_otc/basic_info_cols.json"
  },
  {
    "revision": "0da9d9255b68b7d19c0d5cf4877b11cf",
    "url": "/stockmoney/json_otc/basic_noi.json"
  },
  {
    "revision": "64e9a3d3da815961952816d7c2395d2a",
    "url": "/stockmoney/json_otc/basic_noi_cols.json"
  },
  {
    "revision": "36d94318e2ed234d4a82de82192a89b4",
    "url": "/stockmoney/json_otc/basic_opm.json"
  },
  {
    "revision": "edbac0cff2792337f4ca903330fcdc0e",
    "url": "/stockmoney/json_otc/basic_opm_cols.json"
  },
  {
    "revision": "85dd2c3efef3416eb2f2a870e40fb2b6",
    "url": "/stockmoney/json_otc/basic_opp.json"
  },
  {
    "revision": "ebe21d1dcc2dea1cc37d0bf93941495a",
    "url": "/stockmoney/json_otc/basic_opp_cols.json"
  },
  {
    "revision": "cb5af06654e691188b9b950970dbd6c7",
    "url": "/stockmoney/json_otc/basic_roe.json"
  },
  {
    "revision": "af510b3b7db6a2b5c778e6305eb9eecb",
    "url": "/stockmoney/json_otc/basic_roe_cols.json"
  },
  {
    "revision": "4b30ffcdfa6aa78bf424bed6b70b2e1f",
    "url": "/stockmoney/json_otc/basic_rvn.json"
  },
  {
    "revision": "4aed09c9f2964d32e1b4d7f39cda1fff",
    "url": "/stockmoney/json_otc/basic_rvn_cols.json"
  },
  {
    "revision": "aaa6576c7256f1e74d5a1b91a48ec640",
    "url": "/stockmoney/json_otc/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json_otc/basic_yearw_cols.json"
  },
  {
    "revision": "7ef2d8d0b41afb76222277336938718d",
    "url": "/stockmoney/json_otc/chip_director.json"
  },
  {
    "revision": "57a368845e63e962f5503b103c81d631",
    "url": "/stockmoney/json_otc/chip_director1.json"
  },
  {
    "revision": "f9146b966dfd77db0815d4d76be2f95a",
    "url": "/stockmoney/json_otc/chip_director1_cols.json"
  },
  {
    "revision": "d1dbf2ab9bb78c9663ddb1e1c18c2aa9",
    "url": "/stockmoney/json_otc/chip_director3.json"
  },
  {
    "revision": "2443007c508c710095c9852dcfbcbf90",
    "url": "/stockmoney/json_otc/chip_director3_cols.json"
  },
  {
    "revision": "9a0cdc2bfbfc320116f307298087082a",
    "url": "/stockmoney/json_otc/chip_director5.json"
  },
  {
    "revision": "2899f8c6ca20e9574aeb80f81a52a0d4",
    "url": "/stockmoney/json_otc/chip_director5_cols.json"
  },
  {
    "revision": "51e09fcd7a526fc9bf57bd6136d0da91",
    "url": "/stockmoney/json_otc/chip_director_cols.json"
  },
  {
    "revision": "86108e92a006c61e0d4949d5a8a2ecb7",
    "url": "/stockmoney/json_otc/chip_legal.json"
  },
  {
    "revision": "d7e02491040240f9cb7da3e58c364e5d",
    "url": "/stockmoney/json_otc/chip_legal_cols.json"
  },
  {
    "revision": "0109e05e19cb7e399586bf2a7699731d",
    "url": "/stockmoney/json_otc/chip_trust.json"
  },
  {
    "revision": "fecc398de2cf4696c3d156dd0da35961",
    "url": "/stockmoney/json_otc/chip_trust_cols.json"
  },
  {
    "revision": "1b6739811ba8ac51135cd4ed2604aff3",
    "url": "/stockmoney/json_otc/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json_otc/deal_pct_cols.json"
  },
  {
    "revision": "0f394e6c45965a75a0c8ef2f37ad1f75",
    "url": "/stockmoney/json_otc/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json_otc/deal_vol_cols.json"
  },
  {
    "revision": "db3d919966af01ee03a39a5c97cd80b7",
    "url": "/stockmoney/json_otc/dividend_cont.json"
  },
  {
    "revision": "e98f37eaa810fd912b66473ef4aec297",
    "url": "/stockmoney/json_otc/dividend_cont_cols.json"
  },
  {
    "revision": "0baedd51627f5c4d3928287549ef8f3f",
    "url": "/stockmoney/json_otc/dividend_stat.json"
  },
  {
    "revision": "21c6d862c4542447ccccfd08ff51bce9",
    "url": "/stockmoney/json_otc/dividend_stat_2015.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2015_cols.json"
  },
  {
    "revision": "d6c9d1101ef9f25794f0467f67dd9a17",
    "url": "/stockmoney/json_otc/dividend_stat_2016.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2016_cols.json"
  },
  {
    "revision": "531e4b866bc78364065f34d415dc117f",
    "url": "/stockmoney/json_otc/dividend_stat_2017.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2017_cols.json"
  },
  {
    "revision": "96fb1225ec93dfa7421a9d369ee8de90",
    "url": "/stockmoney/json_otc/dividend_stat_2018.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2018_cols.json"
  },
  {
    "revision": "2c47c220e75f515787167b98f504246d",
    "url": "/stockmoney/json_otc/dividend_stat_2019.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2019_cols.json"
  },
  {
    "revision": "00409984eab5803f4b79487d03e0091c",
    "url": "/stockmoney/json_otc/dividend_stat_cols.json"
  },
  {
    "revision": "c30d1eb85a7fc988f6a8395b4c450c27",
    "url": "/stockmoney/json_otc/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json_otc/dividend_yield_cols.json"
  },
  {
    "revision": "a83fe1ad9afb63292fbffdd98e312184",
    "url": "/stockmoney/json_otc/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json_otc/export_director_cols.json"
  },
  {
    "revision": "27f4b98684f10fb8ab0ff72c9a10ce68",
    "url": "/stockmoney/json_otc/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json_otc/export_incomerate_cols.json"
  },
  {
    "revision": "9fea5036ca030c802833886fdd709928",
    "url": "/stockmoney/json_otc/export_stockfish.json"
  },
  {
    "revision": "aa76bf1d9931072a3fe9c3e216868eac",
    "url": "/stockmoney/json_otc/export_stockfish_cols.json"
  },
  {
    "revision": "b488fa1b882fe6b8edfb94295f1fce7f",
    "url": "/stockmoney/json_otc/export_triplerate.json"
  },
  {
    "revision": "a625f25eee5bf1c3f165bc86c455ce79",
    "url": "/stockmoney/json_otc/export_triplerate_cols.json"
  },
  {
    "revision": "b859a8ede72b3f1a3ef599a7feb62072",
    "url": "/stockmoney/json_otc/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json_otc/export_water_cols.json"
  },
  {
    "revision": "495167dc4674a4ac6d6d8d5038dbef97",
    "url": "/stockmoney/json_otc/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json_otc/export_yield_cols.json"
  },
  {
    "revision": "e140134fe1f29ac6aa96d64b775f7a51",
    "url": "/stockmoney/json_otc/my_eps.json"
  },
  {
    "revision": "87b98bb7ccff2628d43fe83db7362e93",
    "url": "/stockmoney/json_otc/my_eps_cols.json"
  },
  {
    "revision": "5b0c3ccf2a5f76922adb927a5a2adee9",
    "url": "/stockmoney/json_otc/tech_bch.json"
  },
  {
    "revision": "4ceab57a8c9a6cd7e19f2b097e934cc2",
    "url": "/stockmoney/json_otc/tech_bch_cols.json"
  },
  {
    "revision": "31595ec75d58a829ead68e8519aa52ee",
    "url": "/stockmoney/json_otc/tech_beta.json"
  },
  {
    "revision": "4bb937eaf819207728fd1032030d72a4",
    "url": "/stockmoney/json_otc/tech_beta_cols.json"
  },
  {
    "revision": "c64339a1c7d4d1add668d9ca5b4d3738",
    "url": "/stockmoney/json_otc/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json_otc/tech_kd_cols.json"
  },
  {
    "revision": "cf671f2fb26eb67bc58278a9daf9a48b",
    "url": "/stockmoney/json_otc/tech_ma.json"
  },
  {
    "revision": "0312283011ee3335e1c1333e9725ace1",
    "url": "/stockmoney/json_otc/tech_ma_cols.json"
  },
  {
    "revision": "67e4afbd34e0e194df65f42f8612ef10",
    "url": "/stockmoney/json_otc/triplerate_gross.json"
  },
  {
    "revision": "5dbc9e96cdc54b9e952bd5d4920fce71",
    "url": "/stockmoney/json_otc/triplerate_gross_cols.json"
  },
  {
    "revision": "89d15295438b590329090813f579d8c2",
    "url": "/stockmoney/json_otc/triplerate_net.json"
  },
  {
    "revision": "3d7c83f97b38cafa042d4ad4ecfa3104",
    "url": "/stockmoney/json_otc/triplerate_net_cols.json"
  },
  {
    "revision": "dd6ba1888d48e5b7def9089cfef28b4d",
    "url": "/stockmoney/json_otc/triplerate_opp.json"
  },
  {
    "revision": "b52d5e2fcd0ce8bfe332795396c7a656",
    "url": "/stockmoney/json_otc/triplerate_opp_cols.json"
  },
  {
    "revision": "906a6a671282ca1bbadd88222b849cd1",
    "url": "/stockmoney/json_otc/year_eps.json"
  },
  {
    "revision": "f20b867d6cf6b4131ab75f1a3b677b5a",
    "url": "/stockmoney/json_otc/year_eps_cols.json"
  },
  {
    "revision": "b787df67499a78748b2d945316287425",
    "url": "/stockmoney/json_otc/year_roe.json"
  },
  {
    "revision": "1f1f835656eaeee1cb011d4d8fa01a7e",
    "url": "/stockmoney/json_otc/year_roe_cols.json"
  },
  {
    "revision": "b96e0d5a5df171b63ae60164bac0e3af",
    "url": "/stockmoney/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/stockmoney/robots.txt"
  },
  {
    "revision": "aa8315e9112c0c52365e",
    "url": "/stockmoney/static/css/app.91034a19.css"
  },
  {
    "revision": "00a14ddebf3604813825",
    "url": "/stockmoney/static/css/chunk-vendors.eae4093c.css"
  },
  {
    "revision": "ecb3bfc03db10b6f9d6e23e710d5c953",
    "url": "/stockmoney/static/img/logo.ecb3bfc0.png"
  },
  {
    "revision": "85ce6e4334a2eeb8390e",
    "url": "/stockmoney/static/js/about.3644c617.js"
  },
  {
    "revision": "aa8315e9112c0c52365e",
    "url": "/stockmoney/static/js/app.f6e31a0c.js"
  },
  {
    "revision": "00a14ddebf3604813825",
    "url": "/stockmoney/static/js/chunk-vendors.2d8e5b65.js"
  }
]);