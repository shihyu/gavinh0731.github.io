self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "fa3260761ee5fa26c85aca412b954f65",
    "url": "/stockmoney/index.html"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json/.dummy"
  },
  {
    "revision": "19983fd9371afac2512d43bdee243cde",
    "url": "/stockmoney/json/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json/basic_4season_cols.json"
  },
  {
    "revision": "e105ac5d496a4484392efd8510fbe2d1",
    "url": "/stockmoney/json/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json/basic_asset_cols.json"
  },
  {
    "revision": "cab78aee68dcc71c960561537fb3d6e7",
    "url": "/stockmoney/json/basic_cash.json"
  },
  {
    "revision": "5349424348aa80afa6ae8346580a712f",
    "url": "/stockmoney/json/basic_cash_cols.json"
  },
  {
    "revision": "3260ac8190305729ede87cb722b2b175",
    "url": "/stockmoney/json/basic_debt.json"
  },
  {
    "revision": "149c233a96836df1a575318ec2a1509d",
    "url": "/stockmoney/json/basic_debt_cols.json"
  },
  {
    "revision": "0c51502afab49f0c14ba07ba1aa489cb",
    "url": "/stockmoney/json/basic_eps.json"
  },
  {
    "revision": "b90192ca9115275349bfea323a394569",
    "url": "/stockmoney/json/basic_eps_cols.json"
  },
  {
    "revision": "c4e28d99f152c0afffe7f1f1d51773ab",
    "url": "/stockmoney/json/basic_gross.json"
  },
  {
    "revision": "9c4dcfc402f48cb75982fe1d0615a7cb",
    "url": "/stockmoney/json/basic_gross_cols.json"
  },
  {
    "revision": "582852c1f7eeafb8665a609331e001b3",
    "url": "/stockmoney/json/basic_info.json"
  },
  {
    "revision": "4a01d4330b10e31c6048acfe2d9dde98",
    "url": "/stockmoney/json/basic_info_cols.json"
  },
  {
    "revision": "21e8032bae264b46aafa0f47eb5ae8ab",
    "url": "/stockmoney/json/basic_net.json"
  },
  {
    "revision": "2ba3ac8050a3d880496ca58318dcb7dc",
    "url": "/stockmoney/json/basic_net_cols.json"
  },
  {
    "revision": "bc99d0b4d527f6258a8b4c7ab5e62217",
    "url": "/stockmoney/json/basic_noi.json"
  },
  {
    "revision": "682d8a925174920c27df43d992708acb",
    "url": "/stockmoney/json/basic_noi_cols.json"
  },
  {
    "revision": "8cd787fd4d4a1363d045354fe92929cc",
    "url": "/stockmoney/json/basic_opm.json"
  },
  {
    "revision": "d25fc77588c0fdc65b8f3e3d57c163e8",
    "url": "/stockmoney/json/basic_opm_cols.json"
  },
  {
    "revision": "0bb8c05c1977dbd14475a581976b6395",
    "url": "/stockmoney/json/basic_opp.json"
  },
  {
    "revision": "cd5e1981364e5ab21acb32ee82608e2d",
    "url": "/stockmoney/json/basic_opp_cols.json"
  },
  {
    "revision": "06431fca6634d5c02a4150e642f31ea4",
    "url": "/stockmoney/json/basic_roe.json"
  },
  {
    "revision": "36692d25edb0355ea92b9c37564e0684",
    "url": "/stockmoney/json/basic_roe_cols.json"
  },
  {
    "revision": "efbbb8d86c1bc7a3f3008c0b39086527",
    "url": "/stockmoney/json/basic_rvn.json"
  },
  {
    "revision": "726df860aa07852a20559f1f368dd854",
    "url": "/stockmoney/json/basic_rvn_cols.json"
  },
  {
    "revision": "6e4d81116eba81ae9c77832a1b5f14ab",
    "url": "/stockmoney/json/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json/basic_yearw_cols.json"
  },
  {
    "revision": "e6f6a1717adc6c6a89d4be6f4a6b0af3",
    "url": "/stockmoney/json/chip_borrow.json"
  },
  {
    "revision": "b9d898714914df8c330d1f25fd728bd4",
    "url": "/stockmoney/json/chip_borrow_cols.json"
  },
  {
    "revision": "f53e0c908c3b1b84b5ef711908e03469",
    "url": "/stockmoney/json/chip_broker.json"
  },
  {
    "revision": "a07c8fc77597992396e367fa482d0b4b",
    "url": "/stockmoney/json/chip_director.json"
  },
  {
    "revision": "a3855cd3916138bb576eab6bf29daf45",
    "url": "/stockmoney/json/chip_director1.json"
  },
  {
    "revision": "9245b933efe32254018a0a6e9a6c8613",
    "url": "/stockmoney/json/chip_director1_cols.json"
  },
  {
    "revision": "a67dcb2fff8f8515b4a20d0af6391918",
    "url": "/stockmoney/json/chip_director3.json"
  },
  {
    "revision": "b856d752ee7572bba69b5bfefbe9e41b",
    "url": "/stockmoney/json/chip_director3_cols.json"
  },
  {
    "revision": "15a56fc4a9126dcda797ccea8f2058d5",
    "url": "/stockmoney/json/chip_director5.json"
  },
  {
    "revision": "825ba91683006403a96e4ead7ebc2e2c",
    "url": "/stockmoney/json/chip_director5_cols.json"
  },
  {
    "revision": "9bbbf6600d4c03482470ae7a8ed48118",
    "url": "/stockmoney/json/chip_director_cols.json"
  },
  {
    "revision": "21efebab2d58871efab50981d5997165",
    "url": "/stockmoney/json/chip_foreign.json"
  },
  {
    "revision": "1f66416e66912403af00c4d2366c2741",
    "url": "/stockmoney/json/chip_foreign_cols.json"
  },
  {
    "revision": "104a141d9c19308b76c02efbe5a376fd",
    "url": "/stockmoney/json/chip_holder.json"
  },
  {
    "revision": "672717b58db691e5c491065fd3720da4",
    "url": "/stockmoney/json/chip_holder_cols.json"
  },
  {
    "revision": "57841fd216c51b1e85100720f525c3ca",
    "url": "/stockmoney/json/chip_legal.json"
  },
  {
    "revision": "60a82514c04d8b46e234b6c3b7db8a4c",
    "url": "/stockmoney/json/chip_legal_cols.json"
  },
  {
    "revision": "5ec652d12573fdec0326502bc5a796f4",
    "url": "/stockmoney/json/chip_loan.json"
  },
  {
    "revision": "f9dc3e02b8b829e17677de08ed985401",
    "url": "/stockmoney/json/chip_loan_cols.json"
  },
  {
    "revision": "c4a78193affe9beab5e0871c1ee8f74c",
    "url": "/stockmoney/json/chip_trust.json"
  },
  {
    "revision": "0453c094ec1578d8b609550d9e477938",
    "url": "/stockmoney/json/chip_trust_cols.json"
  },
  {
    "revision": "89c84f4d5d32be3c82d1555f09fa04c4",
    "url": "/stockmoney/json/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json/deal_pct_cols.json"
  },
  {
    "revision": "ccb7be8738bfa60f597509db6f6457ad",
    "url": "/stockmoney/json/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json/deal_vol_cols.json"
  },
  {
    "revision": "85d30487965c80d676db5eb2606d5679",
    "url": "/stockmoney/json/dividend_cont.json"
  },
  {
    "revision": "3e8dc99836816cdedc952a126db1fa79",
    "url": "/stockmoney/json/dividend_cont_cols.json"
  },
  {
    "revision": "cb00cc5146c7561dabbe93f219d47d05",
    "url": "/stockmoney/json/dividend_stat.json"
  },
  {
    "revision": "0a114f5cffe39147488794d28cabbed4",
    "url": "/stockmoney/json/dividend_stat_2015.json"
  },
  {
    "revision": "008c79d526737b517a9a742b04502b20",
    "url": "/stockmoney/json/dividend_stat_2015_cols.json"
  },
  {
    "revision": "a3eb58c326321abe89eb7963319891f1",
    "url": "/stockmoney/json/dividend_stat_2016.json"
  },
  {
    "revision": "ec5a0a94673998b0bb4a63db93d08f4a",
    "url": "/stockmoney/json/dividend_stat_2016_cols.json"
  },
  {
    "revision": "79496de807d241313651a220ae1d13b2",
    "url": "/stockmoney/json/dividend_stat_2017.json"
  },
  {
    "revision": "e37fc91cd72912b24657ed675d9f1c8b",
    "url": "/stockmoney/json/dividend_stat_2017_cols.json"
  },
  {
    "revision": "1a8cbc95893844e6d4bcc8479ebabf64",
    "url": "/stockmoney/json/dividend_stat_2018.json"
  },
  {
    "revision": "38050d84b8d337ce366fb397e8e206f7",
    "url": "/stockmoney/json/dividend_stat_2018_cols.json"
  },
  {
    "revision": "afc3a1ab031130d25c77ba24a0902823",
    "url": "/stockmoney/json/dividend_stat_2019.json"
  },
  {
    "revision": "7ec66cdc30aa0d150bc4f797bdc131c4",
    "url": "/stockmoney/json/dividend_stat_2019_cols.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json/dividend_stat_cols.json"
  },
  {
    "revision": "b73b0873735ca9cd6666e97419852d5f",
    "url": "/stockmoney/json/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json/dividend_yield_cols.json"
  },
  {
    "revision": "0426112380331650dba87def52fb81de",
    "url": "/stockmoney/json/dk_dies.json"
  },
  {
    "revision": "0842de8223abec6d0d02135b89168710",
    "url": "/stockmoney/json/dk_dies_cols.json"
  },
  {
    "revision": "8ee5cbd92f7cbd6af5bddef886567285",
    "url": "/stockmoney/json/export_director.json"
  },
  {
    "revision": "89100efeca7bfb4d95efdab07df62a48",
    "url": "/stockmoney/json/export_director_cols.json"
  },
  {
    "revision": "38d98a85ddb40066044bbc22e20533f2",
    "url": "/stockmoney/json/export_incomerate.json"
  },
  {
    "revision": "8a782513b99c4e31cf07aca4745c38e4",
    "url": "/stockmoney/json/export_incomerate_cols.json"
  },
  {
    "revision": "2ea5e4666baa17ea82c8fbebe50ff439",
    "url": "/stockmoney/json/export_stockfish.json"
  },
  {
    "revision": "24c365c317bd950273a6bbe79b14d791",
    "url": "/stockmoney/json/export_stockfish_cols.json"
  },
  {
    "revision": "37f081a55e32fd547e7fb2384da01523",
    "url": "/stockmoney/json/export_triplerate.json"
  },
  {
    "revision": "29e0c2731cf0823c503af4580b581346",
    "url": "/stockmoney/json/export_triplerate_cols.json"
  },
  {
    "revision": "db302f4445462350e161b27b559bc9f5",
    "url": "/stockmoney/json/export_water.json"
  },
  {
    "revision": "1743dc326779ed0d0955118930c2fdc1",
    "url": "/stockmoney/json/export_water_cols.json"
  },
  {
    "revision": "9ea54aa92f7f3db00b30150916ce5d95",
    "url": "/stockmoney/json/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json/export_yield_cols.json"
  },
  {
    "revision": "2180e3e743ad3da94a62b96abda77e91",
    "url": "/stockmoney/json/my_basic.json"
  },
  {
    "revision": "295c360491ab2ad27aa285e780073787",
    "url": "/stockmoney/json/my_basic_cols.json"
  },
  {
    "revision": "9585c78f1f1abfaad7b6184779f3b080",
    "url": "/stockmoney/json/my_chip.json"
  },
  {
    "revision": "4591748299e5053668af84371363907d",
    "url": "/stockmoney/json/my_chip_cols.json"
  },
  {
    "revision": "201f29d66765759bddbd67e9999e0826",
    "url": "/stockmoney/json/my_eps.json"
  },
  {
    "revision": "87b98bb7ccff2628d43fe83db7362e93",
    "url": "/stockmoney/json/my_eps_cols.json"
  },
  {
    "revision": "de15623c89f46aa4b9a7192339b868ea",
    "url": "/stockmoney/json/my_tech.json"
  },
  {
    "revision": "8a19cc05a24dcd177b9df5db81ec28b3",
    "url": "/stockmoney/json/my_tech_cols.json"
  },
  {
    "revision": "505e5483671c3aa97588260ee821782c",
    "url": "/stockmoney/json/price_dpct.json"
  },
  {
    "revision": "111c1063358cf2cce62d1c4c3cf2a601",
    "url": "/stockmoney/json/price_dpct_cols.json"
  },
  {
    "revision": "3e38e517e5842b8cd3e79d3d33459c76",
    "url": "/stockmoney/json/price_high.json"
  },
  {
    "revision": "8f986523f915cd6a9dae0cd5f54f5d7f",
    "url": "/stockmoney/json/price_high_cols.json"
  },
  {
    "revision": "14b4fb4b08ac5b4129a4c5083c0a9c20",
    "url": "/stockmoney/json/price_mpct.json"
  },
  {
    "revision": "19f8b091eacff631ac486f7a35596c56",
    "url": "/stockmoney/json/price_mpct_cols.json"
  },
  {
    "revision": "39e6d40fb2d5f6e987e3a3e734441a88",
    "url": "/stockmoney/json/price_wpct.json"
  },
  {
    "revision": "06e2f207dffd568d93360a54eff1629d",
    "url": "/stockmoney/json/price_wpct_cols.json"
  },
  {
    "revision": "c77413da25fb2f9e740eb748f1120b03",
    "url": "/stockmoney/json/tech_bch.json"
  },
  {
    "revision": "56d227c0fc6a9c5a25f2502cc26148ab",
    "url": "/stockmoney/json/tech_bch_cols.json"
  },
  {
    "revision": "85022aa461e8c390abc143b25368b152",
    "url": "/stockmoney/json/tech_beta.json"
  },
  {
    "revision": "8f09f6a30643cd54d5275425bea06c52",
    "url": "/stockmoney/json/tech_beta_cols.json"
  },
  {
    "revision": "957b7618b075f652f5bfe7327deccda9",
    "url": "/stockmoney/json/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json/tech_kd_cols.json"
  },
  {
    "revision": "6f4285f335092d8c5949befa9a930530",
    "url": "/stockmoney/json/tech_ma.json"
  },
  {
    "revision": "5c125157702e4475325fc62420500833",
    "url": "/stockmoney/json/tech_ma_cols.json"
  },
  {
    "revision": "beaf242951743331009cbcadf253d4b4",
    "url": "/stockmoney/json/tech_makink.json"
  },
  {
    "revision": "f95de82f9706f0ab7fbcddef3c0742ee",
    "url": "/stockmoney/json/tech_makink_cols.json"
  },
  {
    "revision": "83e6998c1c6b3da19a58827e753a901c",
    "url": "/stockmoney/json/triplerate_gross.json"
  },
  {
    "revision": "bdea5894fe1ee11fe29b8c1b086f8b14",
    "url": "/stockmoney/json/triplerate_gross_cols.json"
  },
  {
    "revision": "6459732690a2a507bcbcf6d507440291",
    "url": "/stockmoney/json/triplerate_net.json"
  },
  {
    "revision": "131977477f007368864220bd92c5b140",
    "url": "/stockmoney/json/triplerate_net_cols.json"
  },
  {
    "revision": "f5ab1ae8f32c003c591fa9cc5671330c",
    "url": "/stockmoney/json/triplerate_opp.json"
  },
  {
    "revision": "101ce9c11dafd51f9b77daa28ec5e106",
    "url": "/stockmoney/json/triplerate_opp_cols.json"
  },
  {
    "revision": "4596795fba3fccc45d170bd1e41dd2ff",
    "url": "/stockmoney/json/year_eps.json"
  },
  {
    "revision": "6d3ef962007b26c6d23c4c5d7a057cc8",
    "url": "/stockmoney/json/year_eps_cols.json"
  },
  {
    "revision": "46ccc6ea5b28e01ab60382a7ae599102",
    "url": "/stockmoney/json/year_roe.json"
  },
  {
    "revision": "07c767a967283717369ecc8e0f0f7d99",
    "url": "/stockmoney/json/year_roe_cols.json"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json_otc/.dummy"
  },
  {
    "revision": "99097acb18c3a5fa4a8e96ea3924e136",
    "url": "/stockmoney/json_otc/basic_4season.json"
  },
  {
    "revision": "5af8e03d5ac2fd4ca03652dd2b98f6f0",
    "url": "/stockmoney/json_otc/basic_4season_cols.json"
  },
  {
    "revision": "336a6ec338c32cd838656b5fae0bbd15",
    "url": "/stockmoney/json_otc/basic_asset.json"
  },
  {
    "revision": "b38212d12f678a74ad6a6565339df931",
    "url": "/stockmoney/json_otc/basic_asset_cols.json"
  },
  {
    "revision": "3593042668a164e44cc5e7d7c8aaf6bf",
    "url": "/stockmoney/json_otc/basic_cash.json"
  },
  {
    "revision": "5349424348aa80afa6ae8346580a712f",
    "url": "/stockmoney/json_otc/basic_cash_cols.json"
  },
  {
    "revision": "807c8f76a4ba4c1abdbe304376e7bfa3",
    "url": "/stockmoney/json_otc/basic_debt.json"
  },
  {
    "revision": "149c233a96836df1a575318ec2a1509d",
    "url": "/stockmoney/json_otc/basic_debt_cols.json"
  },
  {
    "revision": "92595136c57b4ec799e0cd3fc4acd15d",
    "url": "/stockmoney/json_otc/basic_eps.json"
  },
  {
    "revision": "b90192ca9115275349bfea323a394569",
    "url": "/stockmoney/json_otc/basic_eps_cols.json"
  },
  {
    "revision": "6bb5b466023c741095d22042d8d97fb8",
    "url": "/stockmoney/json_otc/basic_gross.json"
  },
  {
    "revision": "9c4dcfc402f48cb75982fe1d0615a7cb",
    "url": "/stockmoney/json_otc/basic_gross_cols.json"
  },
  {
    "revision": "a677406f84399152ae58c3b4c2beedda",
    "url": "/stockmoney/json_otc/basic_info.json"
  },
  {
    "revision": "6f99a8a60e35b64e93e4e87ccbc4e5dd",
    "url": "/stockmoney/json_otc/basic_info_cols.json"
  },
  {
    "revision": "c32106bec40b7227d1451638876320c2",
    "url": "/stockmoney/json_otc/basic_net.json"
  },
  {
    "revision": "2ba3ac8050a3d880496ca58318dcb7dc",
    "url": "/stockmoney/json_otc/basic_net_cols.json"
  },
  {
    "revision": "1c6e24a126be507b41f4e802511d6d41",
    "url": "/stockmoney/json_otc/basic_noi.json"
  },
  {
    "revision": "682d8a925174920c27df43d992708acb",
    "url": "/stockmoney/json_otc/basic_noi_cols.json"
  },
  {
    "revision": "5e1e3668ce1fe3d5c13ef18d92ca08e7",
    "url": "/stockmoney/json_otc/basic_opm.json"
  },
  {
    "revision": "d25fc77588c0fdc65b8f3e3d57c163e8",
    "url": "/stockmoney/json_otc/basic_opm_cols.json"
  },
  {
    "revision": "ec1d09fd71822ce1dca24377e9890705",
    "url": "/stockmoney/json_otc/basic_opp.json"
  },
  {
    "revision": "cd5e1981364e5ab21acb32ee82608e2d",
    "url": "/stockmoney/json_otc/basic_opp_cols.json"
  },
  {
    "revision": "f0d2136b2e6000454703eccd946f92a0",
    "url": "/stockmoney/json_otc/basic_roe.json"
  },
  {
    "revision": "36692d25edb0355ea92b9c37564e0684",
    "url": "/stockmoney/json_otc/basic_roe_cols.json"
  },
  {
    "revision": "14a38245b670f39993a83fba7551bb14",
    "url": "/stockmoney/json_otc/basic_rvn.json"
  },
  {
    "revision": "726df860aa07852a20559f1f368dd854",
    "url": "/stockmoney/json_otc/basic_rvn_cols.json"
  },
  {
    "revision": "7e1c235d7359a79823ef5e1aee3abcf9",
    "url": "/stockmoney/json_otc/basic_yearw.json"
  },
  {
    "revision": "37afed6bf332938bf457759590f15e20",
    "url": "/stockmoney/json_otc/basic_yearw_cols.json"
  },
  {
    "revision": "799791bf0816304876f24bc4bb188ef7",
    "url": "/stockmoney/json_otc/chip_borrow.json"
  },
  {
    "revision": "5a8bd57521f8a67e6f158eda3faacf21",
    "url": "/stockmoney/json_otc/chip_borrow_cols.json"
  },
  {
    "revision": "506d59409aa3c0703ffffb039dafaa41",
    "url": "/stockmoney/json_otc/chip_director.json"
  },
  {
    "revision": "5d23148c707411d004af22bf3139001f",
    "url": "/stockmoney/json_otc/chip_director1.json"
  },
  {
    "revision": "8e7a0bacff28aa1cf9f5825c7712c937",
    "url": "/stockmoney/json_otc/chip_director1_cols.json"
  },
  {
    "revision": "f6fdbdbabb2d8d88c4c3061a65ebff98",
    "url": "/stockmoney/json_otc/chip_director3.json"
  },
  {
    "revision": "cb725822bf310830ac86771e76bbf7e5",
    "url": "/stockmoney/json_otc/chip_director3_cols.json"
  },
  {
    "revision": "ba0e805efb85acc07c054b4d4ff080d6",
    "url": "/stockmoney/json_otc/chip_director5.json"
  },
  {
    "revision": "9e1f67c918b55fd9c2153dc91b5ea992",
    "url": "/stockmoney/json_otc/chip_director5_cols.json"
  },
  {
    "revision": "79dce6a98cc61675f28207bb8ee66d68",
    "url": "/stockmoney/json_otc/chip_director_cols.json"
  },
  {
    "revision": "706153125439674579a73e31c2add724",
    "url": "/stockmoney/json_otc/chip_foreign.json"
  },
  {
    "revision": "e59f62dd4b9a788009bac352d7e91c12",
    "url": "/stockmoney/json_otc/chip_foreign_cols.json"
  },
  {
    "revision": "4020a7605ce8abd9d82abfd51e304738",
    "url": "/stockmoney/json_otc/chip_holder.json"
  },
  {
    "revision": "0d80a0b66a710be5c8449613ed1abad2",
    "url": "/stockmoney/json_otc/chip_holder_cols.json"
  },
  {
    "revision": "620d692ccc85ae9f4950aa85ab73f044",
    "url": "/stockmoney/json_otc/chip_legal.json"
  },
  {
    "revision": "56a5a51151871b1624874a4fe5a82f83",
    "url": "/stockmoney/json_otc/chip_legal_cols.json"
  },
  {
    "revision": "149c3e20570d58a3edfd160981ed4cf0",
    "url": "/stockmoney/json_otc/chip_loan.json"
  },
  {
    "revision": "ee402593614d4650e99e562d17e63538",
    "url": "/stockmoney/json_otc/chip_loan_cols.json"
  },
  {
    "revision": "527cb592bcedaf33139c39bd264142d1",
    "url": "/stockmoney/json_otc/chip_trust.json"
  },
  {
    "revision": "4466ee075166bd957824b4a6d6c6ddbe",
    "url": "/stockmoney/json_otc/chip_trust_cols.json"
  },
  {
    "revision": "94b78bdc490aaf15dc52cd8f346741e1",
    "url": "/stockmoney/json_otc/deal_pct.json"
  },
  {
    "revision": "6aa4eed51cba9dc1dc746762256d9659",
    "url": "/stockmoney/json_otc/deal_pct_cols.json"
  },
  {
    "revision": "b74c9f992ac2d2d5a45c20c356d1d907",
    "url": "/stockmoney/json_otc/deal_vol.json"
  },
  {
    "revision": "b27cd4bd88359e51326cd3dab8215f69",
    "url": "/stockmoney/json_otc/deal_vol_cols.json"
  },
  {
    "revision": "18b1506919cd3a3f360f3aadbd4d8a54",
    "url": "/stockmoney/json_otc/dividend_cont.json"
  },
  {
    "revision": "d770b65af07d9d64a25e81b34c57086f",
    "url": "/stockmoney/json_otc/dividend_cont_cols.json"
  },
  {
    "revision": "54ae903cb36f3b0fb39ec9bb19ce2f59",
    "url": "/stockmoney/json_otc/dividend_stat.json"
  },
  {
    "revision": "5fe70a774c5d9ce28d72f5fde0cd006c",
    "url": "/stockmoney/json_otc/dividend_stat_2015.json"
  },
  {
    "revision": "cbec2feb676f6a6aa3b239e88e6d6a2c",
    "url": "/stockmoney/json_otc/dividend_stat_2015_cols.json"
  },
  {
    "revision": "16c3da119990ee4e315144d6ef2b183c",
    "url": "/stockmoney/json_otc/dividend_stat_2016.json"
  },
  {
    "revision": "6e18d58a36f9fc2a33f01cedfe00600b",
    "url": "/stockmoney/json_otc/dividend_stat_2016_cols.json"
  },
  {
    "revision": "fbce447cfd92fcbe64c2a2ebbbac99ad",
    "url": "/stockmoney/json_otc/dividend_stat_2017.json"
  },
  {
    "revision": "297d5aebd0f10fcde9bb1a0e4ac5182e",
    "url": "/stockmoney/json_otc/dividend_stat_2017_cols.json"
  },
  {
    "revision": "ab0aad180f421833e51eb972186bdb18",
    "url": "/stockmoney/json_otc/dividend_stat_2018.json"
  },
  {
    "revision": "260b5376813e3734a06dab71d8b9bd8a",
    "url": "/stockmoney/json_otc/dividend_stat_2018_cols.json"
  },
  {
    "revision": "8d93143486c15d365513eba3f826dd09",
    "url": "/stockmoney/json_otc/dividend_stat_2019.json"
  },
  {
    "revision": "6050c49dcd02fe1bf54be9c00f3014eb",
    "url": "/stockmoney/json_otc/dividend_stat_2019_cols.json"
  },
  {
    "revision": "9b4c4be9545c11e770cbe8be386f94cb",
    "url": "/stockmoney/json_otc/dividend_stat_cols.json"
  },
  {
    "revision": "db04391bea732fe54f12ed4c3941fad1",
    "url": "/stockmoney/json_otc/dividend_yield.json"
  },
  {
    "revision": "ecb2998fde71d849b8992a7b6c4e2e3d",
    "url": "/stockmoney/json_otc/dividend_yield_cols.json"
  },
  {
    "revision": "7070d461fca9f57f911b200dd2fc5bd8",
    "url": "/stockmoney/json_otc/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json_otc/export_director_cols.json"
  },
  {
    "revision": "bf4091968a9416ed62033f7746eeee19",
    "url": "/stockmoney/json_otc/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json_otc/export_incomerate_cols.json"
  },
  {
    "revision": "cd31b8a4e6ae79c8381334b713671557",
    "url": "/stockmoney/json_otc/export_stockfish.json"
  },
  {
    "revision": "192fef50d1b0b739db62b78e28521927",
    "url": "/stockmoney/json_otc/export_stockfish_cols.json"
  },
  {
    "revision": "06644a4d0d24006b9520f689110d209f",
    "url": "/stockmoney/json_otc/export_triplerate.json"
  },
  {
    "revision": "a625f25eee5bf1c3f165bc86c455ce79",
    "url": "/stockmoney/json_otc/export_triplerate_cols.json"
  },
  {
    "revision": "962233c053e6db9fe7b8fc8ba435e819",
    "url": "/stockmoney/json_otc/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json_otc/export_water_cols.json"
  },
  {
    "revision": "c55c440719a695161addc6d1fe124f60",
    "url": "/stockmoney/json_otc/export_yield.json"
  },
  {
    "revision": "49e7cdd201cc3d5a6cd680c3a5aa3c7f",
    "url": "/stockmoney/json_otc/my_basic.json"
  },
  {
    "revision": "12af128c5c8cb61ac4c2042aefe1f0cf",
    "url": "/stockmoney/json_otc/my_eps.json"
  },
  {
    "revision": "ee41870e2a556afa1b4a4cb967744e6d",
    "url": "/stockmoney/json_otc/my_eps_cols.json"
  },
  {
    "revision": "334ba87cb4ae2bff9881047c24f321d9",
    "url": "/stockmoney/json_otc/price_dpct.json"
  },
  {
    "revision": "4a8550ef29380c4fa8d8ac437919bf01",
    "url": "/stockmoney/json_otc/price_dpct_cols.json"
  },
  {
    "revision": "283cfaa255e8093f94689f4333345b7c",
    "url": "/stockmoney/json_otc/price_mpct.json"
  },
  {
    "revision": "f49e4c8c592ee192541945e62871c3d3",
    "url": "/stockmoney/json_otc/price_mpct_cols.json"
  },
  {
    "revision": "79fd51e6f951f7f5de0d90b0438d71eb",
    "url": "/stockmoney/json_otc/price_wpct.json"
  },
  {
    "revision": "5274839ff9361763e75b70bb12e266d6",
    "url": "/stockmoney/json_otc/price_wpct_cols.json"
  },
  {
    "revision": "08532aae6bfa169eeeb51f60b0e36c5e",
    "url": "/stockmoney/json_otc/tech_bch.json"
  },
  {
    "revision": "1f3501a7241684346326f6b20fef29ab",
    "url": "/stockmoney/json_otc/tech_bch_cols.json"
  },
  {
    "revision": "6f85459fb7a30416436be6269da6105e",
    "url": "/stockmoney/json_otc/tech_beta.json"
  },
  {
    "revision": "1d1993c61608814513697231793da5ff",
    "url": "/stockmoney/json_otc/tech_beta_cols.json"
  },
  {
    "revision": "9c61fba81b56a5b658ba1da30517e251",
    "url": "/stockmoney/json_otc/tech_kd.json"
  },
  {
    "revision": "4f5d6ca8656dd449a555f2892c29746e",
    "url": "/stockmoney/json_otc/tech_kd_cols.json"
  },
  {
    "revision": "c1779410604e48dd2ab45a17dfd47d38",
    "url": "/stockmoney/json_otc/triplerate_gross.json"
  },
  {
    "revision": "bdea5894fe1ee11fe29b8c1b086f8b14",
    "url": "/stockmoney/json_otc/triplerate_gross_cols.json"
  },
  {
    "revision": "5bf3455b5acaaed71c2d5948022a1962",
    "url": "/stockmoney/json_otc/triplerate_net.json"
  },
  {
    "revision": "131977477f007368864220bd92c5b140",
    "url": "/stockmoney/json_otc/triplerate_net_cols.json"
  },
  {
    "revision": "bbcc6017c033faec0c6605cdfe51e8cd",
    "url": "/stockmoney/json_otc/triplerate_opp.json"
  },
  {
    "revision": "101ce9c11dafd51f9b77daa28ec5e106",
    "url": "/stockmoney/json_otc/triplerate_opp_cols.json"
  },
  {
    "revision": "5dcfb484147ce45f9a231cedfcdcbe47",
    "url": "/stockmoney/json_otc/year_eps.json"
  },
  {
    "revision": "6d3ef962007b26c6d23c4c5d7a057cc8",
    "url": "/stockmoney/json_otc/year_eps_cols.json"
  },
  {
    "revision": "1d3c1e041ee03df06535e814cc09dd6f",
    "url": "/stockmoney/json_otc/year_roe.json"
  },
  {
    "revision": "07c767a967283717369ecc8e0f0f7d99",
    "url": "/stockmoney/json_otc/year_roe_cols.json"
  },
  {
    "revision": "b96e0d5a5df171b63ae60164bac0e3af",
    "url": "/stockmoney/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/stockmoney/robots.txt"
  },
  {
    "revision": "b5519dbfdf2f88009150",
    "url": "/stockmoney/static/css/app.144a22eb.css"
  },
  {
    "revision": "a7bd39673262647df6da",
    "url": "/stockmoney/static/css/chunk-vendors.eae4093c.css"
  },
  {
    "revision": "ecb3bfc03db10b6f9d6e23e710d5c953",
    "url": "/stockmoney/static/img/logo.ecb3bfc0.png"
  },
  {
    "revision": "658800e4ddcdedaaa231",
    "url": "/stockmoney/static/js/about.6cc0e21f.js"
  },
  {
    "revision": "b5519dbfdf2f88009150",
    "url": "/stockmoney/static/js/app.d8eed5dc.js"
  },
  {
    "revision": "a7bd39673262647df6da",
    "url": "/stockmoney/static/js/chunk-vendors.1f857820.js"
  }
]);