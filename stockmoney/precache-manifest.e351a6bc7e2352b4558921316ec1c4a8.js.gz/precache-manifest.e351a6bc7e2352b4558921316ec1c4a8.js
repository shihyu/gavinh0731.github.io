self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "66f8f250353cd7b183dab292903da7b6",
    "url": "/stockmoney/index.html"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json/.dummy"
  },
  {
    "revision": "e85877799d18056d95be34f4e662e7c5",
    "url": "/stockmoney/json/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json/basic_4season_cols.json"
  },
  {
    "revision": "6fbb063f095191355a866c622588dfbe",
    "url": "/stockmoney/json/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json/basic_asset_cols.json"
  },
  {
    "revision": "db94024eac728aa47b6dc3145b32fea6",
    "url": "/stockmoney/json/basic_cash.json"
  },
  {
    "revision": "b6e6d3f20553910eff7fd0a869df2479",
    "url": "/stockmoney/json/basic_debt.json"
  },
  {
    "revision": "e00513c4f0332d1d7657f50b4a342be1",
    "url": "/stockmoney/json/basic_eps.json"
  },
  {
    "revision": "944e29520f67397db969a8e69a22f0bc",
    "url": "/stockmoney/json/basic_gross.json"
  },
  {
    "revision": "0417895ab5a47eb66825657dce35342a",
    "url": "/stockmoney/json/basic_info.json"
  },
  {
    "revision": "2dbdaa83e5d85419907f0945a8bbb99d",
    "url": "/stockmoney/json/basic_info_cols.json"
  },
  {
    "revision": "1a556ba955590e9e8a2e89266f5a08ee",
    "url": "/stockmoney/json/basic_noi.json"
  },
  {
    "revision": "3d15d65c0620f9ebca29cf2cb81fb43f",
    "url": "/stockmoney/json/basic_opm.json"
  },
  {
    "revision": "f8aee28dac900dd0589c8c5291f914dd",
    "url": "/stockmoney/json/basic_opp.json"
  },
  {
    "revision": "1bd992695b684df9d4f17533b2bbee4d",
    "url": "/stockmoney/json/basic_roe.json"
  },
  {
    "revision": "0eb07831bb709830d02704d6e5dbd190",
    "url": "/stockmoney/json/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json/basic_yearw_cols.json"
  },
  {
    "revision": "b0c779700a6f4d6b9e29c104ce800538",
    "url": "/stockmoney/json/chip_director.json"
  },
  {
    "revision": "210692a1c8c5179f06a0e7ba1c4fc400",
    "url": "/stockmoney/json/chip_director1.json"
  },
  {
    "revision": "65ba18e49b9d5516315cc9c6eb7dbc8c",
    "url": "/stockmoney/json/chip_director3.json"
  },
  {
    "revision": "2d5008e021c23b9bcbb4229105e69dd1",
    "url": "/stockmoney/json/chip_director5.json"
  },
  {
    "revision": "b8c98e65f51ba4e1ffc7a5aa1b872666",
    "url": "/stockmoney/json/chip_legal.json"
  },
  {
    "revision": "b59a83a724f06b92285af06a7012e28a",
    "url": "/stockmoney/json/chip_legal_cols.json"
  },
  {
    "revision": "f7dd04a12064239ee4f9a020a0d36ed7",
    "url": "/stockmoney/json/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json/deal_pct_cols.json"
  },
  {
    "revision": "d31b3ed5d9edce78dfa4c03c04d9d149",
    "url": "/stockmoney/json/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json/deal_vol_cols.json"
  },
  {
    "revision": "fe37edfe3382d73e1108eb9a1fcdbe30",
    "url": "/stockmoney/json/dividend_cont.json"
  },
  {
    "revision": "e98f37eaa810fd912b66473ef4aec297",
    "url": "/stockmoney/json/dividend_cont_cols.json"
  },
  {
    "revision": "a0fb517dba590736525587032b851a0b",
    "url": "/stockmoney/json/dividend_stat.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json/dividend_stat_cols.json"
  },
  {
    "revision": "c34bf62cd762bf8788003decfdfaa5a8",
    "url": "/stockmoney/json/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json/dividend_yield_cols.json"
  },
  {
    "revision": "82e404011a4d265b57662b5374dad1de",
    "url": "/stockmoney/json/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json/export_director_cols.json"
  },
  {
    "revision": "e3cb5da1371bc54d3d62d7beb020f470",
    "url": "/stockmoney/json/export_stockfish.json"
  },
  {
    "revision": "a80fc9a43765684f7559542e3aca31cc",
    "url": "/stockmoney/json/export_stockfish_cols.json"
  },
  {
    "revision": "6631dd963702f01bb3265f840c9bf188",
    "url": "/stockmoney/json/export_triplerate.json"
  },
  {
    "revision": "861354d45af0f2c2668223c028057f85",
    "url": "/stockmoney/json/export_triplerate_cols.json"
  },
  {
    "revision": "96b05cd7bd9ab6877fdea390602ce171",
    "url": "/stockmoney/json/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json/export_water_cols.json"
  },
  {
    "revision": "b0fa7c85435afbb3b15686b580fd2bea",
    "url": "/stockmoney/json/tech_bch.json"
  },
  {
    "revision": "4ceab57a8c9a6cd7e19f2b097e934cc2",
    "url": "/stockmoney/json/tech_bch_cols.json"
  },
  {
    "revision": "120ead59f35b901bbc0e6255bc79e4aa",
    "url": "/stockmoney/json/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json/tech_kd_cols.json"
  },
  {
    "revision": "b6c4276d43f1c14b0212e8e35ece0407",
    "url": "/stockmoney/json/tech_ma.json"
  },
  {
    "revision": "0312283011ee3335e1c1333e9725ace1",
    "url": "/stockmoney/json/tech_ma_cols.json"
  },
  {
    "revision": "5be30709028e91a9716b4aec7a9aae1e",
    "url": "/stockmoney/json/triplerate_gross.json"
  },
  {
    "revision": "e0107d2576ee6f1cb17b21fe316c96cb",
    "url": "/stockmoney/json/triplerate_net.json"
  },
  {
    "revision": "5fe394c3c0a42ae06177096276d0eac8",
    "url": "/stockmoney/json/triplerate_opp.json"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json_otc/.dummy"
  },
  {
    "revision": "1ce5db6a9e176e04bb4057cd4a4d0801",
    "url": "/stockmoney/json_otc/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json_otc/basic_4season_cols.json"
  },
  {
    "revision": "b4c807036c51086317fa544ae25e5271",
    "url": "/stockmoney/json_otc/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json_otc/basic_asset_cols.json"
  },
  {
    "revision": "6733b9a0b6afc9ab519b7828ebaff4b9",
    "url": "/stockmoney/json_otc/basic_cash.json"
  },
  {
    "revision": "1c5f2a4641d397f6c2b7e3fa5a351c6c",
    "url": "/stockmoney/json_otc/basic_debt.json"
  },
  {
    "revision": "0758a2f9c45472263538b10f8e7586b8",
    "url": "/stockmoney/json_otc/basic_eps.json"
  },
  {
    "revision": "8620b2ab7c62db789940f8a2a33de6e7",
    "url": "/stockmoney/json_otc/basic_gross.json"
  },
  {
    "revision": "d788a3b141b2e0bb99e94c4f4a9c3f58",
    "url": "/stockmoney/json_otc/basic_info.json"
  },
  {
    "revision": "2dbdaa83e5d85419907f0945a8bbb99d",
    "url": "/stockmoney/json_otc/basic_info_cols.json"
  },
  {
    "revision": "7e3a4b99469f3a0110238f2d848b391e",
    "url": "/stockmoney/json_otc/basic_noi.json"
  },
  {
    "revision": "08ccb6dcb313e8a18db1ae6d29b2c5e0",
    "url": "/stockmoney/json_otc/basic_opm.json"
  },
  {
    "revision": "782847bfe77bf96a1b28824d37c88360",
    "url": "/stockmoney/json_otc/basic_opp.json"
  },
  {
    "revision": "692239a812088d82fb3264f89b16c5d8",
    "url": "/stockmoney/json_otc/basic_roe.json"
  },
  {
    "revision": "b99ce2a2052c26de74d61886080f668c",
    "url": "/stockmoney/json_otc/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json_otc/basic_yearw_cols.json"
  },
  {
    "revision": "d714faa6941ac4c10c4c550f7caab395",
    "url": "/stockmoney/json_otc/chip_director.json"
  },
  {
    "revision": "6c3efd8f63bba2aecd94299a75ed4d76",
    "url": "/stockmoney/json_otc/chip_director1.json"
  },
  {
    "revision": "f9146b966dfd77db0815d4d76be2f95a",
    "url": "/stockmoney/json_otc/chip_director1_cols.json"
  },
  {
    "revision": "af292c903a8aa5ecf8546af36b4d873e",
    "url": "/stockmoney/json_otc/chip_director3.json"
  },
  {
    "revision": "2443007c508c710095c9852dcfbcbf90",
    "url": "/stockmoney/json_otc/chip_director3_cols.json"
  },
  {
    "revision": "71009865db9aeb6609a9cc710b4e0344",
    "url": "/stockmoney/json_otc/chip_director5.json"
  },
  {
    "revision": "2899f8c6ca20e9574aeb80f81a52a0d4",
    "url": "/stockmoney/json_otc/chip_director5_cols.json"
  },
  {
    "revision": "51e09fcd7a526fc9bf57bd6136d0da91",
    "url": "/stockmoney/json_otc/chip_director_cols.json"
  },
  {
    "revision": "d53466b222001700bc40ef3e56339f29",
    "url": "/stockmoney/json_otc/chip_legal.json"
  },
  {
    "revision": "b59a83a724f06b92285af06a7012e28a",
    "url": "/stockmoney/json_otc/chip_legal_cols.json"
  },
  {
    "revision": "54156293b724d668ca976560d80a033a",
    "url": "/stockmoney/json_otc/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json_otc/deal_pct_cols.json"
  },
  {
    "revision": "981019b2a1b3524af266354948638a8d",
    "url": "/stockmoney/json_otc/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json_otc/deal_vol_cols.json"
  },
  {
    "revision": "b94a9d282feec2b01a496c573b1a4bb8",
    "url": "/stockmoney/json_otc/dividend_cont.json"
  },
  {
    "revision": "e98f37eaa810fd912b66473ef4aec297",
    "url": "/stockmoney/json_otc/dividend_cont_cols.json"
  },
  {
    "revision": "384c3182b0bc0eb6af9716306c14f240",
    "url": "/stockmoney/json_otc/dividend_stat.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json_otc/dividend_stat_cols.json"
  },
  {
    "revision": "0f93d2d35992d8e7248b887875ee025f",
    "url": "/stockmoney/json_otc/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json_otc/dividend_yield_cols.json"
  },
  {
    "revision": "91f03b6ee66b77556cf4817901a640d4",
    "url": "/stockmoney/json_otc/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json_otc/export_director_cols.json"
  },
  {
    "revision": "b6854fdb610289a3f57661a3f0ccef6c",
    "url": "/stockmoney/json_otc/export_stockfish.json"
  },
  {
    "revision": "a80fc9a43765684f7559542e3aca31cc",
    "url": "/stockmoney/json_otc/export_stockfish_cols.json"
  },
  {
    "revision": "fe7cac42d11821526858eb1175960837",
    "url": "/stockmoney/json_otc/export_triplerate.json"
  },
  {
    "revision": "861354d45af0f2c2668223c028057f85",
    "url": "/stockmoney/json_otc/export_triplerate_cols.json"
  },
  {
    "revision": "a7e56325c609c604640394e125da71a3",
    "url": "/stockmoney/json_otc/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json_otc/export_water_cols.json"
  },
  {
    "revision": "04d7c0c25551ea6788e85412b1b98f01",
    "url": "/stockmoney/json_otc/tech_bch.json"
  },
  {
    "revision": "4ceab57a8c9a6cd7e19f2b097e934cc2",
    "url": "/stockmoney/json_otc/tech_bch_cols.json"
  },
  {
    "revision": "a67058019b92b8819f8bcbbb029f7597",
    "url": "/stockmoney/json_otc/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json_otc/tech_kd_cols.json"
  },
  {
    "revision": "0312283011ee3335e1c1333e9725ace1",
    "url": "/stockmoney/json_otc/tech_ma_cols.json"
  },
  {
    "revision": "6015652b01eca99a4263e35accc7e7de",
    "url": "/stockmoney/json_otc/triplerate_gross.json"
  },
  {
    "revision": "5c147a57d1959fee026ec4fabac00a93",
    "url": "/stockmoney/json_otc/triplerate_net.json"
  },
  {
    "revision": "bfb7768ff6638edbff4577cb2e8ef364",
    "url": "/stockmoney/json_otc/triplerate_opp.json"
  },
  {
    "revision": "b96e0d5a5df171b63ae60164bac0e3af",
    "url": "/stockmoney/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/stockmoney/robots.txt"
  },
  {
    "revision": "23fa6f1038a4812c34a8",
    "url": "/stockmoney/static/css/app.89860cdf.css"
  },
  {
    "revision": "00a14ddebf3604813825",
    "url": "/stockmoney/static/css/chunk-vendors.eae4093c.css"
  },
  {
    "revision": "ecb3bfc03db10b6f9d6e23e710d5c953",
    "url": "/stockmoney/static/img/logo.ecb3bfc0.png"
  },
  {
    "revision": "85ce6e4334a2eeb8390e",
    "url": "/stockmoney/static/js/about.3644c617.js"
  },
  {
    "revision": "23fa6f1038a4812c34a8",
    "url": "/stockmoney/static/js/app.7528a1e9.js"
  },
  {
    "revision": "00a14ddebf3604813825",
    "url": "/stockmoney/static/js/chunk-vendors.2d8e5b65.js"
  }
]);