self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "439eda02fd9a3496350d25571675b528",
    "url": "/stockmoney/index.html"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json/.dummy"
  },
  {
    "revision": "4ab6818b1806e152faf198ee3be307d4",
    "url": "/stockmoney/json/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json/basic_4season_cols.json"
  },
  {
    "revision": "7c345cb85f12b1d6bed23e9276347fa9",
    "url": "/stockmoney/json/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json/basic_asset_cols.json"
  },
  {
    "revision": "a97b644f85706d06f64d027ca040842c",
    "url": "/stockmoney/json/basic_cash.json"
  },
  {
    "revision": "47256836fd61e6f1ca493dae0834f5b9",
    "url": "/stockmoney/json/basic_cash_cols.json"
  },
  {
    "revision": "ed7ede5603e4d96c1a2fbf7c42d02fd5",
    "url": "/stockmoney/json/basic_debt.json"
  },
  {
    "revision": "2c91cea2a6741af81ef30140c36d77a8",
    "url": "/stockmoney/json/basic_debt_cols.json"
  },
  {
    "revision": "dcfd16112baf6de09c2cac493e5841ea",
    "url": "/stockmoney/json/basic_eps.json"
  },
  {
    "revision": "e11fd0eaa9972ee5a746f7da4a9c75cd",
    "url": "/stockmoney/json/basic_eps_cols.json"
  },
  {
    "revision": "8ab4b5d7e382ac7ed2ddf2adb5c0677b",
    "url": "/stockmoney/json/basic_gross.json"
  },
  {
    "revision": "d8c4d608f40b3dcc3dd8af9fbbb6b2bc",
    "url": "/stockmoney/json/basic_gross_cols.json"
  },
  {
    "revision": "6205482edc6bc399c31c8698c2742fdc",
    "url": "/stockmoney/json/basic_info.json"
  },
  {
    "revision": "13e705f89a2b21a1bed5151ba2614a3a",
    "url": "/stockmoney/json/basic_info_cols.json"
  },
  {
    "revision": "dc09b1754a80455f95148f742c9fe654",
    "url": "/stockmoney/json/basic_net.json"
  },
  {
    "revision": "e800701595827c00d737226c84a4c45b",
    "url": "/stockmoney/json/basic_net_cols.json"
  },
  {
    "revision": "74161ea127d66e48a181b4d9c166927a",
    "url": "/stockmoney/json/basic_noi.json"
  },
  {
    "revision": "42a1dc348732b164011a0f2a32967499",
    "url": "/stockmoney/json/basic_noi_cols.json"
  },
  {
    "revision": "fb8394d52ab89e54f2ddad904db957c3",
    "url": "/stockmoney/json/basic_opm.json"
  },
  {
    "revision": "7691b6e4cac72dab3ad428e282b02730",
    "url": "/stockmoney/json/basic_opm_cols.json"
  },
  {
    "revision": "e983c4fbf91d045e4617062cbcedfae6",
    "url": "/stockmoney/json/basic_opp.json"
  },
  {
    "revision": "b8df4c4107e98a0aed2b5968a3e9230e",
    "url": "/stockmoney/json/basic_opp_cols.json"
  },
  {
    "revision": "0119c5a83db31d7997edeac7bac26a03",
    "url": "/stockmoney/json/basic_roe.json"
  },
  {
    "revision": "5eb9427d2ec18d4083eee1ee3a4a0b36",
    "url": "/stockmoney/json/basic_roe_cols.json"
  },
  {
    "revision": "45aea8a1ef485255ce847ea9523d8b61",
    "url": "/stockmoney/json/basic_rvn.json"
  },
  {
    "revision": "bca272032c95aaeca5e2932ef5177de1",
    "url": "/stockmoney/json/basic_rvn_cols.json"
  },
  {
    "revision": "262f2ed4739795e462275fdce3f56033",
    "url": "/stockmoney/json/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json/basic_yearw_cols.json"
  },
  {
    "revision": "2aad56e88a9b96ed9762faa092b6c234",
    "url": "/stockmoney/json/chip_borrow.json"
  },
  {
    "revision": "b9d898714914df8c330d1f25fd728bd4",
    "url": "/stockmoney/json/chip_borrow_cols.json"
  },
  {
    "revision": "a790ea960287d723f3cd13c04c7de98b",
    "url": "/stockmoney/json/chip_director.json"
  },
  {
    "revision": "84a8f93611b9b72bc6a94e8714ea4e5a",
    "url": "/stockmoney/json/chip_director1.json"
  },
  {
    "revision": "9245b933efe32254018a0a6e9a6c8613",
    "url": "/stockmoney/json/chip_director1_cols.json"
  },
  {
    "revision": "0b4523a763178fa10ea2a438c8e93c3e",
    "url": "/stockmoney/json/chip_director3.json"
  },
  {
    "revision": "b856d752ee7572bba69b5bfefbe9e41b",
    "url": "/stockmoney/json/chip_director3_cols.json"
  },
  {
    "revision": "63295f00242f09488a57890cf05dc6c7",
    "url": "/stockmoney/json/chip_director5.json"
  },
  {
    "revision": "825ba91683006403a96e4ead7ebc2e2c",
    "url": "/stockmoney/json/chip_director5_cols.json"
  },
  {
    "revision": "9bbbf6600d4c03482470ae7a8ed48118",
    "url": "/stockmoney/json/chip_director_cols.json"
  },
  {
    "revision": "271fa787acd2f2424013589cab2e5350",
    "url": "/stockmoney/json/chip_foreign.json"
  },
  {
    "revision": "1f66416e66912403af00c4d2366c2741",
    "url": "/stockmoney/json/chip_foreign_cols.json"
  },
  {
    "revision": "a1555ab5a2013108738b5f37c4d6f68a",
    "url": "/stockmoney/json/chip_holder.json"
  },
  {
    "revision": "2cb7e035f77671b5563db45f5a496269",
    "url": "/stockmoney/json/chip_holder_cols.json"
  },
  {
    "revision": "cf931930ff9b834097fd6d743d44b7fe",
    "url": "/stockmoney/json/chip_legal.json"
  },
  {
    "revision": "60a82514c04d8b46e234b6c3b7db8a4c",
    "url": "/stockmoney/json/chip_legal_cols.json"
  },
  {
    "revision": "03652b2fca06dda325e1aad477ad9f93",
    "url": "/stockmoney/json/chip_loan.json"
  },
  {
    "revision": "f9dc3e02b8b829e17677de08ed985401",
    "url": "/stockmoney/json/chip_loan_cols.json"
  },
  {
    "revision": "c4364b23c7fd63bec615fd18c77a8b43",
    "url": "/stockmoney/json/chip_trust.json"
  },
  {
    "revision": "0453c094ec1578d8b609550d9e477938",
    "url": "/stockmoney/json/chip_trust_cols.json"
  },
  {
    "revision": "97c77efc31277350a1d93db839f08303",
    "url": "/stockmoney/json/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json/deal_pct_cols.json"
  },
  {
    "revision": "b5d0c28d99cc9c5fb41ef7cd8830f234",
    "url": "/stockmoney/json/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json/deal_vol_cols.json"
  },
  {
    "revision": "d021fcef32baa19fca3ab08392344d25",
    "url": "/stockmoney/json/dividend_cont.json"
  },
  {
    "revision": "e98f37eaa810fd912b66473ef4aec297",
    "url": "/stockmoney/json/dividend_cont_cols.json"
  },
  {
    "revision": "81b4d025bdc5b4d825dc87f4d371b34b",
    "url": "/stockmoney/json/dividend_stat.json"
  },
  {
    "revision": "7a0acb8648054955af747330298a8ede",
    "url": "/stockmoney/json/dividend_stat_2015.json"
  },
  {
    "revision": "008c79d526737b517a9a742b04502b20",
    "url": "/stockmoney/json/dividend_stat_2015_cols.json"
  },
  {
    "revision": "5307b1027bffd12f00d2af2b25bdec2d",
    "url": "/stockmoney/json/dividend_stat_2016.json"
  },
  {
    "revision": "ec5a0a94673998b0bb4a63db93d08f4a",
    "url": "/stockmoney/json/dividend_stat_2016_cols.json"
  },
  {
    "revision": "fd8bd691bca7e0b2689bf4d0fb3ad0d2",
    "url": "/stockmoney/json/dividend_stat_2017.json"
  },
  {
    "revision": "e37fc91cd72912b24657ed675d9f1c8b",
    "url": "/stockmoney/json/dividend_stat_2017_cols.json"
  },
  {
    "revision": "d000cb27d1c464cc7212d7176b7da7b0",
    "url": "/stockmoney/json/dividend_stat_2018.json"
  },
  {
    "revision": "38050d84b8d337ce366fb397e8e206f7",
    "url": "/stockmoney/json/dividend_stat_2018_cols.json"
  },
  {
    "revision": "26e2bc9e5e23165719e56c58a095effb",
    "url": "/stockmoney/json/dividend_stat_2019.json"
  },
  {
    "revision": "7ec66cdc30aa0d150bc4f797bdc131c4",
    "url": "/stockmoney/json/dividend_stat_2019_cols.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json/dividend_stat_cols.json"
  },
  {
    "revision": "e9ddb09e0f6a6c8fe7837c544da8cb6c",
    "url": "/stockmoney/json/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json/dividend_yield_cols.json"
  },
  {
    "revision": "717aded11d9f90d03ebd21532e8771b5",
    "url": "/stockmoney/json/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json/export_director_cols.json"
  },
  {
    "revision": "94528718854ef1b2e8cc71cd2e4531ab",
    "url": "/stockmoney/json/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json/export_incomerate_cols.json"
  },
  {
    "revision": "88617b53dafeea141b721c879bf83bd0",
    "url": "/stockmoney/json/export_stockfish.json"
  },
  {
    "revision": "a93f6c61875881463916d17972fd941f",
    "url": "/stockmoney/json/export_stockfish_cols.json"
  },
  {
    "revision": "a80bfcd3a5ef180aa259b4018aec8a2f",
    "url": "/stockmoney/json/export_triplerate.json"
  },
  {
    "revision": "2f91c73c151fa60608962f562b8d2bc9",
    "url": "/stockmoney/json/export_triplerate_cols.json"
  },
  {
    "revision": "29f666462b40319c7e1650a4831d6bfc",
    "url": "/stockmoney/json/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json/export_water_cols.json"
  },
  {
    "revision": "0e4c4a30c743cd3ad34c1473ace7463a",
    "url": "/stockmoney/json/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json/export_yield_cols.json"
  },
  {
    "revision": "d400e491cd105295598559be1a2ecb42",
    "url": "/stockmoney/json/my_chip.json"
  },
  {
    "revision": "05157cfc57dc847f4c0ec794c0a2fc08",
    "url": "/stockmoney/json/my_chip_cols.json"
  },
  {
    "revision": "d19b7c5ff149c66f3307347849d882cd",
    "url": "/stockmoney/json/my_eps.json"
  },
  {
    "revision": "87b98bb7ccff2628d43fe83db7362e93",
    "url": "/stockmoney/json/my_eps_cols.json"
  },
  {
    "revision": "4d5c05513b2fb191d3c434173f3017a6",
    "url": "/stockmoney/json/price_high.json"
  },
  {
    "revision": "8f986523f915cd6a9dae0cd5f54f5d7f",
    "url": "/stockmoney/json/price_high_cols.json"
  },
  {
    "revision": "8cf5c54faff19b2a7c508586a86fa7de",
    "url": "/stockmoney/json/tech_bch.json"
  },
  {
    "revision": "4ceab57a8c9a6cd7e19f2b097e934cc2",
    "url": "/stockmoney/json/tech_bch_cols.json"
  },
  {
    "revision": "39aa81650c6d6ecb393b5a58b42b77c8",
    "url": "/stockmoney/json/tech_beta.json"
  },
  {
    "revision": "8f09f6a30643cd54d5275425bea06c52",
    "url": "/stockmoney/json/tech_beta_cols.json"
  },
  {
    "revision": "095697a024684e0b8f8d9ae92e02df1f",
    "url": "/stockmoney/json/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json/tech_kd_cols.json"
  },
  {
    "revision": "0f71c4ba25b04ab0bd69a3bfcb74cbb9",
    "url": "/stockmoney/json/tech_ma.json"
  },
  {
    "revision": "0312283011ee3335e1c1333e9725ace1",
    "url": "/stockmoney/json/tech_ma_cols.json"
  },
  {
    "revision": "bb180111a670b8ec3ebdd48bef9c92b1",
    "url": "/stockmoney/json/triplerate_gross.json"
  },
  {
    "revision": "a13db154431d48a1400e5f61c7addd0a",
    "url": "/stockmoney/json/triplerate_gross_cols.json"
  },
  {
    "revision": "53d952974af97350fd30c9bb89629301",
    "url": "/stockmoney/json/triplerate_net.json"
  },
  {
    "revision": "f8d7efb91393b25f2379a683232faccc",
    "url": "/stockmoney/json/triplerate_net_cols.json"
  },
  {
    "revision": "6f6ec4990de27f3492592c4b2454dae7",
    "url": "/stockmoney/json/triplerate_opp.json"
  },
  {
    "revision": "0f74be20460ac5da9f37d6c74ad5897b",
    "url": "/stockmoney/json/triplerate_opp_cols.json"
  },
  {
    "revision": "223d40b410fb5ae8ec340254ceb1c429",
    "url": "/stockmoney/json/year_eps.json"
  },
  {
    "revision": "fb8630f31196b33b3b05790d64e8ae62",
    "url": "/stockmoney/json/year_eps_cols.json"
  },
  {
    "revision": "982915c4f707aa542849d89c68f876dd",
    "url": "/stockmoney/json/year_roe.json"
  },
  {
    "revision": "19bba5bc978ad9d84bf505e65f95273d",
    "url": "/stockmoney/json/year_roe_cols.json"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json_otc/.dummy"
  },
  {
    "revision": "c47b90554c39ee2d3d4d3a251d0889bd",
    "url": "/stockmoney/json_otc/basic_4season.json"
  },
  {
    "revision": "5af8e03d5ac2fd4ca03652dd2b98f6f0",
    "url": "/stockmoney/json_otc/basic_4season_cols.json"
  },
  {
    "revision": "0d82b95fa53d8fc985c165a7d21c2f2d",
    "url": "/stockmoney/json_otc/basic_asset.json"
  },
  {
    "revision": "b38212d12f678a74ad6a6565339df931",
    "url": "/stockmoney/json_otc/basic_asset_cols.json"
  },
  {
    "revision": "ac628c5e2fa4d20ee97272202df7d3bf",
    "url": "/stockmoney/json_otc/basic_cash.json"
  },
  {
    "revision": "fb11e7b6d046f6171abb53ae187c5db2",
    "url": "/stockmoney/json_otc/basic_cash_cols.json"
  },
  {
    "revision": "dbaafeb6149518bb094c8b7661f0ee0a",
    "url": "/stockmoney/json_otc/basic_debt.json"
  },
  {
    "revision": "a757ec4d577d26f0d2d31c1142265b88",
    "url": "/stockmoney/json_otc/basic_debt_cols.json"
  },
  {
    "revision": "20fad80804e9cc37cda5310cc74f8ca2",
    "url": "/stockmoney/json_otc/basic_eps.json"
  },
  {
    "revision": "6236e8496991094a506429ee88076925",
    "url": "/stockmoney/json_otc/basic_eps_cols.json"
  },
  {
    "revision": "4c8b8d2b48ddcbd675354629b3fc1fba",
    "url": "/stockmoney/json_otc/basic_gross.json"
  },
  {
    "revision": "c6aa8c617ea5d66a3f74b5bbe0ffb334",
    "url": "/stockmoney/json_otc/basic_gross_cols.json"
  },
  {
    "revision": "f9ed770670c201a75a156894b4c566fe",
    "url": "/stockmoney/json_otc/basic_info.json"
  },
  {
    "revision": "6f99a8a60e35b64e93e4e87ccbc4e5dd",
    "url": "/stockmoney/json_otc/basic_info_cols.json"
  },
  {
    "revision": "867ca9fec9686a4ac683b47b91650c85",
    "url": "/stockmoney/json_otc/basic_net.json"
  },
  {
    "revision": "812a2467032d7ff37817f0c72863b73b",
    "url": "/stockmoney/json_otc/basic_net_cols.json"
  },
  {
    "revision": "74c6cea82178081792835283344e3974",
    "url": "/stockmoney/json_otc/basic_noi.json"
  },
  {
    "revision": "c4389154a0c4849f1a7a081adbe943eb",
    "url": "/stockmoney/json_otc/basic_noi_cols.json"
  },
  {
    "revision": "2296b0d43b2827adf5829c2d830530f6",
    "url": "/stockmoney/json_otc/basic_opm.json"
  },
  {
    "revision": "8da4b2a22df8c587fe27eb6563e93398",
    "url": "/stockmoney/json_otc/basic_opm_cols.json"
  },
  {
    "revision": "3d5fd2cb20a77090303c6568c65746e1",
    "url": "/stockmoney/json_otc/basic_opp.json"
  },
  {
    "revision": "faaa15a86f02d58b3cda3428933bbb99",
    "url": "/stockmoney/json_otc/basic_opp_cols.json"
  },
  {
    "revision": "a218a8f1ee41f861ea8974e8dc4a9d00",
    "url": "/stockmoney/json_otc/basic_roe.json"
  },
  {
    "revision": "3cd3a076d0a3612aea4e282a6a648e0f",
    "url": "/stockmoney/json_otc/basic_roe_cols.json"
  },
  {
    "revision": "6154ff524fa3fca33d15671c0c8e0ef9",
    "url": "/stockmoney/json_otc/basic_rvn.json"
  },
  {
    "revision": "d25a5eb5d87cabec78085efa60644bcb",
    "url": "/stockmoney/json_otc/basic_rvn_cols.json"
  },
  {
    "revision": "f1524a67e0335f38bd117f5bfd797a28",
    "url": "/stockmoney/json_otc/basic_yearw.json"
  },
  {
    "revision": "37afed6bf332938bf457759590f15e20",
    "url": "/stockmoney/json_otc/basic_yearw_cols.json"
  },
  {
    "revision": "e3c0a981b4014d92338bd4b2787e6bc9",
    "url": "/stockmoney/json_otc/chip_borrow.json"
  },
  {
    "revision": "5a8bd57521f8a67e6f158eda3faacf21",
    "url": "/stockmoney/json_otc/chip_borrow_cols.json"
  },
  {
    "revision": "63962fe09ac887b6f3c72b421b556f4f",
    "url": "/stockmoney/json_otc/chip_director.json"
  },
  {
    "revision": "2e7342b824648247d4ac40865106370e",
    "url": "/stockmoney/json_otc/chip_director1.json"
  },
  {
    "revision": "8e7a0bacff28aa1cf9f5825c7712c937",
    "url": "/stockmoney/json_otc/chip_director1_cols.json"
  },
  {
    "revision": "ec7c68dca443d625c027da8c2559f073",
    "url": "/stockmoney/json_otc/chip_director3.json"
  },
  {
    "revision": "cb725822bf310830ac86771e76bbf7e5",
    "url": "/stockmoney/json_otc/chip_director3_cols.json"
  },
  {
    "revision": "4e5414f93d9bc4ee641b8519ce42b145",
    "url": "/stockmoney/json_otc/chip_director5.json"
  },
  {
    "revision": "9e1f67c918b55fd9c2153dc91b5ea992",
    "url": "/stockmoney/json_otc/chip_director5_cols.json"
  },
  {
    "revision": "79dce6a98cc61675f28207bb8ee66d68",
    "url": "/stockmoney/json_otc/chip_director_cols.json"
  },
  {
    "revision": "f2f8a90bc37e744647718c32a36c0165",
    "url": "/stockmoney/json_otc/chip_foreign.json"
  },
  {
    "revision": "e59f62dd4b9a788009bac352d7e91c12",
    "url": "/stockmoney/json_otc/chip_foreign_cols.json"
  },
  {
    "revision": "b70ae59181e28cc89a7f31bcdf6386c8",
    "url": "/stockmoney/json_otc/chip_holder.json"
  },
  {
    "revision": "2cb7e035f77671b5563db45f5a496269",
    "url": "/stockmoney/json_otc/chip_holder_cols.json"
  },
  {
    "revision": "51645f21608b4d08b0dcde824cb132fb",
    "url": "/stockmoney/json_otc/chip_legal.json"
  },
  {
    "revision": "56a5a51151871b1624874a4fe5a82f83",
    "url": "/stockmoney/json_otc/chip_legal_cols.json"
  },
  {
    "revision": "bb9a9d79c678dfc4299306c2c2e0b4d0",
    "url": "/stockmoney/json_otc/chip_loan.json"
  },
  {
    "revision": "ee402593614d4650e99e562d17e63538",
    "url": "/stockmoney/json_otc/chip_loan_cols.json"
  },
  {
    "revision": "131dac6ae4e802749eed6fefd8918b7e",
    "url": "/stockmoney/json_otc/chip_trust.json"
  },
  {
    "revision": "4466ee075166bd957824b4a6d6c6ddbe",
    "url": "/stockmoney/json_otc/chip_trust_cols.json"
  },
  {
    "revision": "9c3f1ce4960af1a0ed23a47d93d73a23",
    "url": "/stockmoney/json_otc/deal_pct.json"
  },
  {
    "revision": "6aa4eed51cba9dc1dc746762256d9659",
    "url": "/stockmoney/json_otc/deal_pct_cols.json"
  },
  {
    "revision": "f2f3a5e50b11d26dfd4b52c712d84a4c",
    "url": "/stockmoney/json_otc/deal_vol.json"
  },
  {
    "revision": "b27cd4bd88359e51326cd3dab8215f69",
    "url": "/stockmoney/json_otc/deal_vol_cols.json"
  },
  {
    "revision": "dc567a5fd4e2db1a242213a4f575e1f7",
    "url": "/stockmoney/json_otc/dividend_cont.json"
  },
  {
    "revision": "d770b65af07d9d64a25e81b34c57086f",
    "url": "/stockmoney/json_otc/dividend_cont_cols.json"
  },
  {
    "revision": "679dcee505f21b8e167c90fe2561db19",
    "url": "/stockmoney/json_otc/dividend_stat.json"
  },
  {
    "revision": "0812b45d7d98fd5db55460a5ccfdac01",
    "url": "/stockmoney/json_otc/dividend_stat_2015.json"
  },
  {
    "revision": "cbec2feb676f6a6aa3b239e88e6d6a2c",
    "url": "/stockmoney/json_otc/dividend_stat_2015_cols.json"
  },
  {
    "revision": "3fbf91b38dcf8c082e0868e4c638014d",
    "url": "/stockmoney/json_otc/dividend_stat_2016.json"
  },
  {
    "revision": "6e18d58a36f9fc2a33f01cedfe00600b",
    "url": "/stockmoney/json_otc/dividend_stat_2016_cols.json"
  },
  {
    "revision": "ebc30c4cfe69180fab42979adda2a02c",
    "url": "/stockmoney/json_otc/dividend_stat_2017.json"
  },
  {
    "revision": "297d5aebd0f10fcde9bb1a0e4ac5182e",
    "url": "/stockmoney/json_otc/dividend_stat_2017_cols.json"
  },
  {
    "revision": "aeb6d6d7217083acde2e428edf887728",
    "url": "/stockmoney/json_otc/dividend_stat_2018.json"
  },
  {
    "revision": "260b5376813e3734a06dab71d8b9bd8a",
    "url": "/stockmoney/json_otc/dividend_stat_2018_cols.json"
  },
  {
    "revision": "52780a5aa803dea856400ea7b1389419",
    "url": "/stockmoney/json_otc/dividend_stat_2019.json"
  },
  {
    "revision": "6050c49dcd02fe1bf54be9c00f3014eb",
    "url": "/stockmoney/json_otc/dividend_stat_2019_cols.json"
  },
  {
    "revision": "9b4c4be9545c11e770cbe8be386f94cb",
    "url": "/stockmoney/json_otc/dividend_stat_cols.json"
  },
  {
    "revision": "175c1b07b3a83cf6122cfb1304a77c9c",
    "url": "/stockmoney/json_otc/dividend_yield.json"
  },
  {
    "revision": "ecb2998fde71d849b8992a7b6c4e2e3d",
    "url": "/stockmoney/json_otc/dividend_yield_cols.json"
  },
  {
    "revision": "e803023ef7559d2f9fa023d050b4c35d",
    "url": "/stockmoney/json_otc/export_director.json"
  },
  {
    "revision": "ddda31a1413ac0cdd7368db2feee5496",
    "url": "/stockmoney/json_otc/export_incomerate.json"
  },
  {
    "revision": "d5a053805daeb895ff18f05f48b59df6",
    "url": "/stockmoney/json_otc/export_stockfish.json"
  },
  {
    "revision": "be19c8ac6ad984c81ec3f53a10b67a0c",
    "url": "/stockmoney/json_otc/export_triplerate.json"
  },
  {
    "revision": "9fbe4a8ee77c8adff493bd29774f2be4",
    "url": "/stockmoney/json_otc/export_water.json"
  },
  {
    "revision": "e4d19ef621373535f3e85d7dfc1e6a0f",
    "url": "/stockmoney/json_otc/export_yield.json"
  },
  {
    "revision": "5bd5ebab636a2d7b35ee12f93df04467",
    "url": "/stockmoney/json_otc/my_eps.json"
  },
  {
    "revision": "8b62b388fa61cbd9eeac19a71332310e",
    "url": "/stockmoney/json_otc/tech_bch.json"
  },
  {
    "revision": "1f3501a7241684346326f6b20fef29ab",
    "url": "/stockmoney/json_otc/tech_bch_cols.json"
  },
  {
    "revision": "e2c795115a75e6e946d55b5ffa04c8ee",
    "url": "/stockmoney/json_otc/tech_beta.json"
  },
  {
    "revision": "1d1993c61608814513697231793da5ff",
    "url": "/stockmoney/json_otc/tech_beta_cols.json"
  },
  {
    "revision": "39ef9fbb8661566df400fbac0208e4f4",
    "url": "/stockmoney/json_otc/tech_kd.json"
  },
  {
    "revision": "4f5d6ca8656dd449a555f2892c29746e",
    "url": "/stockmoney/json_otc/tech_kd_cols.json"
  },
  {
    "revision": "65f85b9cea1e4e6b027f201505a46ae1",
    "url": "/stockmoney/json_otc/tech_ma.json"
  },
  {
    "revision": "d6c2c2c917b71f3b85765373cb229222",
    "url": "/stockmoney/json_otc/tech_ma_cols.json"
  },
  {
    "revision": "8ec4dc111a3868bfe2556b4f9f3db6a7",
    "url": "/stockmoney/json_otc/triplerate_gross.json"
  },
  {
    "revision": "a878d9930cb6084be8efc2b221299517",
    "url": "/stockmoney/json_otc/triplerate_gross_cols.json"
  },
  {
    "revision": "1f0b72b8f70781c9587f6e8d30f5d8e6",
    "url": "/stockmoney/json_otc/triplerate_net.json"
  },
  {
    "revision": "ca4a9510066b0a1cfd44ba2d93d54d3e",
    "url": "/stockmoney/json_otc/triplerate_net_cols.json"
  },
  {
    "revision": "dcf7a80fdc79622c6caf64496e677730",
    "url": "/stockmoney/json_otc/triplerate_opp.json"
  },
  {
    "revision": "7d5474632c1cb890471701cfc8df4201",
    "url": "/stockmoney/json_otc/triplerate_opp_cols.json"
  },
  {
    "revision": "9a4fa9104c0183124b827bff92a97f24",
    "url": "/stockmoney/json_otc/year_eps.json"
  },
  {
    "revision": "b756bfd59f2bde408c4bda6aa436abc9",
    "url": "/stockmoney/json_otc/year_eps_cols.json"
  },
  {
    "revision": "e6f8be123b2c7d4f8cc9cb1948a6eb08",
    "url": "/stockmoney/json_otc/year_roe.json"
  },
  {
    "revision": "b2864c9916e85f4cd6e50e5f745ea397",
    "url": "/stockmoney/json_otc/year_roe_cols.json"
  },
  {
    "revision": "b96e0d5a5df171b63ae60164bac0e3af",
    "url": "/stockmoney/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/stockmoney/robots.txt"
  },
  {
    "revision": "44752836d2f0393858cd",
    "url": "/stockmoney/static/css/app.20385547.css"
  },
  {
    "revision": "0b67f49ecef966899a76",
    "url": "/stockmoney/static/css/chunk-vendors.eae4093c.css"
  },
  {
    "revision": "ecb3bfc03db10b6f9d6e23e710d5c953",
    "url": "/stockmoney/static/img/logo.ecb3bfc0.png"
  },
  {
    "revision": "658800e4ddcdedaaa231",
    "url": "/stockmoney/static/js/about.6cc0e21f.js"
  },
  {
    "revision": "44752836d2f0393858cd",
    "url": "/stockmoney/static/js/app.7d95b303.js"
  },
  {
    "revision": "0b67f49ecef966899a76",
    "url": "/stockmoney/static/js/chunk-vendors.e64b16c7.js"
  }
]);