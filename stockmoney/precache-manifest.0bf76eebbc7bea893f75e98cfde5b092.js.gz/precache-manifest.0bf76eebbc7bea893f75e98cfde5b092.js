self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6d026b5d85a4f5ddfeb9676b0dac249a",
    "url": "/stockmoney/index.html"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json/.dummy"
  },
  {
    "revision": "55daa64ae78341db8aa6cb340c57e526",
    "url": "/stockmoney/json/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json/basic_4season_cols.json"
  },
  {
    "revision": "54ac230bdb89bee148ec2710da002cc9",
    "url": "/stockmoney/json/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json/basic_asset_cols.json"
  },
  {
    "revision": "5a19d0f21e92b47d9f8d4aa2c1959e80",
    "url": "/stockmoney/json/basic_cash.json"
  },
  {
    "revision": "5349424348aa80afa6ae8346580a712f",
    "url": "/stockmoney/json/basic_cash_cols.json"
  },
  {
    "revision": "c256cbf6423187b40d0e1cdb25d7ee0c",
    "url": "/stockmoney/json/basic_debt.json"
  },
  {
    "revision": "149c233a96836df1a575318ec2a1509d",
    "url": "/stockmoney/json/basic_debt_cols.json"
  },
  {
    "revision": "4aa81859fdd683a4ca4b68ee206a1e63",
    "url": "/stockmoney/json/basic_eps.json"
  },
  {
    "revision": "b90192ca9115275349bfea323a394569",
    "url": "/stockmoney/json/basic_eps_cols.json"
  },
  {
    "revision": "e3419a74d55b7ff58f9a848d682f87ff",
    "url": "/stockmoney/json/basic_gross.json"
  },
  {
    "revision": "9c4dcfc402f48cb75982fe1d0615a7cb",
    "url": "/stockmoney/json/basic_gross_cols.json"
  },
  {
    "revision": "9ae35aa0147892aae899540194cd30bb",
    "url": "/stockmoney/json/basic_info.json"
  },
  {
    "revision": "4a01d4330b10e31c6048acfe2d9dde98",
    "url": "/stockmoney/json/basic_info_cols.json"
  },
  {
    "revision": "15831f1702b20e7d4de6095062211b72",
    "url": "/stockmoney/json/basic_net.json"
  },
  {
    "revision": "2ba3ac8050a3d880496ca58318dcb7dc",
    "url": "/stockmoney/json/basic_net_cols.json"
  },
  {
    "revision": "8da30071e159eb73d2e64e790d1d4501",
    "url": "/stockmoney/json/basic_noi.json"
  },
  {
    "revision": "682d8a925174920c27df43d992708acb",
    "url": "/stockmoney/json/basic_noi_cols.json"
  },
  {
    "revision": "558b2ad83da9275df1c4ac00c519e13a",
    "url": "/stockmoney/json/basic_opm.json"
  },
  {
    "revision": "d25fc77588c0fdc65b8f3e3d57c163e8",
    "url": "/stockmoney/json/basic_opm_cols.json"
  },
  {
    "revision": "31b77c77d7612c1ed2e708e0f0afd9e9",
    "url": "/stockmoney/json/basic_opp.json"
  },
  {
    "revision": "cd5e1981364e5ab21acb32ee82608e2d",
    "url": "/stockmoney/json/basic_opp_cols.json"
  },
  {
    "revision": "987c84a1842af160803d9697cb7a17de",
    "url": "/stockmoney/json/basic_roe.json"
  },
  {
    "revision": "36692d25edb0355ea92b9c37564e0684",
    "url": "/stockmoney/json/basic_roe_cols.json"
  },
  {
    "revision": "414438b5fbddb7eeb72c25ba6ef3faf9",
    "url": "/stockmoney/json/basic_rvn.json"
  },
  {
    "revision": "726df860aa07852a20559f1f368dd854",
    "url": "/stockmoney/json/basic_rvn_cols.json"
  },
  {
    "revision": "7f55a81ae89ae327068a851418208858",
    "url": "/stockmoney/json/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json/basic_yearw_cols.json"
  },
  {
    "revision": "1e15faa1984fb2e278174e38a3e2db1e",
    "url": "/stockmoney/json/chip_borrow.json"
  },
  {
    "revision": "b9d898714914df8c330d1f25fd728bd4",
    "url": "/stockmoney/json/chip_borrow_cols.json"
  },
  {
    "revision": "cf2fa607a4bf1db9ac29a6f9b9d51fce",
    "url": "/stockmoney/json/chip_broker.json"
  },
  {
    "revision": "b89c8934953e4c846feaa5bf0ed58a84",
    "url": "/stockmoney/json/chip_director.json"
  },
  {
    "revision": "da5548192c8ebe7bfd70f682508fc1e1",
    "url": "/stockmoney/json/chip_director1.json"
  },
  {
    "revision": "9245b933efe32254018a0a6e9a6c8613",
    "url": "/stockmoney/json/chip_director1_cols.json"
  },
  {
    "revision": "f09f8bdb102d03ef35056c3f8c53d1ae",
    "url": "/stockmoney/json/chip_director3.json"
  },
  {
    "revision": "b856d752ee7572bba69b5bfefbe9e41b",
    "url": "/stockmoney/json/chip_director3_cols.json"
  },
  {
    "revision": "345eb94f7d9e4df346896ca5e4852f31",
    "url": "/stockmoney/json/chip_director5.json"
  },
  {
    "revision": "825ba91683006403a96e4ead7ebc2e2c",
    "url": "/stockmoney/json/chip_director5_cols.json"
  },
  {
    "revision": "9bbbf6600d4c03482470ae7a8ed48118",
    "url": "/stockmoney/json/chip_director_cols.json"
  },
  {
    "revision": "2c8467ed674a829ccb1f0e227f6134ad",
    "url": "/stockmoney/json/chip_foreign.json"
  },
  {
    "revision": "1f66416e66912403af00c4d2366c2741",
    "url": "/stockmoney/json/chip_foreign_cols.json"
  },
  {
    "revision": "f0295e13c774c6627bc9a9cabfe6421f",
    "url": "/stockmoney/json/chip_holder.json"
  },
  {
    "revision": "672717b58db691e5c491065fd3720da4",
    "url": "/stockmoney/json/chip_holder_cols.json"
  },
  {
    "revision": "7a860fd10496fca0b77ab68234e1f8da",
    "url": "/stockmoney/json/chip_legal.json"
  },
  {
    "revision": "60a82514c04d8b46e234b6c3b7db8a4c",
    "url": "/stockmoney/json/chip_legal_cols.json"
  },
  {
    "revision": "93f7609a9311003c8bac65cd9865d162",
    "url": "/stockmoney/json/chip_loan.json"
  },
  {
    "revision": "f9dc3e02b8b829e17677de08ed985401",
    "url": "/stockmoney/json/chip_loan_cols.json"
  },
  {
    "revision": "e679d0e21bb2a2dabaa3d621c9de9d76",
    "url": "/stockmoney/json/chip_trust.json"
  },
  {
    "revision": "0453c094ec1578d8b609550d9e477938",
    "url": "/stockmoney/json/chip_trust_cols.json"
  },
  {
    "revision": "94a0013a0a8d7e5d115eaa402e88de43",
    "url": "/stockmoney/json/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json/deal_pct_cols.json"
  },
  {
    "revision": "7c0fdc45f20edc9062d4ddb72ffa4f65",
    "url": "/stockmoney/json/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json/deal_vol_cols.json"
  },
  {
    "revision": "44523ef86d76d12e46abaf7a10d71d3f",
    "url": "/stockmoney/json/dividend_cont.json"
  },
  {
    "revision": "3e8dc99836816cdedc952a126db1fa79",
    "url": "/stockmoney/json/dividend_cont_cols.json"
  },
  {
    "revision": "6e050f7c6fe6aa2bc90718e892e43322",
    "url": "/stockmoney/json/dividend_stat.json"
  },
  {
    "revision": "690d1e2aaaf13a4abf8c869f9466873b",
    "url": "/stockmoney/json/dividend_stat_2015.json"
  },
  {
    "revision": "008c79d526737b517a9a742b04502b20",
    "url": "/stockmoney/json/dividend_stat_2015_cols.json"
  },
  {
    "revision": "90f6b72c01ae2964cacfc7c888dd7b16",
    "url": "/stockmoney/json/dividend_stat_2016.json"
  },
  {
    "revision": "ec5a0a94673998b0bb4a63db93d08f4a",
    "url": "/stockmoney/json/dividend_stat_2016_cols.json"
  },
  {
    "revision": "48d94b131f336e67826b549fb1e0b789",
    "url": "/stockmoney/json/dividend_stat_2017.json"
  },
  {
    "revision": "e37fc91cd72912b24657ed675d9f1c8b",
    "url": "/stockmoney/json/dividend_stat_2017_cols.json"
  },
  {
    "revision": "50ae67bf59e8677cb94cbe8faa90cbdd",
    "url": "/stockmoney/json/dividend_stat_2018.json"
  },
  {
    "revision": "38050d84b8d337ce366fb397e8e206f7",
    "url": "/stockmoney/json/dividend_stat_2018_cols.json"
  },
  {
    "revision": "1bd38ab8caaff9d4dd1f4cbbe8fe46ec",
    "url": "/stockmoney/json/dividend_stat_2019.json"
  },
  {
    "revision": "7ec66cdc30aa0d150bc4f797bdc131c4",
    "url": "/stockmoney/json/dividend_stat_2019_cols.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json/dividend_stat_cols.json"
  },
  {
    "revision": "bc9a265aea6f4dcdf5bd576e1e43dc54",
    "url": "/stockmoney/json/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json/dividend_yield_cols.json"
  },
  {
    "revision": "3a2ec855f199b99400f3ea4ed9053beb",
    "url": "/stockmoney/json/dk_dies.json"
  },
  {
    "revision": "0842de8223abec6d0d02135b89168710",
    "url": "/stockmoney/json/dk_dies_cols.json"
  },
  {
    "revision": "eb5d97abb2f6cf304a82523cb7803c05",
    "url": "/stockmoney/json/export_director.json"
  },
  {
    "revision": "89100efeca7bfb4d95efdab07df62a48",
    "url": "/stockmoney/json/export_director_cols.json"
  },
  {
    "revision": "ba7b40bb3c841e4115520c8232247077",
    "url": "/stockmoney/json/export_incomerate.json"
  },
  {
    "revision": "8a782513b99c4e31cf07aca4745c38e4",
    "url": "/stockmoney/json/export_incomerate_cols.json"
  },
  {
    "revision": "23f8ea28b4207f056c31093449a6ad91",
    "url": "/stockmoney/json/export_stockfish.json"
  },
  {
    "revision": "24c365c317bd950273a6bbe79b14d791",
    "url": "/stockmoney/json/export_stockfish_cols.json"
  },
  {
    "revision": "212efc825bd0c31ed23c6e02b87a835a",
    "url": "/stockmoney/json/export_triplerate.json"
  },
  {
    "revision": "29e0c2731cf0823c503af4580b581346",
    "url": "/stockmoney/json/export_triplerate_cols.json"
  },
  {
    "revision": "0cacafa20dc21d9d515b8f95670cd627",
    "url": "/stockmoney/json/export_water.json"
  },
  {
    "revision": "1743dc326779ed0d0955118930c2fdc1",
    "url": "/stockmoney/json/export_water_cols.json"
  },
  {
    "revision": "28f146959efc4b7859f502d875a51df3",
    "url": "/stockmoney/json/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json/export_yield_cols.json"
  },
  {
    "revision": "f4676c22bf13d074ddaeb0864366940a",
    "url": "/stockmoney/json/my_basic.json"
  },
  {
    "revision": "2f5793f3c37c43bf4332b89384b912a3",
    "url": "/stockmoney/json/my_basic_cols.json"
  },
  {
    "revision": "ad1769ab71467e25cfe058a2c50f30a6",
    "url": "/stockmoney/json/my_chip.json"
  },
  {
    "revision": "4591748299e5053668af84371363907d",
    "url": "/stockmoney/json/my_chip_cols.json"
  },
  {
    "revision": "176bff5e5c5afeb14b2c875e6c07dc63",
    "url": "/stockmoney/json/my_eps.json"
  },
  {
    "revision": "87b98bb7ccff2628d43fe83db7362e93",
    "url": "/stockmoney/json/my_eps_cols.json"
  },
  {
    "revision": "6ee15be80ba053511c1782a4a250f1ec",
    "url": "/stockmoney/json/my_tech.json"
  },
  {
    "revision": "4b39153da2d47c317e3bf1ded1a14cf5",
    "url": "/stockmoney/json/my_tech_cols.json"
  },
  {
    "revision": "b475ea08c9129124df7e26e17a089326",
    "url": "/stockmoney/json/my_topforce.json"
  },
  {
    "revision": "355b4a8e70cde4a12ff1467395dee2d2",
    "url": "/stockmoney/json/my_topforce_cols.json"
  },
  {
    "revision": "b07f95012dcc8bcd39c0fdeb2c8c147b",
    "url": "/stockmoney/json/price_dpct.json"
  },
  {
    "revision": "111c1063358cf2cce62d1c4c3cf2a601",
    "url": "/stockmoney/json/price_dpct_cols.json"
  },
  {
    "revision": "24998fe7c764a7545376f279bf013fd4",
    "url": "/stockmoney/json/price_high.json"
  },
  {
    "revision": "8f986523f915cd6a9dae0cd5f54f5d7f",
    "url": "/stockmoney/json/price_high_cols.json"
  },
  {
    "revision": "f1630db6652eb3eff7569fef2fb891ba",
    "url": "/stockmoney/json/price_mpct.json"
  },
  {
    "revision": "19f8b091eacff631ac486f7a35596c56",
    "url": "/stockmoney/json/price_mpct_cols.json"
  },
  {
    "revision": "b02f7d0ccd0bf67965659cd3d69bcae1",
    "url": "/stockmoney/json/price_wpct.json"
  },
  {
    "revision": "06e2f207dffd568d93360a54eff1629d",
    "url": "/stockmoney/json/price_wpct_cols.json"
  },
  {
    "revision": "7325b5394a219d9f71099d1409430942",
    "url": "/stockmoney/json/tech_bch.json"
  },
  {
    "revision": "56d227c0fc6a9c5a25f2502cc26148ab",
    "url": "/stockmoney/json/tech_bch_cols.json"
  },
  {
    "revision": "44ef84048282fc1ea927cb9b26c0585f",
    "url": "/stockmoney/json/tech_beta.json"
  },
  {
    "revision": "8f09f6a30643cd54d5275425bea06c52",
    "url": "/stockmoney/json/tech_beta_cols.json"
  },
  {
    "revision": "525d2046b83fc3df6dd147cda05caea4",
    "url": "/stockmoney/json/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json/tech_kd_cols.json"
  },
  {
    "revision": "c7b6849be6b4474ef8f3350fc6626caf",
    "url": "/stockmoney/json/tech_ma.json"
  },
  {
    "revision": "5c125157702e4475325fc62420500833",
    "url": "/stockmoney/json/tech_ma_cols.json"
  },
  {
    "revision": "dc610445cd2dbab5fed494511c4e625c",
    "url": "/stockmoney/json/tech_makink.json"
  },
  {
    "revision": "f95de82f9706f0ab7fbcddef3c0742ee",
    "url": "/stockmoney/json/tech_makink_cols.json"
  },
  {
    "revision": "ebf8860419bc4b988c03d9747cb2020b",
    "url": "/stockmoney/json/triplerate_gross.json"
  },
  {
    "revision": "bdea5894fe1ee11fe29b8c1b086f8b14",
    "url": "/stockmoney/json/triplerate_gross_cols.json"
  },
  {
    "revision": "5028c86a8950e13c002cbcf93fa405e5",
    "url": "/stockmoney/json/triplerate_net.json"
  },
  {
    "revision": "131977477f007368864220bd92c5b140",
    "url": "/stockmoney/json/triplerate_net_cols.json"
  },
  {
    "revision": "5bb0711ead6254bf817dba96dba794be",
    "url": "/stockmoney/json/triplerate_opp.json"
  },
  {
    "revision": "101ce9c11dafd51f9b77daa28ec5e106",
    "url": "/stockmoney/json/triplerate_opp_cols.json"
  },
  {
    "revision": "70aaf17f5bf8ae2617766c07b43d344f",
    "url": "/stockmoney/json/year_eps.json"
  },
  {
    "revision": "6d3ef962007b26c6d23c4c5d7a057cc8",
    "url": "/stockmoney/json/year_eps_cols.json"
  },
  {
    "revision": "149239a79970183bac90f9667fddffe4",
    "url": "/stockmoney/json/year_roe.json"
  },
  {
    "revision": "07c767a967283717369ecc8e0f0f7d99",
    "url": "/stockmoney/json/year_roe_cols.json"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json_otc/.dummy"
  },
  {
    "revision": "e4e66691e3de7848ce0428dce0a82ec3",
    "url": "/stockmoney/json_otc/basic_4season.json"
  },
  {
    "revision": "5af8e03d5ac2fd4ca03652dd2b98f6f0",
    "url": "/stockmoney/json_otc/basic_4season_cols.json"
  },
  {
    "revision": "a38ede19bf10159f11a1af60a97d2ce9",
    "url": "/stockmoney/json_otc/basic_asset.json"
  },
  {
    "revision": "b38212d12f678a74ad6a6565339df931",
    "url": "/stockmoney/json_otc/basic_asset_cols.json"
  },
  {
    "revision": "8c3404a4252408568bb945eb24761f95",
    "url": "/stockmoney/json_otc/basic_cash.json"
  },
  {
    "revision": "5349424348aa80afa6ae8346580a712f",
    "url": "/stockmoney/json_otc/basic_cash_cols.json"
  },
  {
    "revision": "a6404f3f97331661aed3dbc7b68705a2",
    "url": "/stockmoney/json_otc/basic_debt.json"
  },
  {
    "revision": "149c233a96836df1a575318ec2a1509d",
    "url": "/stockmoney/json_otc/basic_debt_cols.json"
  },
  {
    "revision": "6471fd1523d54caab4ba23941acf9418",
    "url": "/stockmoney/json_otc/basic_eps.json"
  },
  {
    "revision": "b90192ca9115275349bfea323a394569",
    "url": "/stockmoney/json_otc/basic_eps_cols.json"
  },
  {
    "revision": "6ac43571c76db999a411b4687683cb67",
    "url": "/stockmoney/json_otc/basic_gross.json"
  },
  {
    "revision": "9c4dcfc402f48cb75982fe1d0615a7cb",
    "url": "/stockmoney/json_otc/basic_gross_cols.json"
  },
  {
    "revision": "e41b68395b363223e48204b1f171b04d",
    "url": "/stockmoney/json_otc/basic_info.json"
  },
  {
    "revision": "6f99a8a60e35b64e93e4e87ccbc4e5dd",
    "url": "/stockmoney/json_otc/basic_info_cols.json"
  },
  {
    "revision": "e42fe0aa53c0efd19c79f3528d4db6bb",
    "url": "/stockmoney/json_otc/basic_net.json"
  },
  {
    "revision": "2ba3ac8050a3d880496ca58318dcb7dc",
    "url": "/stockmoney/json_otc/basic_net_cols.json"
  },
  {
    "revision": "c47810fcc17eff3d3713e4e5996dbcd5",
    "url": "/stockmoney/json_otc/basic_noi.json"
  },
  {
    "revision": "682d8a925174920c27df43d992708acb",
    "url": "/stockmoney/json_otc/basic_noi_cols.json"
  },
  {
    "revision": "b4eebfdd15712c8c36ed219fa3086c6a",
    "url": "/stockmoney/json_otc/basic_opm.json"
  },
  {
    "revision": "d25fc77588c0fdc65b8f3e3d57c163e8",
    "url": "/stockmoney/json_otc/basic_opm_cols.json"
  },
  {
    "revision": "4a06979acfa2228000bddadb75515636",
    "url": "/stockmoney/json_otc/basic_opp.json"
  },
  {
    "revision": "cd5e1981364e5ab21acb32ee82608e2d",
    "url": "/stockmoney/json_otc/basic_opp_cols.json"
  },
  {
    "revision": "b7bd5bccae3e07a29e04fd2ea2e47da4",
    "url": "/stockmoney/json_otc/basic_roe.json"
  },
  {
    "revision": "36692d25edb0355ea92b9c37564e0684",
    "url": "/stockmoney/json_otc/basic_roe_cols.json"
  },
  {
    "revision": "4b1be7713d6e731fe416bd5a29e446b2",
    "url": "/stockmoney/json_otc/basic_rvn.json"
  },
  {
    "revision": "726df860aa07852a20559f1f368dd854",
    "url": "/stockmoney/json_otc/basic_rvn_cols.json"
  },
  {
    "revision": "376f2f23260ef29f25568e3fcb0f734e",
    "url": "/stockmoney/json_otc/basic_yearw.json"
  },
  {
    "revision": "37afed6bf332938bf457759590f15e20",
    "url": "/stockmoney/json_otc/basic_yearw_cols.json"
  },
  {
    "revision": "d4bfcfb2303c5ee7cbf3ff6b7d7f4035",
    "url": "/stockmoney/json_otc/chip_borrow.json"
  },
  {
    "revision": "5a8bd57521f8a67e6f158eda3faacf21",
    "url": "/stockmoney/json_otc/chip_borrow_cols.json"
  },
  {
    "revision": "4a7698a544c7ec6f83289fa7a8be2e6b",
    "url": "/stockmoney/json_otc/chip_director.json"
  },
  {
    "revision": "a334a801ea970d199688594ea26ebc8f",
    "url": "/stockmoney/json_otc/chip_director1.json"
  },
  {
    "revision": "8e7a0bacff28aa1cf9f5825c7712c937",
    "url": "/stockmoney/json_otc/chip_director1_cols.json"
  },
  {
    "revision": "e9984547f8c6f586d5f5837c3979abfa",
    "url": "/stockmoney/json_otc/chip_director3.json"
  },
  {
    "revision": "cb725822bf310830ac86771e76bbf7e5",
    "url": "/stockmoney/json_otc/chip_director3_cols.json"
  },
  {
    "revision": "37bd9052fc6d52424eeb67c46d6ad4b9",
    "url": "/stockmoney/json_otc/chip_director5.json"
  },
  {
    "revision": "9e1f67c918b55fd9c2153dc91b5ea992",
    "url": "/stockmoney/json_otc/chip_director5_cols.json"
  },
  {
    "revision": "79dce6a98cc61675f28207bb8ee66d68",
    "url": "/stockmoney/json_otc/chip_director_cols.json"
  },
  {
    "revision": "e4b50adc245f621e2110cfa922d42b08",
    "url": "/stockmoney/json_otc/chip_foreign.json"
  },
  {
    "revision": "e59f62dd4b9a788009bac352d7e91c12",
    "url": "/stockmoney/json_otc/chip_foreign_cols.json"
  },
  {
    "revision": "aad0c54932cbbf75b13a93be9d1474d0",
    "url": "/stockmoney/json_otc/chip_holder.json"
  },
  {
    "revision": "0d80a0b66a710be5c8449613ed1abad2",
    "url": "/stockmoney/json_otc/chip_holder_cols.json"
  },
  {
    "revision": "6c2453579e395c4f2b70aed4d00ecf1e",
    "url": "/stockmoney/json_otc/chip_legal.json"
  },
  {
    "revision": "56a5a51151871b1624874a4fe5a82f83",
    "url": "/stockmoney/json_otc/chip_legal_cols.json"
  },
  {
    "revision": "157b935e74f621a7a2d8a174b3e2f6d7",
    "url": "/stockmoney/json_otc/chip_loan.json"
  },
  {
    "revision": "ee402593614d4650e99e562d17e63538",
    "url": "/stockmoney/json_otc/chip_loan_cols.json"
  },
  {
    "revision": "4247881b9738f71cce1d95e8f010b88c",
    "url": "/stockmoney/json_otc/chip_trust.json"
  },
  {
    "revision": "4466ee075166bd957824b4a6d6c6ddbe",
    "url": "/stockmoney/json_otc/chip_trust_cols.json"
  },
  {
    "revision": "31f83f5d3ef9e02413207a9e41d4e47a",
    "url": "/stockmoney/json_otc/deal_pct.json"
  },
  {
    "revision": "6aa4eed51cba9dc1dc746762256d9659",
    "url": "/stockmoney/json_otc/deal_pct_cols.json"
  },
  {
    "revision": "a962123d12692301c3963089fd93de97",
    "url": "/stockmoney/json_otc/deal_vol.json"
  },
  {
    "revision": "b27cd4bd88359e51326cd3dab8215f69",
    "url": "/stockmoney/json_otc/deal_vol_cols.json"
  },
  {
    "revision": "b284bafb448258b5f9cb2dc0ca44a820",
    "url": "/stockmoney/json_otc/dividend_cont.json"
  },
  {
    "revision": "d770b65af07d9d64a25e81b34c57086f",
    "url": "/stockmoney/json_otc/dividend_cont_cols.json"
  },
  {
    "revision": "0149ee9eff3debf2488e9007159eb756",
    "url": "/stockmoney/json_otc/dividend_stat.json"
  },
  {
    "revision": "2a8cb39132916cf284bf7fe0dd94120f",
    "url": "/stockmoney/json_otc/dividend_stat_2015.json"
  },
  {
    "revision": "cbec2feb676f6a6aa3b239e88e6d6a2c",
    "url": "/stockmoney/json_otc/dividend_stat_2015_cols.json"
  },
  {
    "revision": "b41109992355986597fa480f4a4fb94a",
    "url": "/stockmoney/json_otc/dividend_stat_2016.json"
  },
  {
    "revision": "6e18d58a36f9fc2a33f01cedfe00600b",
    "url": "/stockmoney/json_otc/dividend_stat_2016_cols.json"
  },
  {
    "revision": "7f3bab650e0a981723956e40047b220b",
    "url": "/stockmoney/json_otc/dividend_stat_2017.json"
  },
  {
    "revision": "297d5aebd0f10fcde9bb1a0e4ac5182e",
    "url": "/stockmoney/json_otc/dividend_stat_2017_cols.json"
  },
  {
    "revision": "8453a55874df25b38f2c651900fba58b",
    "url": "/stockmoney/json_otc/dividend_stat_2018.json"
  },
  {
    "revision": "260b5376813e3734a06dab71d8b9bd8a",
    "url": "/stockmoney/json_otc/dividend_stat_2018_cols.json"
  },
  {
    "revision": "c4ba543a19c8a28b99d2b74f37b3a433",
    "url": "/stockmoney/json_otc/dividend_stat_2019.json"
  },
  {
    "revision": "6050c49dcd02fe1bf54be9c00f3014eb",
    "url": "/stockmoney/json_otc/dividend_stat_2019_cols.json"
  },
  {
    "revision": "9b4c4be9545c11e770cbe8be386f94cb",
    "url": "/stockmoney/json_otc/dividend_stat_cols.json"
  },
  {
    "revision": "d31227df08211a6971423974154d044c",
    "url": "/stockmoney/json_otc/dividend_yield.json"
  },
  {
    "revision": "ecb2998fde71d849b8992a7b6c4e2e3d",
    "url": "/stockmoney/json_otc/dividend_yield_cols.json"
  },
  {
    "revision": "7070d461fca9f57f911b200dd2fc5bd8",
    "url": "/stockmoney/json_otc/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json_otc/export_director_cols.json"
  },
  {
    "revision": "bf4091968a9416ed62033f7746eeee19",
    "url": "/stockmoney/json_otc/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json_otc/export_incomerate_cols.json"
  },
  {
    "revision": "cd31b8a4e6ae79c8381334b713671557",
    "url": "/stockmoney/json_otc/export_stockfish.json"
  },
  {
    "revision": "192fef50d1b0b739db62b78e28521927",
    "url": "/stockmoney/json_otc/export_stockfish_cols.json"
  },
  {
    "revision": "06644a4d0d24006b9520f689110d209f",
    "url": "/stockmoney/json_otc/export_triplerate.json"
  },
  {
    "revision": "a625f25eee5bf1c3f165bc86c455ce79",
    "url": "/stockmoney/json_otc/export_triplerate_cols.json"
  },
  {
    "revision": "962233c053e6db9fe7b8fc8ba435e819",
    "url": "/stockmoney/json_otc/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json_otc/export_water_cols.json"
  },
  {
    "revision": "c55c440719a695161addc6d1fe124f60",
    "url": "/stockmoney/json_otc/export_yield.json"
  },
  {
    "revision": "49e7cdd201cc3d5a6cd680c3a5aa3c7f",
    "url": "/stockmoney/json_otc/my_basic.json"
  },
  {
    "revision": "12af128c5c8cb61ac4c2042aefe1f0cf",
    "url": "/stockmoney/json_otc/my_eps.json"
  },
  {
    "revision": "ee41870e2a556afa1b4a4cb967744e6d",
    "url": "/stockmoney/json_otc/my_eps_cols.json"
  },
  {
    "revision": "0c2f976dd46752d462d2fc5241f24866",
    "url": "/stockmoney/json_otc/price_dpct.json"
  },
  {
    "revision": "4a8550ef29380c4fa8d8ac437919bf01",
    "url": "/stockmoney/json_otc/price_dpct_cols.json"
  },
  {
    "revision": "3f16317ac854d68fce09dd3a3df01461",
    "url": "/stockmoney/json_otc/price_mpct.json"
  },
  {
    "revision": "f49e4c8c592ee192541945e62871c3d3",
    "url": "/stockmoney/json_otc/price_mpct_cols.json"
  },
  {
    "revision": "cbc2be0cc1fc962b48cec1ed03fd217f",
    "url": "/stockmoney/json_otc/price_wpct.json"
  },
  {
    "revision": "5274839ff9361763e75b70bb12e266d6",
    "url": "/stockmoney/json_otc/price_wpct_cols.json"
  },
  {
    "revision": "763859fb0cfbd78fe6df3c72847a1239",
    "url": "/stockmoney/json_otc/tech_bch.json"
  },
  {
    "revision": "1f3501a7241684346326f6b20fef29ab",
    "url": "/stockmoney/json_otc/tech_bch_cols.json"
  },
  {
    "revision": "a2af31593dedb8092bcc424342449741",
    "url": "/stockmoney/json_otc/tech_beta.json"
  },
  {
    "revision": "1d1993c61608814513697231793da5ff",
    "url": "/stockmoney/json_otc/tech_beta_cols.json"
  },
  {
    "revision": "a3d85a445f893e39302983bdbd8e2038",
    "url": "/stockmoney/json_otc/tech_kd.json"
  },
  {
    "revision": "4f5d6ca8656dd449a555f2892c29746e",
    "url": "/stockmoney/json_otc/tech_kd_cols.json"
  },
  {
    "revision": "72aae5c22aeb5c48af97f5f62d9174da",
    "url": "/stockmoney/json_otc/triplerate_gross.json"
  },
  {
    "revision": "bdea5894fe1ee11fe29b8c1b086f8b14",
    "url": "/stockmoney/json_otc/triplerate_gross_cols.json"
  },
  {
    "revision": "54a035f90406792bdfa49559404b825b",
    "url": "/stockmoney/json_otc/triplerate_net.json"
  },
  {
    "revision": "131977477f007368864220bd92c5b140",
    "url": "/stockmoney/json_otc/triplerate_net_cols.json"
  },
  {
    "revision": "38b92269236a81c4144fd6052ffe6d62",
    "url": "/stockmoney/json_otc/triplerate_opp.json"
  },
  {
    "revision": "101ce9c11dafd51f9b77daa28ec5e106",
    "url": "/stockmoney/json_otc/triplerate_opp_cols.json"
  },
  {
    "revision": "f7352486aa9add8e57bf6a7909865edf",
    "url": "/stockmoney/json_otc/year_eps.json"
  },
  {
    "revision": "6d3ef962007b26c6d23c4c5d7a057cc8",
    "url": "/stockmoney/json_otc/year_eps_cols.json"
  },
  {
    "revision": "830b6c972b1bb88ccf9ff003c74b676c",
    "url": "/stockmoney/json_otc/year_roe.json"
  },
  {
    "revision": "07c767a967283717369ecc8e0f0f7d99",
    "url": "/stockmoney/json_otc/year_roe_cols.json"
  },
  {
    "revision": "b96e0d5a5df171b63ae60164bac0e3af",
    "url": "/stockmoney/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/stockmoney/robots.txt"
  },
  {
    "revision": "edc213fc6ea3e52e1474",
    "url": "/stockmoney/static/css/app.29133ace.css"
  },
  {
    "revision": "a7bd39673262647df6da",
    "url": "/stockmoney/static/css/chunk-vendors.eae4093c.css"
  },
  {
    "revision": "ecb3bfc03db10b6f9d6e23e710d5c953",
    "url": "/stockmoney/static/img/logo.ecb3bfc0.png"
  },
  {
    "revision": "658800e4ddcdedaaa231",
    "url": "/stockmoney/static/js/about.6cc0e21f.js"
  },
  {
    "revision": "edc213fc6ea3e52e1474",
    "url": "/stockmoney/static/js/app.018c9625.js"
  },
  {
    "revision": "a7bd39673262647df6da",
    "url": "/stockmoney/static/js/chunk-vendors.1f857820.js"
  }
]);