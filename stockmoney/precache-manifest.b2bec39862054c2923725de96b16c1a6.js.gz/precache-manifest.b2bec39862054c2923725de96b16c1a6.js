self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2f177b16da5e0bde91db0030ffc93d94",
    "url": "/stockmoney/index.html"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json/.dummy"
  },
  {
    "revision": "24a700eb2359661788c7c6ab82f6e802",
    "url": "/stockmoney/json/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json/basic_4season_cols.json"
  },
  {
    "revision": "2efa2cae8ae8ea2645cca33005415346",
    "url": "/stockmoney/json/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json/basic_asset_cols.json"
  },
  {
    "revision": "832061a16b752498caea9754f51953db",
    "url": "/stockmoney/json/basic_cash.json"
  },
  {
    "revision": "e99c7a8088d70141d6bb7817ca9c0456",
    "url": "/stockmoney/json/basic_cash_cols.json"
  },
  {
    "revision": "64a0c6df256f0bf277ee9e729432d8ef",
    "url": "/stockmoney/json/basic_debt.json"
  },
  {
    "revision": "51d119ed52ea0a25ca92ae98c2465d05",
    "url": "/stockmoney/json/basic_debt_cols.json"
  },
  {
    "revision": "ebc992aaab804a5d97af0db22830ec66",
    "url": "/stockmoney/json/basic_eps.json"
  },
  {
    "revision": "7c36b3b4cd77b006b8917c89a29eae1e",
    "url": "/stockmoney/json/basic_eps_cols.json"
  },
  {
    "revision": "a220c386e7406890386805513060e02e",
    "url": "/stockmoney/json/basic_gross.json"
  },
  {
    "revision": "178782397086a5d7c62abe7bae8ecff8",
    "url": "/stockmoney/json/basic_gross_cols.json"
  },
  {
    "revision": "7674aa3af0516b878e1e26d8dde74414",
    "url": "/stockmoney/json/basic_info.json"
  },
  {
    "revision": "13e705f89a2b21a1bed5151ba2614a3a",
    "url": "/stockmoney/json/basic_info_cols.json"
  },
  {
    "revision": "b30e1749ea1bc9f25d6b4bd323c2483c",
    "url": "/stockmoney/json/basic_net.json"
  },
  {
    "revision": "89209aed25a6960fa6d46b91ee084982",
    "url": "/stockmoney/json/basic_net_cols.json"
  },
  {
    "revision": "f4d61cc88012ba85854970d69fda5bca",
    "url": "/stockmoney/json/basic_noi.json"
  },
  {
    "revision": "ec79f376c13cef24684a7b3d08d494a4",
    "url": "/stockmoney/json/basic_noi_cols.json"
  },
  {
    "revision": "a3e651e164e7710a960706b97d6ea079",
    "url": "/stockmoney/json/basic_opm.json"
  },
  {
    "revision": "c26e8731d6e069b7e96cc7d2581495c8",
    "url": "/stockmoney/json/basic_opm_cols.json"
  },
  {
    "revision": "5eda793c05c27626aa4eaa58f3581b3b",
    "url": "/stockmoney/json/basic_opp.json"
  },
  {
    "revision": "5dcb84627bf5795557db0139b9e6bbc5",
    "url": "/stockmoney/json/basic_opp_cols.json"
  },
  {
    "revision": "db050790fcf0149b1e64f2b3e450873b",
    "url": "/stockmoney/json/basic_roe.json"
  },
  {
    "revision": "cd34e2ec22c379df4957d314aef039ce",
    "url": "/stockmoney/json/basic_roe_cols.json"
  },
  {
    "revision": "7f6a9e404835530f24667d8774dc7493",
    "url": "/stockmoney/json/basic_rvn.json"
  },
  {
    "revision": "946da565daafda7afa0853b831a44575",
    "url": "/stockmoney/json/basic_rvn_cols.json"
  },
  {
    "revision": "6fd0a054c57f92f682ad571bf3999d01",
    "url": "/stockmoney/json/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json/basic_yearw_cols.json"
  },
  {
    "revision": "a92599a7683de526e7b08491571e0355",
    "url": "/stockmoney/json/chip_borrow.json"
  },
  {
    "revision": "b9d898714914df8c330d1f25fd728bd4",
    "url": "/stockmoney/json/chip_borrow_cols.json"
  },
  {
    "revision": "c048e6f2e1c9f4b0a42709f00eb32e4e",
    "url": "/stockmoney/json/chip_director.json"
  },
  {
    "revision": "10862401b531b18e1a2272a49134c017",
    "url": "/stockmoney/json/chip_director1.json"
  },
  {
    "revision": "9245b933efe32254018a0a6e9a6c8613",
    "url": "/stockmoney/json/chip_director1_cols.json"
  },
  {
    "revision": "18384446321a9d65ddf364333ff79b4f",
    "url": "/stockmoney/json/chip_director3.json"
  },
  {
    "revision": "b856d752ee7572bba69b5bfefbe9e41b",
    "url": "/stockmoney/json/chip_director3_cols.json"
  },
  {
    "revision": "62c4a069d99aa75ac976a695663f0d5b",
    "url": "/stockmoney/json/chip_director5.json"
  },
  {
    "revision": "825ba91683006403a96e4ead7ebc2e2c",
    "url": "/stockmoney/json/chip_director5_cols.json"
  },
  {
    "revision": "9bbbf6600d4c03482470ae7a8ed48118",
    "url": "/stockmoney/json/chip_director_cols.json"
  },
  {
    "revision": "efa7eaca105a23053bc85964b64dc053",
    "url": "/stockmoney/json/chip_foreign.json"
  },
  {
    "revision": "1f66416e66912403af00c4d2366c2741",
    "url": "/stockmoney/json/chip_foreign_cols.json"
  },
  {
    "revision": "0fd2562b4233e3ed248b8d16cde55769",
    "url": "/stockmoney/json/chip_legal.json"
  },
  {
    "revision": "60a82514c04d8b46e234b6c3b7db8a4c",
    "url": "/stockmoney/json/chip_legal_cols.json"
  },
  {
    "revision": "3b4545e4915daf270fef48dbb0a5aa77",
    "url": "/stockmoney/json/chip_loan.json"
  },
  {
    "revision": "5396a6b60fdb18143f688500ef15b099",
    "url": "/stockmoney/json/chip_loan_cols.json"
  },
  {
    "revision": "69d4648de06d272e00bcd160c107dd3e",
    "url": "/stockmoney/json/chip_trust.json"
  },
  {
    "revision": "0453c094ec1578d8b609550d9e477938",
    "url": "/stockmoney/json/chip_trust_cols.json"
  },
  {
    "revision": "76421a863fdd8ea27c442ab844afe4af",
    "url": "/stockmoney/json/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json/deal_pct_cols.json"
  },
  {
    "revision": "0d1e8d65b15d0110b6c873c1a04f236b",
    "url": "/stockmoney/json/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json/deal_vol_cols.json"
  },
  {
    "revision": "08f16146a5e70864ddbb0edc2b9b3669",
    "url": "/stockmoney/json/dividend_cont.json"
  },
  {
    "revision": "e98f37eaa810fd912b66473ef4aec297",
    "url": "/stockmoney/json/dividend_cont_cols.json"
  },
  {
    "revision": "c9e08f62448b970d5eddefd9b1c05e10",
    "url": "/stockmoney/json/dividend_stat.json"
  },
  {
    "revision": "357154626c5f9a734e699a40f6afe3d3",
    "url": "/stockmoney/json/dividend_stat_2015.json"
  },
  {
    "revision": "008c79d526737b517a9a742b04502b20",
    "url": "/stockmoney/json/dividend_stat_2015_cols.json"
  },
  {
    "revision": "a246681183066b41d74718f7738edfa5",
    "url": "/stockmoney/json/dividend_stat_2016.json"
  },
  {
    "revision": "ec5a0a94673998b0bb4a63db93d08f4a",
    "url": "/stockmoney/json/dividend_stat_2016_cols.json"
  },
  {
    "revision": "24bf7c6e4834ea505c54469fb33027a7",
    "url": "/stockmoney/json/dividend_stat_2017.json"
  },
  {
    "revision": "e37fc91cd72912b24657ed675d9f1c8b",
    "url": "/stockmoney/json/dividend_stat_2017_cols.json"
  },
  {
    "revision": "fb7d4c68232f223bd91132e27135fb53",
    "url": "/stockmoney/json/dividend_stat_2018.json"
  },
  {
    "revision": "38050d84b8d337ce366fb397e8e206f7",
    "url": "/stockmoney/json/dividend_stat_2018_cols.json"
  },
  {
    "revision": "a408b87efdc73dbdff6a497d646e7459",
    "url": "/stockmoney/json/dividend_stat_2019.json"
  },
  {
    "revision": "7ec66cdc30aa0d150bc4f797bdc131c4",
    "url": "/stockmoney/json/dividend_stat_2019_cols.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json/dividend_stat_cols.json"
  },
  {
    "revision": "efb1d39fc0d2696efbcc9286136c37c6",
    "url": "/stockmoney/json/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json/dividend_yield_cols.json"
  },
  {
    "revision": "038911e371b0ecd2442b382c17b9bc1d",
    "url": "/stockmoney/json/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json/export_director_cols.json"
  },
  {
    "revision": "45949bbd114cd03c0069bb774ae2c388",
    "url": "/stockmoney/json/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json/export_incomerate_cols.json"
  },
  {
    "revision": "d4f7e8b40710ca034b1f1908e23e7ac1",
    "url": "/stockmoney/json/export_stockfish.json"
  },
  {
    "revision": "aa76bf1d9931072a3fe9c3e216868eac",
    "url": "/stockmoney/json/export_stockfish_cols.json"
  },
  {
    "revision": "904f16750784ebb61636b5ec4e355d9e",
    "url": "/stockmoney/json/export_triplerate.json"
  },
  {
    "revision": "2f91c73c151fa60608962f562b8d2bc9",
    "url": "/stockmoney/json/export_triplerate_cols.json"
  },
  {
    "revision": "fa09514202bed1ef11044be8d20fad74",
    "url": "/stockmoney/json/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json/export_water_cols.json"
  },
  {
    "revision": "feabd175aa1c9cbcb493bbfb5c4e7b94",
    "url": "/stockmoney/json/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json/export_yield_cols.json"
  },
  {
    "revision": "d9092aac3ad34602e9de6d15ee31890e",
    "url": "/stockmoney/json/my_chip.json"
  },
  {
    "revision": "31f13bcaaeeb988567d3ef69e28064f2",
    "url": "/stockmoney/json/my_chip_cols.json"
  },
  {
    "revision": "6c1c628345fae91dd7261b43926eb933",
    "url": "/stockmoney/json/my_eps.json"
  },
  {
    "revision": "87b98bb7ccff2628d43fe83db7362e93",
    "url": "/stockmoney/json/my_eps_cols.json"
  },
  {
    "revision": "408fc0319d736931d78be47cca854afa",
    "url": "/stockmoney/json/price_high.json"
  },
  {
    "revision": "1e35d3daa917b04a37ebd04bbb7506d7",
    "url": "/stockmoney/json/price_high_cols.json"
  },
  {
    "revision": "cf13994574077ae5d16ad2a16fa8b0fa",
    "url": "/stockmoney/json/tech_bch.json"
  },
  {
    "revision": "4ceab57a8c9a6cd7e19f2b097e934cc2",
    "url": "/stockmoney/json/tech_bch_cols.json"
  },
  {
    "revision": "7c8798ebac67152e1e5526b3a39be85f",
    "url": "/stockmoney/json/tech_beta.json"
  },
  {
    "revision": "8f09f6a30643cd54d5275425bea06c52",
    "url": "/stockmoney/json/tech_beta_cols.json"
  },
  {
    "revision": "49c398304ba71159fc580b9b6c437280",
    "url": "/stockmoney/json/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json/tech_kd_cols.json"
  },
  {
    "revision": "4afc4096dd0e5eb659b774a04057b42e",
    "url": "/stockmoney/json/tech_ma.json"
  },
  {
    "revision": "0312283011ee3335e1c1333e9725ace1",
    "url": "/stockmoney/json/tech_ma_cols.json"
  },
  {
    "revision": "cfb094bbac842bc782db0580e53f446c",
    "url": "/stockmoney/json/triplerate_gross.json"
  },
  {
    "revision": "2511f8c50358a8a335bf610cef718b00",
    "url": "/stockmoney/json/triplerate_gross_cols.json"
  },
  {
    "revision": "052dcbd3cca007ed358342dfed7f8650",
    "url": "/stockmoney/json/triplerate_net.json"
  },
  {
    "revision": "17245371cdae86da68309943e5ddfaff",
    "url": "/stockmoney/json/triplerate_net_cols.json"
  },
  {
    "revision": "f753a053aa91c7516a2a6737b4681a62",
    "url": "/stockmoney/json/triplerate_opp.json"
  },
  {
    "revision": "940abcb362ffa6241e052e7f9b3d61f8",
    "url": "/stockmoney/json/triplerate_opp_cols.json"
  },
  {
    "revision": "bf2dc6e12ddeb43f356fca037bd535cd",
    "url": "/stockmoney/json/year_eps.json"
  },
  {
    "revision": "f321e16b4cd8fd855a9cee2ef177b409",
    "url": "/stockmoney/json/year_eps_cols.json"
  },
  {
    "revision": "baac6270dbdbb1600b220178e56afa4c",
    "url": "/stockmoney/json/year_roe.json"
  },
  {
    "revision": "3f77aaa3413033391cb686fa0fe62b20",
    "url": "/stockmoney/json/year_roe_cols.json"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json_otc/.dummy"
  },
  {
    "revision": "f06310f681fef64bf1fa29af19af99e5",
    "url": "/stockmoney/json_otc/basic_4season.json"
  },
  {
    "revision": "5af8e03d5ac2fd4ca03652dd2b98f6f0",
    "url": "/stockmoney/json_otc/basic_4season_cols.json"
  },
  {
    "revision": "71bd980f0bd443471d55719c3ca3cc4a",
    "url": "/stockmoney/json_otc/basic_asset.json"
  },
  {
    "revision": "b38212d12f678a74ad6a6565339df931",
    "url": "/stockmoney/json_otc/basic_asset_cols.json"
  },
  {
    "revision": "5ab8809393f13292fb96f666a775e1e6",
    "url": "/stockmoney/json_otc/basic_cash.json"
  },
  {
    "revision": "f2715297b82d84f75777481f7ce161e0",
    "url": "/stockmoney/json_otc/basic_cash_cols.json"
  },
  {
    "revision": "78c304e4b4ffd7aff6467a3987dc122e",
    "url": "/stockmoney/json_otc/basic_debt.json"
  },
  {
    "revision": "6ddc3182fcf1e8aef2c9ddae23e14368",
    "url": "/stockmoney/json_otc/basic_debt_cols.json"
  },
  {
    "revision": "f1ba6251d3d38002b41b2bde7b164b9f",
    "url": "/stockmoney/json_otc/basic_eps.json"
  },
  {
    "revision": "7032a59ac84e0e1a7b4ff457a6fe3aa9",
    "url": "/stockmoney/json_otc/basic_eps_cols.json"
  },
  {
    "revision": "a0eae5024a39f7825560a3dfbc859758",
    "url": "/stockmoney/json_otc/basic_gross.json"
  },
  {
    "revision": "c182a898930819d990d76aeaa8bb1060",
    "url": "/stockmoney/json_otc/basic_gross_cols.json"
  },
  {
    "revision": "6c5475efb7e9d9dad50456e70cebd3ad",
    "url": "/stockmoney/json_otc/basic_info.json"
  },
  {
    "revision": "6f99a8a60e35b64e93e4e87ccbc4e5dd",
    "url": "/stockmoney/json_otc/basic_info_cols.json"
  },
  {
    "revision": "880602ef2c08164a5df90168b0b3e8b2",
    "url": "/stockmoney/json_otc/basic_net.json"
  },
  {
    "revision": "64dd6cff67c401df4b89917a3489e57a",
    "url": "/stockmoney/json_otc/basic_net_cols.json"
  },
  {
    "revision": "8effd4ec6ca84e5d3a5a4d40c503235b",
    "url": "/stockmoney/json_otc/basic_noi.json"
  },
  {
    "revision": "f3c506d720c0fd09b4f8b4f20d768765",
    "url": "/stockmoney/json_otc/basic_noi_cols.json"
  },
  {
    "revision": "002ec926eac3283aef56fd44f59c8822",
    "url": "/stockmoney/json_otc/basic_opm.json"
  },
  {
    "revision": "ccb2ff3eb797f36a935ebcb795457417",
    "url": "/stockmoney/json_otc/basic_opm_cols.json"
  },
  {
    "revision": "7014e6cda17b420f62b93362ed70031c",
    "url": "/stockmoney/json_otc/basic_opp.json"
  },
  {
    "revision": "dd3783cd244d75a7d3c027e580432ae2",
    "url": "/stockmoney/json_otc/basic_opp_cols.json"
  },
  {
    "revision": "cff779d330bd9b97b8422aed316367cb",
    "url": "/stockmoney/json_otc/basic_roe.json"
  },
  {
    "revision": "53f6f8b1d382a56c8520248e0ae8c257",
    "url": "/stockmoney/json_otc/basic_roe_cols.json"
  },
  {
    "revision": "ca2091f1eba97900507fb703d2fb02a3",
    "url": "/stockmoney/json_otc/basic_rvn.json"
  },
  {
    "revision": "3fe4baea3afbbefd5f0b8dbccb5201ca",
    "url": "/stockmoney/json_otc/basic_rvn_cols.json"
  },
  {
    "revision": "5c2d8d3525214658ca06b578a82e7a5e",
    "url": "/stockmoney/json_otc/basic_yearw.json"
  },
  {
    "revision": "37afed6bf332938bf457759590f15e20",
    "url": "/stockmoney/json_otc/basic_yearw_cols.json"
  },
  {
    "revision": "a7000a4557004a312d502661cc94271f",
    "url": "/stockmoney/json_otc/chip_borrow.json"
  },
  {
    "revision": "5a8bd57521f8a67e6f158eda3faacf21",
    "url": "/stockmoney/json_otc/chip_borrow_cols.json"
  },
  {
    "revision": "529ecbd561c645081fcfaeaa089361a6",
    "url": "/stockmoney/json_otc/chip_director.json"
  },
  {
    "revision": "363b24aff3da9b815a23a94e5dccef2a",
    "url": "/stockmoney/json_otc/chip_director1.json"
  },
  {
    "revision": "8e7a0bacff28aa1cf9f5825c7712c937",
    "url": "/stockmoney/json_otc/chip_director1_cols.json"
  },
  {
    "revision": "0a47988f3fc3cde6359dc6d134f8d7aa",
    "url": "/stockmoney/json_otc/chip_director3.json"
  },
  {
    "revision": "cb725822bf310830ac86771e76bbf7e5",
    "url": "/stockmoney/json_otc/chip_director3_cols.json"
  },
  {
    "revision": "abeac1084cefad991b4417013893df92",
    "url": "/stockmoney/json_otc/chip_director5.json"
  },
  {
    "revision": "9e1f67c918b55fd9c2153dc91b5ea992",
    "url": "/stockmoney/json_otc/chip_director5_cols.json"
  },
  {
    "revision": "79dce6a98cc61675f28207bb8ee66d68",
    "url": "/stockmoney/json_otc/chip_director_cols.json"
  },
  {
    "revision": "051bc9e1498a248d4be74c0e6fdcf71f",
    "url": "/stockmoney/json_otc/chip_foreign.json"
  },
  {
    "revision": "e59f62dd4b9a788009bac352d7e91c12",
    "url": "/stockmoney/json_otc/chip_foreign_cols.json"
  },
  {
    "revision": "a7fcca1d627348e287bca49631017347",
    "url": "/stockmoney/json_otc/chip_legal.json"
  },
  {
    "revision": "56a5a51151871b1624874a4fe5a82f83",
    "url": "/stockmoney/json_otc/chip_legal_cols.json"
  },
  {
    "revision": "8f136e20b6100ca8f9bf9aac1bb8b2d2",
    "url": "/stockmoney/json_otc/chip_loan.json"
  },
  {
    "revision": "5396a6b60fdb18143f688500ef15b099",
    "url": "/stockmoney/json_otc/chip_loan_cols.json"
  },
  {
    "revision": "d510431229ec49955df2eaad12b48ed7",
    "url": "/stockmoney/json_otc/chip_trust.json"
  },
  {
    "revision": "4466ee075166bd957824b4a6d6c6ddbe",
    "url": "/stockmoney/json_otc/chip_trust_cols.json"
  },
  {
    "revision": "a8b589317d5cbab6bf1c0d22da216357",
    "url": "/stockmoney/json_otc/deal_pct.json"
  },
  {
    "revision": "6aa4eed51cba9dc1dc746762256d9659",
    "url": "/stockmoney/json_otc/deal_pct_cols.json"
  },
  {
    "revision": "23acb1e4daf63288448efaa91786f34c",
    "url": "/stockmoney/json_otc/deal_vol.json"
  },
  {
    "revision": "b27cd4bd88359e51326cd3dab8215f69",
    "url": "/stockmoney/json_otc/deal_vol_cols.json"
  },
  {
    "revision": "ceaeacf9f14edfbe3ddcc4f03f857f01",
    "url": "/stockmoney/json_otc/dividend_cont.json"
  },
  {
    "revision": "d770b65af07d9d64a25e81b34c57086f",
    "url": "/stockmoney/json_otc/dividend_cont_cols.json"
  },
  {
    "revision": "72c9da9a784de443bfd450a7a43ba485",
    "url": "/stockmoney/json_otc/dividend_stat.json"
  },
  {
    "revision": "dc732d95e61c772e0d5dfef761a2b939",
    "url": "/stockmoney/json_otc/dividend_stat_2015.json"
  },
  {
    "revision": "cbec2feb676f6a6aa3b239e88e6d6a2c",
    "url": "/stockmoney/json_otc/dividend_stat_2015_cols.json"
  },
  {
    "revision": "5d92fd1e29b6bdf9a7bb3e05d8f949ca",
    "url": "/stockmoney/json_otc/dividend_stat_2016.json"
  },
  {
    "revision": "6e18d58a36f9fc2a33f01cedfe00600b",
    "url": "/stockmoney/json_otc/dividend_stat_2016_cols.json"
  },
  {
    "revision": "1e1db151f95267d617b3590cfb96882c",
    "url": "/stockmoney/json_otc/dividend_stat_2017.json"
  },
  {
    "revision": "297d5aebd0f10fcde9bb1a0e4ac5182e",
    "url": "/stockmoney/json_otc/dividend_stat_2017_cols.json"
  },
  {
    "revision": "3d2314d5d04827612ae1ee1c5a026604",
    "url": "/stockmoney/json_otc/dividend_stat_2018.json"
  },
  {
    "revision": "260b5376813e3734a06dab71d8b9bd8a",
    "url": "/stockmoney/json_otc/dividend_stat_2018_cols.json"
  },
  {
    "revision": "8ec292615a18c857aad64ba93467c4d0",
    "url": "/stockmoney/json_otc/dividend_stat_2019.json"
  },
  {
    "revision": "6050c49dcd02fe1bf54be9c00f3014eb",
    "url": "/stockmoney/json_otc/dividend_stat_2019_cols.json"
  },
  {
    "revision": "9b4c4be9545c11e770cbe8be386f94cb",
    "url": "/stockmoney/json_otc/dividend_stat_cols.json"
  },
  {
    "revision": "da53a909c4d42fdcdd6af9cf57f12d91",
    "url": "/stockmoney/json_otc/dividend_yield.json"
  },
  {
    "revision": "ecb2998fde71d849b8992a7b6c4e2e3d",
    "url": "/stockmoney/json_otc/dividend_yield_cols.json"
  },
  {
    "revision": "67978166175f9faf442fa8308440fbfd",
    "url": "/stockmoney/json_otc/export_director.json"
  },
  {
    "revision": "ddcdee328066513aab63255848beda17",
    "url": "/stockmoney/json_otc/export_incomerate.json"
  },
  {
    "revision": "63ba1d1637bd0ae1073fd99755809442",
    "url": "/stockmoney/json_otc/export_stockfish.json"
  },
  {
    "revision": "ac92f58a7bca6475b14b2beb04a085c2",
    "url": "/stockmoney/json_otc/export_triplerate.json"
  },
  {
    "revision": "b40b813e40da1448db916281fba8be42",
    "url": "/stockmoney/json_otc/export_water.json"
  },
  {
    "revision": "3a5a9b07708241c673563660b9377186",
    "url": "/stockmoney/json_otc/export_yield.json"
  },
  {
    "revision": "93911d71e73b707bcf857d8bdab4e52d",
    "url": "/stockmoney/json_otc/my_eps.json"
  },
  {
    "revision": "4f478966a55a2bb1438da5e8587aa10a",
    "url": "/stockmoney/json_otc/tech_bch.json"
  },
  {
    "revision": "1f3501a7241684346326f6b20fef29ab",
    "url": "/stockmoney/json_otc/tech_bch_cols.json"
  },
  {
    "revision": "9b1ced7b9b86d13e79d0f25e9488089f",
    "url": "/stockmoney/json_otc/tech_beta.json"
  },
  {
    "revision": "1d1993c61608814513697231793da5ff",
    "url": "/stockmoney/json_otc/tech_beta_cols.json"
  },
  {
    "revision": "14cb010229b4de7f47aecb754166440b",
    "url": "/stockmoney/json_otc/tech_kd.json"
  },
  {
    "revision": "4f5d6ca8656dd449a555f2892c29746e",
    "url": "/stockmoney/json_otc/tech_kd_cols.json"
  },
  {
    "revision": "1876469ed5ac80fdb20a8f7e73400926",
    "url": "/stockmoney/json_otc/tech_ma.json"
  },
  {
    "revision": "d6c2c2c917b71f3b85765373cb229222",
    "url": "/stockmoney/json_otc/tech_ma_cols.json"
  },
  {
    "revision": "0ed3c518ab5aeea960ee2971bcfffe16",
    "url": "/stockmoney/json_otc/triplerate_gross.json"
  },
  {
    "revision": "da57a241c25d7f4ae9626ec64c96c23d",
    "url": "/stockmoney/json_otc/triplerate_gross_cols.json"
  },
  {
    "revision": "efa924d08a15519431bc2cc146342c5f",
    "url": "/stockmoney/json_otc/triplerate_net.json"
  },
  {
    "revision": "1614c752ad02d7d2378e50f31d867877",
    "url": "/stockmoney/json_otc/triplerate_net_cols.json"
  },
  {
    "revision": "47967d116c0ea0cf25bd59899c0d431f",
    "url": "/stockmoney/json_otc/triplerate_opp.json"
  },
  {
    "revision": "6d5e20c02490a67b40f5a87405ef310c",
    "url": "/stockmoney/json_otc/triplerate_opp_cols.json"
  },
  {
    "revision": "6cccab4a03f0fe2c3e1397c93740064e",
    "url": "/stockmoney/json_otc/year_eps.json"
  },
  {
    "revision": "80b1bf77a3103041803654f78be57eca",
    "url": "/stockmoney/json_otc/year_eps_cols.json"
  },
  {
    "revision": "d468af70ecbaca0057d17c24e9a65eba",
    "url": "/stockmoney/json_otc/year_roe.json"
  },
  {
    "revision": "82891d9b63b9e51b573c0c50550a8143",
    "url": "/stockmoney/json_otc/year_roe_cols.json"
  },
  {
    "revision": "b96e0d5a5df171b63ae60164bac0e3af",
    "url": "/stockmoney/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/stockmoney/robots.txt"
  },
  {
    "revision": "7f8dcde8b28f9454d4e5",
    "url": "/stockmoney/static/css/app.ab2c9892.css"
  },
  {
    "revision": "0b67f49ecef966899a76",
    "url": "/stockmoney/static/css/chunk-vendors.eae4093c.css"
  },
  {
    "revision": "ecb3bfc03db10b6f9d6e23e710d5c953",
    "url": "/stockmoney/static/img/logo.ecb3bfc0.png"
  },
  {
    "revision": "658800e4ddcdedaaa231",
    "url": "/stockmoney/static/js/about.6cc0e21f.js"
  },
  {
    "revision": "7f8dcde8b28f9454d4e5",
    "url": "/stockmoney/static/js/app.964590e7.js"
  },
  {
    "revision": "0b67f49ecef966899a76",
    "url": "/stockmoney/static/js/chunk-vendors.e64b16c7.js"
  }
]);