self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "96606efcf9c6c8d30d1f5f4747dab45f",
    "url": "/stockmoney/index.html"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json/.dummy"
  },
  {
    "revision": "ac88a1f373c6ee8c81992d0794b965a7",
    "url": "/stockmoney/json/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json/basic_4season_cols.json"
  },
  {
    "revision": "6b25ed127e95f0e10a02c6336477940f",
    "url": "/stockmoney/json/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json/basic_asset_cols.json"
  },
  {
    "revision": "4e6987e6fe547ea6e7cd10e67e2852b1",
    "url": "/stockmoney/json/basic_cash.json"
  },
  {
    "revision": "c0244e115a5efbe13dab5ee9b3adb05a",
    "url": "/stockmoney/json/basic_cash_cols.json"
  },
  {
    "revision": "347ba5d122f501c7f2b7392a1338b70b",
    "url": "/stockmoney/json/basic_debt.json"
  },
  {
    "revision": "00491b3476a9c3646e4418c83f7ea44d",
    "url": "/stockmoney/json/basic_debt_cols.json"
  },
  {
    "revision": "e48ba0ef07e5dcd1685ab7b8f7c22d0a",
    "url": "/stockmoney/json/basic_eps.json"
  },
  {
    "revision": "d5b2fccfe0ccac6cdcc0f7cb4aaf6752",
    "url": "/stockmoney/json/basic_eps_cols.json"
  },
  {
    "revision": "91e9c9f33025e5037565ef6933b09a43",
    "url": "/stockmoney/json/basic_gross.json"
  },
  {
    "revision": "447c95b97b5305b8ba3b7ebe2200cbe1",
    "url": "/stockmoney/json/basic_gross_cols.json"
  },
  {
    "revision": "ac0db4a9e2e10e32f1872682b9445695",
    "url": "/stockmoney/json/basic_info.json"
  },
  {
    "revision": "2dbdaa83e5d85419907f0945a8bbb99d",
    "url": "/stockmoney/json/basic_info_cols.json"
  },
  {
    "revision": "b9f863bcfe0c6aa0e6f8d47d09495ea7",
    "url": "/stockmoney/json/basic_noi.json"
  },
  {
    "revision": "eca7a5d02e1973a244ada82c7d072a8e",
    "url": "/stockmoney/json/basic_noi_cols.json"
  },
  {
    "revision": "bf414cbd957458a92a6fd42b248759bb",
    "url": "/stockmoney/json/basic_opm.json"
  },
  {
    "revision": "08a05051f168ffe160f7028ec7eba48a",
    "url": "/stockmoney/json/basic_opm_cols.json"
  },
  {
    "revision": "cb052e0b213d53d75983bd7ae4049c52",
    "url": "/stockmoney/json/basic_opp.json"
  },
  {
    "revision": "6d9dc2a30ebc4a864d8d98b92c0efd2a",
    "url": "/stockmoney/json/basic_opp_cols.json"
  },
  {
    "revision": "a52d2fc36185f39fdc36c5ff492e41cc",
    "url": "/stockmoney/json/basic_roe.json"
  },
  {
    "revision": "1a79665afc3d1f1e8f54e37fde6691f4",
    "url": "/stockmoney/json/basic_roe_cols.json"
  },
  {
    "revision": "6181742a9e2c49863f651d14f1a758b9",
    "url": "/stockmoney/json/basic_rvn.json"
  },
  {
    "revision": "fa5f9c854d9e36237a74ca744dc4e484",
    "url": "/stockmoney/json/basic_rvn_cols.json"
  },
  {
    "revision": "91e97e3991047a94ce47c06845779968",
    "url": "/stockmoney/json/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json/basic_yearw_cols.json"
  },
  {
    "revision": "aeaf39691bbeefa719db212d8705b8c5",
    "url": "/stockmoney/json/chip_director.json"
  },
  {
    "revision": "37979fa308d67ee75fe97ff02e0262c9",
    "url": "/stockmoney/json/chip_director1.json"
  },
  {
    "revision": "9245b933efe32254018a0a6e9a6c8613",
    "url": "/stockmoney/json/chip_director1_cols.json"
  },
  {
    "revision": "31448574c0bc818253f990af799be1f9",
    "url": "/stockmoney/json/chip_director3.json"
  },
  {
    "revision": "b856d752ee7572bba69b5bfefbe9e41b",
    "url": "/stockmoney/json/chip_director3_cols.json"
  },
  {
    "revision": "6eb2bafde81a89fe40e6164839641053",
    "url": "/stockmoney/json/chip_director5.json"
  },
  {
    "revision": "825ba91683006403a96e4ead7ebc2e2c",
    "url": "/stockmoney/json/chip_director5_cols.json"
  },
  {
    "revision": "9bbbf6600d4c03482470ae7a8ed48118",
    "url": "/stockmoney/json/chip_director_cols.json"
  },
  {
    "revision": "92df10c22713c4585e03a4e76cecb973",
    "url": "/stockmoney/json/chip_legal.json"
  },
  {
    "revision": "d7e02491040240f9cb7da3e58c364e5d",
    "url": "/stockmoney/json/chip_legal_cols.json"
  },
  {
    "revision": "6d400dbc4b7591d3e39cf5fadd77af87",
    "url": "/stockmoney/json/chip_trust.json"
  },
  {
    "revision": "5fd5d28bcd216b4388792d1f1ca56305",
    "url": "/stockmoney/json/chip_trust_cols.json"
  },
  {
    "revision": "85418a99e3377faa4f63a50f1eb8fe6a",
    "url": "/stockmoney/json/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json/deal_pct_cols.json"
  },
  {
    "revision": "42497310af369f01dee1ae4c4188fdc8",
    "url": "/stockmoney/json/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json/deal_vol_cols.json"
  },
  {
    "revision": "fc35461239f8bb5ce8024a8fa535405b",
    "url": "/stockmoney/json/dividend_cont.json"
  },
  {
    "revision": "e98f37eaa810fd912b66473ef4aec297",
    "url": "/stockmoney/json/dividend_cont_cols.json"
  },
  {
    "revision": "d816e4c7eccafb7477b11025bad0fa43",
    "url": "/stockmoney/json/dividend_stat.json"
  },
  {
    "revision": "f03b67903ab1f6932422317bd284718f",
    "url": "/stockmoney/json/dividend_stat_2015.json"
  },
  {
    "revision": "008c79d526737b517a9a742b04502b20",
    "url": "/stockmoney/json/dividend_stat_2015_cols.json"
  },
  {
    "revision": "67615e1f5be2080ca1b98a110d1aaaa9",
    "url": "/stockmoney/json/dividend_stat_2016.json"
  },
  {
    "revision": "ec5a0a94673998b0bb4a63db93d08f4a",
    "url": "/stockmoney/json/dividend_stat_2016_cols.json"
  },
  {
    "revision": "4c6ca752a53a9ee4c52517a6f9628891",
    "url": "/stockmoney/json/dividend_stat_2017.json"
  },
  {
    "revision": "e37fc91cd72912b24657ed675d9f1c8b",
    "url": "/stockmoney/json/dividend_stat_2017_cols.json"
  },
  {
    "revision": "b5e6a0bac0ec565b9bdc2135a91d25ae",
    "url": "/stockmoney/json/dividend_stat_2018.json"
  },
  {
    "revision": "38050d84b8d337ce366fb397e8e206f7",
    "url": "/stockmoney/json/dividend_stat_2018_cols.json"
  },
  {
    "revision": "f931222e1508ebc131592758103c1f09",
    "url": "/stockmoney/json/dividend_stat_2019.json"
  },
  {
    "revision": "7ec66cdc30aa0d150bc4f797bdc131c4",
    "url": "/stockmoney/json/dividend_stat_2019_cols.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json/dividend_stat_cols.json"
  },
  {
    "revision": "3d9b3f003d6dddbe9788ca9ccd4e691c",
    "url": "/stockmoney/json/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json/dividend_yield_cols.json"
  },
  {
    "revision": "05c0acd9dc7f2b2b5f913ed06dab92c7",
    "url": "/stockmoney/json/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json/export_director_cols.json"
  },
  {
    "revision": "ffb09b6e15cda1ba91265a39d142ceea",
    "url": "/stockmoney/json/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json/export_incomerate_cols.json"
  },
  {
    "revision": "34fb858a2c75f39292591cc02605c09a",
    "url": "/stockmoney/json/export_stockfish.json"
  },
  {
    "revision": "aa76bf1d9931072a3fe9c3e216868eac",
    "url": "/stockmoney/json/export_stockfish_cols.json"
  },
  {
    "revision": "247d5ca4b513ac8cb52b9591ca2dc16a",
    "url": "/stockmoney/json/export_triplerate.json"
  },
  {
    "revision": "a625f25eee5bf1c3f165bc86c455ce79",
    "url": "/stockmoney/json/export_triplerate_cols.json"
  },
  {
    "revision": "f09efcaaffd057186579feb21195e62a",
    "url": "/stockmoney/json/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json/export_water_cols.json"
  },
  {
    "revision": "0262cc49d6dbd53b0713b27b957e0c52",
    "url": "/stockmoney/json/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json/export_yield_cols.json"
  },
  {
    "revision": "0e6e40d2baa7e4324d4d76477380ba7e",
    "url": "/stockmoney/json/my_eps.json"
  },
  {
    "revision": "87b98bb7ccff2628d43fe83db7362e93",
    "url": "/stockmoney/json/my_eps_cols.json"
  },
  {
    "revision": "0715cdec29c867845637aa29e7bcaa32",
    "url": "/stockmoney/json/tech_bch.json"
  },
  {
    "revision": "4ceab57a8c9a6cd7e19f2b097e934cc2",
    "url": "/stockmoney/json/tech_bch_cols.json"
  },
  {
    "revision": "f0e38d8fbafba3085b4ec768e07e03e5",
    "url": "/stockmoney/json/tech_beta.json"
  },
  {
    "revision": "8f09f6a30643cd54d5275425bea06c52",
    "url": "/stockmoney/json/tech_beta_cols.json"
  },
  {
    "revision": "1e9e3cb6037212c15179fba463164d5c",
    "url": "/stockmoney/json/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json/tech_kd_cols.json"
  },
  {
    "revision": "f2797d8f73a3063c2a5fe8c5f1cedc90",
    "url": "/stockmoney/json/tech_ma.json"
  },
  {
    "revision": "0312283011ee3335e1c1333e9725ace1",
    "url": "/stockmoney/json/tech_ma_cols.json"
  },
  {
    "revision": "9a6cbab321a724eca66684ca58d60a21",
    "url": "/stockmoney/json/triplerate_gross.json"
  },
  {
    "revision": "5b107a09351e66b39ae8a49363b2d7d4",
    "url": "/stockmoney/json/triplerate_gross_cols.json"
  },
  {
    "revision": "cdea377c24b6f8f8901f16faf50e02c4",
    "url": "/stockmoney/json/triplerate_net.json"
  },
  {
    "revision": "8cc6bac584df4998524c725b993c40fb",
    "url": "/stockmoney/json/triplerate_net_cols.json"
  },
  {
    "revision": "57deabda66a73348d353509bb0c400a3",
    "url": "/stockmoney/json/triplerate_opp.json"
  },
  {
    "revision": "78b3b65179d647325968e73d9e455496",
    "url": "/stockmoney/json/triplerate_opp_cols.json"
  },
  {
    "revision": "c6baa5d1264f046e39481fbe98809c9c",
    "url": "/stockmoney/json/year_eps.json"
  },
  {
    "revision": "c138f3ed22a8e3b8109fac0077713d1e",
    "url": "/stockmoney/json/year_eps_cols.json"
  },
  {
    "revision": "7ce427dc5d9e07bc50f1b4a59dce3de9",
    "url": "/stockmoney/json/year_roe.json"
  },
  {
    "revision": "e4174661a9b67b63aa5d9f8d82fc1091",
    "url": "/stockmoney/json/year_roe_cols.json"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json_otc/.dummy"
  },
  {
    "revision": "baa7f1b6f29c071d930fbdd7b9e6698f",
    "url": "/stockmoney/json_otc/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json_otc/basic_4season_cols.json"
  },
  {
    "revision": "0b3146e8d0c0cf5763dce84acc4a2314",
    "url": "/stockmoney/json_otc/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json_otc/basic_asset_cols.json"
  },
  {
    "revision": "0038663b3a295db3f6fbc304b42e4020",
    "url": "/stockmoney/json_otc/basic_cash.json"
  },
  {
    "revision": "e35e22824bc77407b54ece5dbd3809b0",
    "url": "/stockmoney/json_otc/basic_cash_cols.json"
  },
  {
    "revision": "9fa564b6b8187e9643b17e09f48e33e4",
    "url": "/stockmoney/json_otc/basic_debt.json"
  },
  {
    "revision": "03154fc22aba11ad894fe252f9814516",
    "url": "/stockmoney/json_otc/basic_debt_cols.json"
  },
  {
    "revision": "952effa2fbbf804ca81e326e4272706a",
    "url": "/stockmoney/json_otc/basic_eps.json"
  },
  {
    "revision": "8bf39d5a2d819ce4153f7c44076c2779",
    "url": "/stockmoney/json_otc/basic_eps_cols.json"
  },
  {
    "revision": "5567c5c6ad876f38d7b7338475f22447",
    "url": "/stockmoney/json_otc/basic_gross.json"
  },
  {
    "revision": "3dc6b18987c8c702b69961a380a4ec81",
    "url": "/stockmoney/json_otc/basic_gross_cols.json"
  },
  {
    "revision": "c6470d43b9a04ba3fdbb9f72c9bd69dd",
    "url": "/stockmoney/json_otc/basic_info.json"
  },
  {
    "revision": "2dbdaa83e5d85419907f0945a8bbb99d",
    "url": "/stockmoney/json_otc/basic_info_cols.json"
  },
  {
    "revision": "9b15dcc2f1f36353099d630c664da666",
    "url": "/stockmoney/json_otc/basic_noi.json"
  },
  {
    "revision": "9f8543eea9b6ea6ffa84ad3d6dbb3249",
    "url": "/stockmoney/json_otc/basic_noi_cols.json"
  },
  {
    "revision": "482caabeec2f973ba6499e18dac074dd",
    "url": "/stockmoney/json_otc/basic_opm.json"
  },
  {
    "revision": "5224d087d8b8cbd980a186dcde0a2e5d",
    "url": "/stockmoney/json_otc/basic_opm_cols.json"
  },
  {
    "revision": "081f49ca8250d917293c661463419cbb",
    "url": "/stockmoney/json_otc/basic_opp.json"
  },
  {
    "revision": "fb785ddc29d43e98f3ce15d467d1abc7",
    "url": "/stockmoney/json_otc/basic_opp_cols.json"
  },
  {
    "revision": "68c4f35766b681368291656b84c71328",
    "url": "/stockmoney/json_otc/basic_roe.json"
  },
  {
    "revision": "c65533a12cbf13b0da8d2b4461c49253",
    "url": "/stockmoney/json_otc/basic_roe_cols.json"
  },
  {
    "revision": "18ee7a0ac3f9fa22750b71909a28135e",
    "url": "/stockmoney/json_otc/basic_rvn.json"
  },
  {
    "revision": "edcf209d7b8c205c23964e9fff04e00f",
    "url": "/stockmoney/json_otc/basic_rvn_cols.json"
  },
  {
    "revision": "804736b91655f487f2b249774aebc5a6",
    "url": "/stockmoney/json_otc/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json_otc/basic_yearw_cols.json"
  },
  {
    "revision": "1a5bb937d5a754bfda06cec95d7e4b75",
    "url": "/stockmoney/json_otc/chip_director.json"
  },
  {
    "revision": "6bb1ba94809f1cc8797fcc4d17242e50",
    "url": "/stockmoney/json_otc/chip_director1.json"
  },
  {
    "revision": "f9146b966dfd77db0815d4d76be2f95a",
    "url": "/stockmoney/json_otc/chip_director1_cols.json"
  },
  {
    "revision": "17b11489199d75f2de75bee47b647a69",
    "url": "/stockmoney/json_otc/chip_director3.json"
  },
  {
    "revision": "2443007c508c710095c9852dcfbcbf90",
    "url": "/stockmoney/json_otc/chip_director3_cols.json"
  },
  {
    "revision": "7a8c0ffdfea69f035991f5954e6fcf51",
    "url": "/stockmoney/json_otc/chip_director5.json"
  },
  {
    "revision": "2899f8c6ca20e9574aeb80f81a52a0d4",
    "url": "/stockmoney/json_otc/chip_director5_cols.json"
  },
  {
    "revision": "51e09fcd7a526fc9bf57bd6136d0da91",
    "url": "/stockmoney/json_otc/chip_director_cols.json"
  },
  {
    "revision": "355a72a552c9ea49a7d3bbf9366872b1",
    "url": "/stockmoney/json_otc/chip_legal.json"
  },
  {
    "revision": "d7e02491040240f9cb7da3e58c364e5d",
    "url": "/stockmoney/json_otc/chip_legal_cols.json"
  },
  {
    "revision": "213b15da8c83293c8de446c514b321f3",
    "url": "/stockmoney/json_otc/chip_trust.json"
  },
  {
    "revision": "fecc398de2cf4696c3d156dd0da35961",
    "url": "/stockmoney/json_otc/chip_trust_cols.json"
  },
  {
    "revision": "bd7c86c2ce18246dc98810c380076192",
    "url": "/stockmoney/json_otc/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json_otc/deal_pct_cols.json"
  },
  {
    "revision": "451a25b9fbf3cdf007f0e3fbac3b49a3",
    "url": "/stockmoney/json_otc/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json_otc/deal_vol_cols.json"
  },
  {
    "revision": "f7a7edc2ffc8c4fdaff57b3739f65f91",
    "url": "/stockmoney/json_otc/dividend_cont.json"
  },
  {
    "revision": "e98f37eaa810fd912b66473ef4aec297",
    "url": "/stockmoney/json_otc/dividend_cont_cols.json"
  },
  {
    "revision": "90fd413f08310d22d2425ed1695f6d86",
    "url": "/stockmoney/json_otc/dividend_stat.json"
  },
  {
    "revision": "202771e9d925c4ff85ad2aec5e77c4de",
    "url": "/stockmoney/json_otc/dividend_stat_2015.json"
  },
  {
    "revision": "35f066a7202cd07a993661003df47e60",
    "url": "/stockmoney/json_otc/dividend_stat_2015_cols.json"
  },
  {
    "revision": "c0cd1f29d68a01b869b19ca254cc0602",
    "url": "/stockmoney/json_otc/dividend_stat_2016.json"
  },
  {
    "revision": "c9ff4726b591ae31ac0d01de3ee835e6",
    "url": "/stockmoney/json_otc/dividend_stat_2016_cols.json"
  },
  {
    "revision": "75b789d2455f882ceca236720d0c2ff0",
    "url": "/stockmoney/json_otc/dividend_stat_2017.json"
  },
  {
    "revision": "1de4f5ace8cafd98e8b0dbf7775d875a",
    "url": "/stockmoney/json_otc/dividend_stat_2017_cols.json"
  },
  {
    "revision": "7d75d51407ae9bbebb762c0908b50f2a",
    "url": "/stockmoney/json_otc/dividend_stat_2018.json"
  },
  {
    "revision": "dc63cd8bd6582abfb555dfa01892c183",
    "url": "/stockmoney/json_otc/dividend_stat_2018_cols.json"
  },
  {
    "revision": "0fa64460b1eb59188c8926b98de88a49",
    "url": "/stockmoney/json_otc/dividend_stat_2019.json"
  },
  {
    "revision": "36fb977815f76ed16183470b9780dc64",
    "url": "/stockmoney/json_otc/dividend_stat_2019_cols.json"
  },
  {
    "revision": "00409984eab5803f4b79487d03e0091c",
    "url": "/stockmoney/json_otc/dividend_stat_cols.json"
  },
  {
    "revision": "577fe9ed713c4865485b2351cec4973c",
    "url": "/stockmoney/json_otc/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json_otc/dividend_yield_cols.json"
  },
  {
    "revision": "d4d71bcf9cb01a12a63d6548c1bb96e3",
    "url": "/stockmoney/json_otc/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json_otc/export_director_cols.json"
  },
  {
    "revision": "282f1b4f7a75b651d38c0adb74ed4aa6",
    "url": "/stockmoney/json_otc/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json_otc/export_incomerate_cols.json"
  },
  {
    "revision": "d4562b410975bd61ffe4c5a90d4840e8",
    "url": "/stockmoney/json_otc/export_stockfish.json"
  },
  {
    "revision": "aa76bf1d9931072a3fe9c3e216868eac",
    "url": "/stockmoney/json_otc/export_stockfish_cols.json"
  },
  {
    "revision": "e85fa0648348d5f35296a3edb087877e",
    "url": "/stockmoney/json_otc/export_triplerate.json"
  },
  {
    "revision": "a625f25eee5bf1c3f165bc86c455ce79",
    "url": "/stockmoney/json_otc/export_triplerate_cols.json"
  },
  {
    "revision": "fa5c25d38423a493bbf851015d8aca02",
    "url": "/stockmoney/json_otc/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json_otc/export_water_cols.json"
  },
  {
    "revision": "4b8a332aef8b0999df3d6165b4c6d205",
    "url": "/stockmoney/json_otc/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json_otc/export_yield_cols.json"
  },
  {
    "revision": "819e70105cffc6a0963ca3243144e48f",
    "url": "/stockmoney/json_otc/my_eps.json"
  },
  {
    "revision": "87b98bb7ccff2628d43fe83db7362e93",
    "url": "/stockmoney/json_otc/my_eps_cols.json"
  },
  {
    "revision": "89af8996e47c52163f7e472556cd9c6f",
    "url": "/stockmoney/json_otc/tech_bch.json"
  },
  {
    "revision": "4ceab57a8c9a6cd7e19f2b097e934cc2",
    "url": "/stockmoney/json_otc/tech_bch_cols.json"
  },
  {
    "revision": "b15ca4246b2a505ae8f078022698d752",
    "url": "/stockmoney/json_otc/tech_beta.json"
  },
  {
    "revision": "4bb937eaf819207728fd1032030d72a4",
    "url": "/stockmoney/json_otc/tech_beta_cols.json"
  },
  {
    "revision": "e5dbdf55518c83c73d0d5ed194d15906",
    "url": "/stockmoney/json_otc/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json_otc/tech_kd_cols.json"
  },
  {
    "revision": "4f825f3f76971b3c4d416a9fa56f4c92",
    "url": "/stockmoney/json_otc/tech_ma.json"
  },
  {
    "revision": "0312283011ee3335e1c1333e9725ace1",
    "url": "/stockmoney/json_otc/tech_ma_cols.json"
  },
  {
    "revision": "929016de3cb90cbc6b787c4e7eb8d75c",
    "url": "/stockmoney/json_otc/triplerate_gross.json"
  },
  {
    "revision": "e64490d877cafd0bf0974a50520dd64b",
    "url": "/stockmoney/json_otc/triplerate_gross_cols.json"
  },
  {
    "revision": "c5f64ea844403bc026dcef09e445ab24",
    "url": "/stockmoney/json_otc/triplerate_net.json"
  },
  {
    "revision": "4a1c917248983b974118d94aff992fbe",
    "url": "/stockmoney/json_otc/triplerate_net_cols.json"
  },
  {
    "revision": "24bbbc6f3c2dd2cfa9454dfa4b5aed05",
    "url": "/stockmoney/json_otc/triplerate_opp.json"
  },
  {
    "revision": "1fc12d566f55e34234d252bd5163e2f0",
    "url": "/stockmoney/json_otc/triplerate_opp_cols.json"
  },
  {
    "revision": "a14e549f44cb21090e512d9c153dd0b5",
    "url": "/stockmoney/json_otc/year_eps.json"
  },
  {
    "revision": "a6f9c36a54376b4a62770c3704464d00",
    "url": "/stockmoney/json_otc/year_eps_cols.json"
  },
  {
    "revision": "ad1ae819b499edcd8b6a0c5504b7ed76",
    "url": "/stockmoney/json_otc/year_roe.json"
  },
  {
    "revision": "b16cea38dc75c242afed123cae000de1",
    "url": "/stockmoney/json_otc/year_roe_cols.json"
  },
  {
    "revision": "b96e0d5a5df171b63ae60164bac0e3af",
    "url": "/stockmoney/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/stockmoney/robots.txt"
  },
  {
    "revision": "5e8571bc813cf0f0f665",
    "url": "/stockmoney/static/css/app.861138e4.css"
  },
  {
    "revision": "00a14ddebf3604813825",
    "url": "/stockmoney/static/css/chunk-vendors.eae4093c.css"
  },
  {
    "revision": "ecb3bfc03db10b6f9d6e23e710d5c953",
    "url": "/stockmoney/static/img/logo.ecb3bfc0.png"
  },
  {
    "revision": "85ce6e4334a2eeb8390e",
    "url": "/stockmoney/static/js/about.3644c617.js"
  },
  {
    "revision": "5e8571bc813cf0f0f665",
    "url": "/stockmoney/static/js/app.39aa3220.js"
  },
  {
    "revision": "00a14ddebf3604813825",
    "url": "/stockmoney/static/js/chunk-vendors.2d8e5b65.js"
  }
]);