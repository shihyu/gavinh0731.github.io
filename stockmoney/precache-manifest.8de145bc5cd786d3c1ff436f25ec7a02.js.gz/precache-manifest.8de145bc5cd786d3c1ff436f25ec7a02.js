self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b64e600da97d58682f99bf763adc7040",
    "url": "/stockmoney/index.html"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json/.dummy"
  },
  {
    "revision": "ca6fcd93ce93d845e1e9656d6ba943df",
    "url": "/stockmoney/json/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json/basic_4season_cols.json"
  },
  {
    "revision": "470d33d525f242bd4d4e387ff8c9b9e5",
    "url": "/stockmoney/json/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json/basic_asset_cols.json"
  },
  {
    "revision": "f35c09183b7262bf9330188ff1e697f8",
    "url": "/stockmoney/json/basic_cash.json"
  },
  {
    "revision": "37f38f1aa6bb8f2f0c147c890d67c151",
    "url": "/stockmoney/json/basic_cash_cols.json"
  },
  {
    "revision": "166959cfee35ed18378eac7dde48b946",
    "url": "/stockmoney/json/basic_debt.json"
  },
  {
    "revision": "a76abb3e0df2e7f44f57581c62262331",
    "url": "/stockmoney/json/basic_debt_cols.json"
  },
  {
    "revision": "c258fcfd53bda282b3e2a56f4570c243",
    "url": "/stockmoney/json/basic_eps.json"
  },
  {
    "revision": "7241ee95818454e8e14b5f8430926288",
    "url": "/stockmoney/json/basic_eps_cols.json"
  },
  {
    "revision": "978313ee5f89c9484fb87fa0dd53ddb7",
    "url": "/stockmoney/json/basic_gross.json"
  },
  {
    "revision": "e8dcdc23836827f1f175afd71720bafe",
    "url": "/stockmoney/json/basic_gross_cols.json"
  },
  {
    "revision": "bdad47302fa6bb05818cf5f722ad18ad",
    "url": "/stockmoney/json/basic_info.json"
  },
  {
    "revision": "4a01d4330b10e31c6048acfe2d9dde98",
    "url": "/stockmoney/json/basic_info_cols.json"
  },
  {
    "revision": "053365a1701bbe9eca989a98caafb9d0",
    "url": "/stockmoney/json/basic_net.json"
  },
  {
    "revision": "2250904d90ff6c9847febb50e7e1297e",
    "url": "/stockmoney/json/basic_net_cols.json"
  },
  {
    "revision": "870311be2cb0d62f8edac8c29bbf70ea",
    "url": "/stockmoney/json/basic_noi.json"
  },
  {
    "revision": "a096112cf53f2747051f0f1b85df69ac",
    "url": "/stockmoney/json/basic_noi_cols.json"
  },
  {
    "revision": "58684ec8e71dfa9f912004844d2a3155",
    "url": "/stockmoney/json/basic_opm.json"
  },
  {
    "revision": "6374075c6593f96920996eb1e94fd4fd",
    "url": "/stockmoney/json/basic_opm_cols.json"
  },
  {
    "revision": "d42e1805e473c40f78d2b24cb1d1e121",
    "url": "/stockmoney/json/basic_opp.json"
  },
  {
    "revision": "ba76da825456203c1cd593ccdfeacc23",
    "url": "/stockmoney/json/basic_opp_cols.json"
  },
  {
    "revision": "4bcb836dbadd2460ca848779cafdfa43",
    "url": "/stockmoney/json/basic_roe.json"
  },
  {
    "revision": "f3c539e26359cda3199ee0f21a2628c9",
    "url": "/stockmoney/json/basic_roe_cols.json"
  },
  {
    "revision": "17cc4c47df6848ceda316a7ec334380d",
    "url": "/stockmoney/json/basic_rvn.json"
  },
  {
    "revision": "726df860aa07852a20559f1f368dd854",
    "url": "/stockmoney/json/basic_rvn_cols.json"
  },
  {
    "revision": "22bb71325570cac36aa097f4f4873d00",
    "url": "/stockmoney/json/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json/basic_yearw_cols.json"
  },
  {
    "revision": "038ededafd034928b052aaacbae45327",
    "url": "/stockmoney/json/chip_borrow.json"
  },
  {
    "revision": "b9d898714914df8c330d1f25fd728bd4",
    "url": "/stockmoney/json/chip_borrow_cols.json"
  },
  {
    "revision": "4bbd791498a8f5475bdf96adc656ce8b",
    "url": "/stockmoney/json/chip_broker.json"
  },
  {
    "revision": "860013a01b77e8e3893ba3260082f3d9",
    "url": "/stockmoney/json/chip_director.json"
  },
  {
    "revision": "68f2de50acf11e902e578029b9d6ccb2",
    "url": "/stockmoney/json/chip_director1.json"
  },
  {
    "revision": "9245b933efe32254018a0a6e9a6c8613",
    "url": "/stockmoney/json/chip_director1_cols.json"
  },
  {
    "revision": "a78362b2e360e2ae977d88d7c8059910",
    "url": "/stockmoney/json/chip_director3.json"
  },
  {
    "revision": "b856d752ee7572bba69b5bfefbe9e41b",
    "url": "/stockmoney/json/chip_director3_cols.json"
  },
  {
    "revision": "4bf5513df918e87602313c78d68eee7d",
    "url": "/stockmoney/json/chip_director5.json"
  },
  {
    "revision": "825ba91683006403a96e4ead7ebc2e2c",
    "url": "/stockmoney/json/chip_director5_cols.json"
  },
  {
    "revision": "9bbbf6600d4c03482470ae7a8ed48118",
    "url": "/stockmoney/json/chip_director_cols.json"
  },
  {
    "revision": "4f1b88906a42f1397c688b737a61a329",
    "url": "/stockmoney/json/chip_foreign.json"
  },
  {
    "revision": "1f66416e66912403af00c4d2366c2741",
    "url": "/stockmoney/json/chip_foreign_cols.json"
  },
  {
    "revision": "c401d30b25d83e91ca4d2936462c10b3",
    "url": "/stockmoney/json/chip_holder.json"
  },
  {
    "revision": "672717b58db691e5c491065fd3720da4",
    "url": "/stockmoney/json/chip_holder_cols.json"
  },
  {
    "revision": "0de326589a19aa01f0b1e85dd7697d13",
    "url": "/stockmoney/json/chip_holder_up.json"
  },
  {
    "revision": "ec1079af0ac2a830213f8b6384b622f7",
    "url": "/stockmoney/json/chip_holder_up_cols.json"
  },
  {
    "revision": "6e25dcecc52313d1fdb3c334ec509dcc",
    "url": "/stockmoney/json/chip_legal.json"
  },
  {
    "revision": "60a82514c04d8b46e234b6c3b7db8a4c",
    "url": "/stockmoney/json/chip_legal_cols.json"
  },
  {
    "revision": "3dbe422484e80bc56a56aefcbf84eb0d",
    "url": "/stockmoney/json/chip_loan.json"
  },
  {
    "revision": "f9dc3e02b8b829e17677de08ed985401",
    "url": "/stockmoney/json/chip_loan_cols.json"
  },
  {
    "revision": "777114114bbf754b5393cd643d0a6efd",
    "url": "/stockmoney/json/chip_trust.json"
  },
  {
    "revision": "0453c094ec1578d8b609550d9e477938",
    "url": "/stockmoney/json/chip_trust_cols.json"
  },
  {
    "revision": "38a75c1ef6a003fb0e28017a7bdec98f",
    "url": "/stockmoney/json/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json/deal_pct_cols.json"
  },
  {
    "revision": "dc8516ae46f08ac36d9c95918a655769",
    "url": "/stockmoney/json/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json/deal_vol_cols.json"
  },
  {
    "revision": "f1d9553621b73064930ac63e2dfa3a9b",
    "url": "/stockmoney/json/dividend_cont.json"
  },
  {
    "revision": "3e8dc99836816cdedc952a126db1fa79",
    "url": "/stockmoney/json/dividend_cont_cols.json"
  },
  {
    "revision": "6cd76a7b9c29d5d7d2a0119a584bf4df",
    "url": "/stockmoney/json/dividend_stat.json"
  },
  {
    "revision": "3ee7d0eb787f5bdfb347fc9b7cabf5d7",
    "url": "/stockmoney/json/dividend_stat_2015.json"
  },
  {
    "revision": "008c79d526737b517a9a742b04502b20",
    "url": "/stockmoney/json/dividend_stat_2015_cols.json"
  },
  {
    "revision": "69f3eb9808a6d8a2ece9b46e96c61fb1",
    "url": "/stockmoney/json/dividend_stat_2016.json"
  },
  {
    "revision": "ec5a0a94673998b0bb4a63db93d08f4a",
    "url": "/stockmoney/json/dividend_stat_2016_cols.json"
  },
  {
    "revision": "18b7de49eee4b5fab9fba84ffe3a43b3",
    "url": "/stockmoney/json/dividend_stat_2017.json"
  },
  {
    "revision": "e37fc91cd72912b24657ed675d9f1c8b",
    "url": "/stockmoney/json/dividend_stat_2017_cols.json"
  },
  {
    "revision": "2cfbcf7284971e1f24c0ad7fe1335f3c",
    "url": "/stockmoney/json/dividend_stat_2018.json"
  },
  {
    "revision": "38050d84b8d337ce366fb397e8e206f7",
    "url": "/stockmoney/json/dividend_stat_2018_cols.json"
  },
  {
    "revision": "9ab82afb7a9bdd38eb2464d60228f1be",
    "url": "/stockmoney/json/dividend_stat_2019.json"
  },
  {
    "revision": "7ec66cdc30aa0d150bc4f797bdc131c4",
    "url": "/stockmoney/json/dividend_stat_2019_cols.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json/dividend_stat_cols.json"
  },
  {
    "revision": "a8520267d1184d53dbe65ae2f7c98c14",
    "url": "/stockmoney/json/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json/dividend_yield_cols.json"
  },
  {
    "revision": "8aaf2a9c82730c5ef9092c59f571d005",
    "url": "/stockmoney/json/dk_dies.json"
  },
  {
    "revision": "0842de8223abec6d0d02135b89168710",
    "url": "/stockmoney/json/dk_dies_cols.json"
  },
  {
    "revision": "09c8659311b2a2c6eb47154112e235e5",
    "url": "/stockmoney/json/export_director.json"
  },
  {
    "revision": "89100efeca7bfb4d95efdab07df62a48",
    "url": "/stockmoney/json/export_director_cols.json"
  },
  {
    "revision": "1f50d0d637bf3789a38ee2444d8b17d9",
    "url": "/stockmoney/json/export_incomerate.json"
  },
  {
    "revision": "8a782513b99c4e31cf07aca4745c38e4",
    "url": "/stockmoney/json/export_incomerate_cols.json"
  },
  {
    "revision": "1a5a12aa08dd05b30eb8da191091cf97",
    "url": "/stockmoney/json/export_stockfish.json"
  },
  {
    "revision": "24c365c317bd950273a6bbe79b14d791",
    "url": "/stockmoney/json/export_stockfish_cols.json"
  },
  {
    "revision": "90b1ac5a2f71b00e8746393f005e3385",
    "url": "/stockmoney/json/export_triplerate.json"
  },
  {
    "revision": "29e0c2731cf0823c503af4580b581346",
    "url": "/stockmoney/json/export_triplerate_cols.json"
  },
  {
    "revision": "323b5383410db63b5080e48363c7afe3",
    "url": "/stockmoney/json/export_water.json"
  },
  {
    "revision": "1743dc326779ed0d0955118930c2fdc1",
    "url": "/stockmoney/json/export_water_cols.json"
  },
  {
    "revision": "41d6fc007029b8bec621881520fabed3",
    "url": "/stockmoney/json/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json/export_yield_cols.json"
  },
  {
    "revision": "b7174550cb8ad85a1e8f7dffd9245b61",
    "url": "/stockmoney/json/my_basic.json"
  },
  {
    "revision": "2f5793f3c37c43bf4332b89384b912a3",
    "url": "/stockmoney/json/my_basic_cols.json"
  },
  {
    "revision": "e0b2240de12de537a9701ec3e91bb7ab",
    "url": "/stockmoney/json/my_chip.json"
  },
  {
    "revision": "9a4e135bd706cb00ba1b6ccd50cde83a",
    "url": "/stockmoney/json/my_chip_cols.json"
  },
  {
    "revision": "fbc4c2fae59f0309ac09d7f09577f5cf",
    "url": "/stockmoney/json/my_eps.json"
  },
  {
    "revision": "87b98bb7ccff2628d43fe83db7362e93",
    "url": "/stockmoney/json/my_eps_cols.json"
  },
  {
    "revision": "f963d9672de47efa3701a8811393d5a5",
    "url": "/stockmoney/json/my_tech.json"
  },
  {
    "revision": "4b39153da2d47c317e3bf1ded1a14cf5",
    "url": "/stockmoney/json/my_tech_cols.json"
  },
  {
    "revision": "67dee4df71212a9605085f709e1c55c9",
    "url": "/stockmoney/json/my_topforce.json"
  },
  {
    "revision": "355b4a8e70cde4a12ff1467395dee2d2",
    "url": "/stockmoney/json/my_topforce_cols.json"
  },
  {
    "revision": "f4a8cae7e09481590344edade2ec6005",
    "url": "/stockmoney/json/price_dpct.json"
  },
  {
    "revision": "111c1063358cf2cce62d1c4c3cf2a601",
    "url": "/stockmoney/json/price_dpct_cols.json"
  },
  {
    "revision": "4de1b382ed591c5a12dd5416ae686a34",
    "url": "/stockmoney/json/price_high.json"
  },
  {
    "revision": "8f986523f915cd6a9dae0cd5f54f5d7f",
    "url": "/stockmoney/json/price_high_cols.json"
  },
  {
    "revision": "d826a2e13b7c185a9bd616d1a33dd80b",
    "url": "/stockmoney/json/price_mpct.json"
  },
  {
    "revision": "19f8b091eacff631ac486f7a35596c56",
    "url": "/stockmoney/json/price_mpct_cols.json"
  },
  {
    "revision": "16859f3f9ff1a366c56fa825626d1299",
    "url": "/stockmoney/json/price_wpct.json"
  },
  {
    "revision": "06e2f207dffd568d93360a54eff1629d",
    "url": "/stockmoney/json/price_wpct_cols.json"
  },
  {
    "revision": "e43558188752eaf22b304db03a0bfdb4",
    "url": "/stockmoney/json/tech_bch.json"
  },
  {
    "revision": "56d227c0fc6a9c5a25f2502cc26148ab",
    "url": "/stockmoney/json/tech_bch_cols.json"
  },
  {
    "revision": "adb3c5b21fa7459dd78d39855833c6ef",
    "url": "/stockmoney/json/tech_beta.json"
  },
  {
    "revision": "8f09f6a30643cd54d5275425bea06c52",
    "url": "/stockmoney/json/tech_beta_cols.json"
  },
  {
    "revision": "9a4c81dd88b696dd89356fbe59049aaa",
    "url": "/stockmoney/json/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json/tech_kd_cols.json"
  },
  {
    "revision": "794bd0ee410fc567940ee45540c19c0c",
    "url": "/stockmoney/json/tech_ma.json"
  },
  {
    "revision": "5c125157702e4475325fc62420500833",
    "url": "/stockmoney/json/tech_ma_cols.json"
  },
  {
    "revision": "954cbb0ca2cc05b6739477632131edd9",
    "url": "/stockmoney/json/tech_makink.json"
  },
  {
    "revision": "f95de82f9706f0ab7fbcddef3c0742ee",
    "url": "/stockmoney/json/tech_makink_cols.json"
  },
  {
    "revision": "ca60aaf9b304218d4d026bb0820db5f0",
    "url": "/stockmoney/json/triplerate_gross.json"
  },
  {
    "revision": "bdea5894fe1ee11fe29b8c1b086f8b14",
    "url": "/stockmoney/json/triplerate_gross_cols.json"
  },
  {
    "revision": "ed52a2d9e558d76ef295eed55ea34315",
    "url": "/stockmoney/json/triplerate_net.json"
  },
  {
    "revision": "131977477f007368864220bd92c5b140",
    "url": "/stockmoney/json/triplerate_net_cols.json"
  },
  {
    "revision": "611d0dc118bc21a80ceb00f96f2f3f8f",
    "url": "/stockmoney/json/triplerate_opp.json"
  },
  {
    "revision": "101ce9c11dafd51f9b77daa28ec5e106",
    "url": "/stockmoney/json/triplerate_opp_cols.json"
  },
  {
    "revision": "0fa29c53e0dafa574f55a0af1b9cc690",
    "url": "/stockmoney/json/year_eps.json"
  },
  {
    "revision": "6d3ef962007b26c6d23c4c5d7a057cc8",
    "url": "/stockmoney/json/year_eps_cols.json"
  },
  {
    "revision": "3636b474481db44e04d5466ddcd1486b",
    "url": "/stockmoney/json/year_roe.json"
  },
  {
    "revision": "07c767a967283717369ecc8e0f0f7d99",
    "url": "/stockmoney/json/year_roe_cols.json"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json_otc/.dummy"
  },
  {
    "revision": "2d187e5c55f463c89514ff1b2133456c",
    "url": "/stockmoney/json_otc/basic_4season.json"
  },
  {
    "revision": "5af8e03d5ac2fd4ca03652dd2b98f6f0",
    "url": "/stockmoney/json_otc/basic_4season_cols.json"
  },
  {
    "revision": "eaceabe40b9696a647c599bf3b66b899",
    "url": "/stockmoney/json_otc/basic_asset.json"
  },
  {
    "revision": "b38212d12f678a74ad6a6565339df931",
    "url": "/stockmoney/json_otc/basic_asset_cols.json"
  },
  {
    "revision": "d09c20915b8d0f2839ae9345af3cda1a",
    "url": "/stockmoney/json_otc/basic_cash.json"
  },
  {
    "revision": "5349424348aa80afa6ae8346580a712f",
    "url": "/stockmoney/json_otc/basic_cash_cols.json"
  },
  {
    "revision": "8a302a5b1f7831dccb71b32e50deb393",
    "url": "/stockmoney/json_otc/basic_debt.json"
  },
  {
    "revision": "149c233a96836df1a575318ec2a1509d",
    "url": "/stockmoney/json_otc/basic_debt_cols.json"
  },
  {
    "revision": "eb796b961c2cfbf209c0ed0bfa29d850",
    "url": "/stockmoney/json_otc/basic_eps.json"
  },
  {
    "revision": "b90192ca9115275349bfea323a394569",
    "url": "/stockmoney/json_otc/basic_eps_cols.json"
  },
  {
    "revision": "d3906b3983d10607f1a26f334a48c1ff",
    "url": "/stockmoney/json_otc/basic_gross.json"
  },
  {
    "revision": "9c4dcfc402f48cb75982fe1d0615a7cb",
    "url": "/stockmoney/json_otc/basic_gross_cols.json"
  },
  {
    "revision": "0d379ecb31ac4141cd566e59db8eb966",
    "url": "/stockmoney/json_otc/basic_info.json"
  },
  {
    "revision": "6f99a8a60e35b64e93e4e87ccbc4e5dd",
    "url": "/stockmoney/json_otc/basic_info_cols.json"
  },
  {
    "revision": "1fe6ada6d1b1389907266b566b229152",
    "url": "/stockmoney/json_otc/basic_net.json"
  },
  {
    "revision": "2ba3ac8050a3d880496ca58318dcb7dc",
    "url": "/stockmoney/json_otc/basic_net_cols.json"
  },
  {
    "revision": "3818a7b2103c40f08b0ca10151048e67",
    "url": "/stockmoney/json_otc/basic_noi.json"
  },
  {
    "revision": "682d8a925174920c27df43d992708acb",
    "url": "/stockmoney/json_otc/basic_noi_cols.json"
  },
  {
    "revision": "8d3ef757b024d77e9473dc437f9b40f5",
    "url": "/stockmoney/json_otc/basic_opm.json"
  },
  {
    "revision": "d25fc77588c0fdc65b8f3e3d57c163e8",
    "url": "/stockmoney/json_otc/basic_opm_cols.json"
  },
  {
    "revision": "50c3ef0fcf6df49e2d1da91dbae9745f",
    "url": "/stockmoney/json_otc/basic_opp.json"
  },
  {
    "revision": "cd5e1981364e5ab21acb32ee82608e2d",
    "url": "/stockmoney/json_otc/basic_opp_cols.json"
  },
  {
    "revision": "881903a2bdcb3016b8ec62a3cc0a3b9d",
    "url": "/stockmoney/json_otc/basic_roe.json"
  },
  {
    "revision": "36692d25edb0355ea92b9c37564e0684",
    "url": "/stockmoney/json_otc/basic_roe_cols.json"
  },
  {
    "revision": "84f4c0edb2c9d01f0f73032076b848e0",
    "url": "/stockmoney/json_otc/basic_rvn.json"
  },
  {
    "revision": "726df860aa07852a20559f1f368dd854",
    "url": "/stockmoney/json_otc/basic_rvn_cols.json"
  },
  {
    "revision": "8a9c3840696a2954f11edad6efe08120",
    "url": "/stockmoney/json_otc/basic_yearw.json"
  },
  {
    "revision": "37afed6bf332938bf457759590f15e20",
    "url": "/stockmoney/json_otc/basic_yearw_cols.json"
  },
  {
    "revision": "d193d84f89f39466bdc8d06ce6b49cc8",
    "url": "/stockmoney/json_otc/chip_borrow.json"
  },
  {
    "revision": "5a8bd57521f8a67e6f158eda3faacf21",
    "url": "/stockmoney/json_otc/chip_borrow_cols.json"
  },
  {
    "revision": "060da2c0d92e7c33bda192b14bd7d60c",
    "url": "/stockmoney/json_otc/chip_director.json"
  },
  {
    "revision": "baba753bff4d7f3bbfb4fd9732f1a889",
    "url": "/stockmoney/json_otc/chip_director1.json"
  },
  {
    "revision": "8e7a0bacff28aa1cf9f5825c7712c937",
    "url": "/stockmoney/json_otc/chip_director1_cols.json"
  },
  {
    "revision": "a205f24628947250f6e16a4f2553fe3e",
    "url": "/stockmoney/json_otc/chip_director3.json"
  },
  {
    "revision": "cb725822bf310830ac86771e76bbf7e5",
    "url": "/stockmoney/json_otc/chip_director3_cols.json"
  },
  {
    "revision": "909a43d252401f525a29fec10ee3f89d",
    "url": "/stockmoney/json_otc/chip_director5.json"
  },
  {
    "revision": "9e1f67c918b55fd9c2153dc91b5ea992",
    "url": "/stockmoney/json_otc/chip_director5_cols.json"
  },
  {
    "revision": "79dce6a98cc61675f28207bb8ee66d68",
    "url": "/stockmoney/json_otc/chip_director_cols.json"
  },
  {
    "revision": "9856b323bea951b51dc6bc9bb63ee057",
    "url": "/stockmoney/json_otc/chip_foreign.json"
  },
  {
    "revision": "e59f62dd4b9a788009bac352d7e91c12",
    "url": "/stockmoney/json_otc/chip_foreign_cols.json"
  },
  {
    "revision": "4a5d8c06ecd0eebd69d55cb863ccacf2",
    "url": "/stockmoney/json_otc/chip_holder.json"
  },
  {
    "revision": "0d80a0b66a710be5c8449613ed1abad2",
    "url": "/stockmoney/json_otc/chip_holder_cols.json"
  },
  {
    "revision": "fac778bcb898051686995cca549951c4",
    "url": "/stockmoney/json_otc/chip_holder_up.json"
  },
  {
    "revision": "ec1079af0ac2a830213f8b6384b622f7",
    "url": "/stockmoney/json_otc/chip_holder_up_cols.json"
  },
  {
    "revision": "b4e56f719fcbf785096fe2b50a90c410",
    "url": "/stockmoney/json_otc/chip_legal.json"
  },
  {
    "revision": "56a5a51151871b1624874a4fe5a82f83",
    "url": "/stockmoney/json_otc/chip_legal_cols.json"
  },
  {
    "revision": "957efba98b2e9006e9550c728aec95bf",
    "url": "/stockmoney/json_otc/chip_loan.json"
  },
  {
    "revision": "ee402593614d4650e99e562d17e63538",
    "url": "/stockmoney/json_otc/chip_loan_cols.json"
  },
  {
    "revision": "1b98125a90fb48f77d62d745389502f3",
    "url": "/stockmoney/json_otc/chip_trust.json"
  },
  {
    "revision": "4466ee075166bd957824b4a6d6c6ddbe",
    "url": "/stockmoney/json_otc/chip_trust_cols.json"
  },
  {
    "revision": "45d94cdd698bcee500cc3774796a9486",
    "url": "/stockmoney/json_otc/deal_pct.json"
  },
  {
    "revision": "6aa4eed51cba9dc1dc746762256d9659",
    "url": "/stockmoney/json_otc/deal_pct_cols.json"
  },
  {
    "revision": "69a8e59de6d79b3b32f4194a0df29ae0",
    "url": "/stockmoney/json_otc/deal_vol.json"
  },
  {
    "revision": "b27cd4bd88359e51326cd3dab8215f69",
    "url": "/stockmoney/json_otc/deal_vol_cols.json"
  },
  {
    "revision": "d676b80edf95beacd56c9821e0a1bfb4",
    "url": "/stockmoney/json_otc/dividend_cont.json"
  },
  {
    "revision": "d770b65af07d9d64a25e81b34c57086f",
    "url": "/stockmoney/json_otc/dividend_cont_cols.json"
  },
  {
    "revision": "3e5d306d93e98dd279e54ab1ca9d2260",
    "url": "/stockmoney/json_otc/dividend_stat.json"
  },
  {
    "revision": "06c725f1195d40b18253776f1647b4ba",
    "url": "/stockmoney/json_otc/dividend_stat_2015.json"
  },
  {
    "revision": "cbec2feb676f6a6aa3b239e88e6d6a2c",
    "url": "/stockmoney/json_otc/dividend_stat_2015_cols.json"
  },
  {
    "revision": "f3bcf09986a2a9abd4908b9bcd17ea74",
    "url": "/stockmoney/json_otc/dividend_stat_2016.json"
  },
  {
    "revision": "6e18d58a36f9fc2a33f01cedfe00600b",
    "url": "/stockmoney/json_otc/dividend_stat_2016_cols.json"
  },
  {
    "revision": "13273eeb837333ce605f811cad48e8da",
    "url": "/stockmoney/json_otc/dividend_stat_2017.json"
  },
  {
    "revision": "297d5aebd0f10fcde9bb1a0e4ac5182e",
    "url": "/stockmoney/json_otc/dividend_stat_2017_cols.json"
  },
  {
    "revision": "14f08351a16e07d042873b61ae6dcb2a",
    "url": "/stockmoney/json_otc/dividend_stat_2018.json"
  },
  {
    "revision": "260b5376813e3734a06dab71d8b9bd8a",
    "url": "/stockmoney/json_otc/dividend_stat_2018_cols.json"
  },
  {
    "revision": "7ed67a09cbb79dacd546d7547d7b6efe",
    "url": "/stockmoney/json_otc/dividend_stat_2019.json"
  },
  {
    "revision": "6050c49dcd02fe1bf54be9c00f3014eb",
    "url": "/stockmoney/json_otc/dividend_stat_2019_cols.json"
  },
  {
    "revision": "9b4c4be9545c11e770cbe8be386f94cb",
    "url": "/stockmoney/json_otc/dividend_stat_cols.json"
  },
  {
    "revision": "cb1c7a76f17c9e1f152038f0061549c7",
    "url": "/stockmoney/json_otc/dividend_yield.json"
  },
  {
    "revision": "ecb2998fde71d849b8992a7b6c4e2e3d",
    "url": "/stockmoney/json_otc/dividend_yield_cols.json"
  },
  {
    "revision": "7070d461fca9f57f911b200dd2fc5bd8",
    "url": "/stockmoney/json_otc/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json_otc/export_director_cols.json"
  },
  {
    "revision": "bf4091968a9416ed62033f7746eeee19",
    "url": "/stockmoney/json_otc/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json_otc/export_incomerate_cols.json"
  },
  {
    "revision": "cd31b8a4e6ae79c8381334b713671557",
    "url": "/stockmoney/json_otc/export_stockfish.json"
  },
  {
    "revision": "192fef50d1b0b739db62b78e28521927",
    "url": "/stockmoney/json_otc/export_stockfish_cols.json"
  },
  {
    "revision": "06644a4d0d24006b9520f689110d209f",
    "url": "/stockmoney/json_otc/export_triplerate.json"
  },
  {
    "revision": "a625f25eee5bf1c3f165bc86c455ce79",
    "url": "/stockmoney/json_otc/export_triplerate_cols.json"
  },
  {
    "revision": "962233c053e6db9fe7b8fc8ba435e819",
    "url": "/stockmoney/json_otc/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json_otc/export_water_cols.json"
  },
  {
    "revision": "c55c440719a695161addc6d1fe124f60",
    "url": "/stockmoney/json_otc/export_yield.json"
  },
  {
    "revision": "49e7cdd201cc3d5a6cd680c3a5aa3c7f",
    "url": "/stockmoney/json_otc/my_basic.json"
  },
  {
    "revision": "12af128c5c8cb61ac4c2042aefe1f0cf",
    "url": "/stockmoney/json_otc/my_eps.json"
  },
  {
    "revision": "ee41870e2a556afa1b4a4cb967744e6d",
    "url": "/stockmoney/json_otc/my_eps_cols.json"
  },
  {
    "revision": "1395aead20977eccac640bbf3995c581",
    "url": "/stockmoney/json_otc/price_dpct.json"
  },
  {
    "revision": "4a8550ef29380c4fa8d8ac437919bf01",
    "url": "/stockmoney/json_otc/price_dpct_cols.json"
  },
  {
    "revision": "1a84cb3797b41ee497e0fe9df78f105a",
    "url": "/stockmoney/json_otc/price_mpct.json"
  },
  {
    "revision": "f49e4c8c592ee192541945e62871c3d3",
    "url": "/stockmoney/json_otc/price_mpct_cols.json"
  },
  {
    "revision": "ed4f7000552aa1169b731b002def646d",
    "url": "/stockmoney/json_otc/price_wpct.json"
  },
  {
    "revision": "5274839ff9361763e75b70bb12e266d6",
    "url": "/stockmoney/json_otc/price_wpct_cols.json"
  },
  {
    "revision": "74b9a929e4b73005398cab04343a3ca7",
    "url": "/stockmoney/json_otc/tech_bch.json"
  },
  {
    "revision": "1f3501a7241684346326f6b20fef29ab",
    "url": "/stockmoney/json_otc/tech_bch_cols.json"
  },
  {
    "revision": "6238c1c5fcdd36fd5a005cb1a374e686",
    "url": "/stockmoney/json_otc/tech_beta.json"
  },
  {
    "revision": "1d1993c61608814513697231793da5ff",
    "url": "/stockmoney/json_otc/tech_beta_cols.json"
  },
  {
    "revision": "3cf9f9f6d61762bde038c50903e6ef33",
    "url": "/stockmoney/json_otc/tech_kd.json"
  },
  {
    "revision": "4f5d6ca8656dd449a555f2892c29746e",
    "url": "/stockmoney/json_otc/tech_kd_cols.json"
  },
  {
    "revision": "fff0b73dd4fcc98c3bc5d915f255f959",
    "url": "/stockmoney/json_otc/triplerate_gross.json"
  },
  {
    "revision": "bdea5894fe1ee11fe29b8c1b086f8b14",
    "url": "/stockmoney/json_otc/triplerate_gross_cols.json"
  },
  {
    "revision": "1ea91449b1443d733cead3b624b18fb1",
    "url": "/stockmoney/json_otc/triplerate_net.json"
  },
  {
    "revision": "131977477f007368864220bd92c5b140",
    "url": "/stockmoney/json_otc/triplerate_net_cols.json"
  },
  {
    "revision": "3ef5f8759fb677e19c103e8791dc6d70",
    "url": "/stockmoney/json_otc/triplerate_opp.json"
  },
  {
    "revision": "101ce9c11dafd51f9b77daa28ec5e106",
    "url": "/stockmoney/json_otc/triplerate_opp_cols.json"
  },
  {
    "revision": "98578f4f95110789fc8bf4f0d8532065",
    "url": "/stockmoney/json_otc/year_eps.json"
  },
  {
    "revision": "6d3ef962007b26c6d23c4c5d7a057cc8",
    "url": "/stockmoney/json_otc/year_eps_cols.json"
  },
  {
    "revision": "24680b66c8986df93a7eae592941a61c",
    "url": "/stockmoney/json_otc/year_roe.json"
  },
  {
    "revision": "07c767a967283717369ecc8e0f0f7d99",
    "url": "/stockmoney/json_otc/year_roe_cols.json"
  },
  {
    "revision": "b96e0d5a5df171b63ae60164bac0e3af",
    "url": "/stockmoney/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/stockmoney/robots.txt"
  },
  {
    "revision": "e722045c445e459bd8fa",
    "url": "/stockmoney/static/css/app.44d1f966.css"
  },
  {
    "revision": "5487711ddcf3f6d565ea",
    "url": "/stockmoney/static/css/chunk-vendors.eae4093c.css"
  },
  {
    "revision": "ecb3bfc03db10b6f9d6e23e710d5c953",
    "url": "/stockmoney/static/img/logo.ecb3bfc0.png"
  },
  {
    "revision": "658800e4ddcdedaaa231",
    "url": "/stockmoney/static/js/about.6cc0e21f.js"
  },
  {
    "revision": "e722045c445e459bd8fa",
    "url": "/stockmoney/static/js/app.0fea75c1.js"
  },
  {
    "revision": "5487711ddcf3f6d565ea",
    "url": "/stockmoney/static/js/chunk-vendors.b4926932.js"
  }
]);