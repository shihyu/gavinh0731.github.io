self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7f242e6a121dcc462d115d623ee97195",
    "url": "/stockmoney/index.html"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json/.dummy"
  },
  {
    "revision": "18901c4add3749ed531ce265e09c0db5",
    "url": "/stockmoney/json/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json/basic_4season_cols.json"
  },
  {
    "revision": "a2105617699b7ecef885bf6f0f3cafcf",
    "url": "/stockmoney/json/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json/basic_asset_cols.json"
  },
  {
    "revision": "ca1f254be7140564a488198f7b3d44d0",
    "url": "/stockmoney/json/basic_cash.json"
  },
  {
    "revision": "f3e734f0abe82e7b1a70a6f8d82f079b",
    "url": "/stockmoney/json/basic_cash_cols.json"
  },
  {
    "revision": "04309966b69ab82a8d35f61f44526fbe",
    "url": "/stockmoney/json/basic_debt.json"
  },
  {
    "revision": "db31eaf879954744578f72e1b42cd33b",
    "url": "/stockmoney/json/basic_debt_cols.json"
  },
  {
    "revision": "2d2f49539e72bfbdc9e87316bc475d94",
    "url": "/stockmoney/json/basic_eps.json"
  },
  {
    "revision": "fc3568005bcbfb93170cc099e25b5171",
    "url": "/stockmoney/json/basic_eps_cols.json"
  },
  {
    "revision": "bc33a984d1a0d45a08e2eeac059e8555",
    "url": "/stockmoney/json/basic_gross.json"
  },
  {
    "revision": "dbd6c4656a96df789b6855233452f791",
    "url": "/stockmoney/json/basic_gross_cols.json"
  },
  {
    "revision": "6f257b184faed1413f4b73940f556343",
    "url": "/stockmoney/json/basic_info.json"
  },
  {
    "revision": "13e705f89a2b21a1bed5151ba2614a3a",
    "url": "/stockmoney/json/basic_info_cols.json"
  },
  {
    "revision": "60467eebe8299fc20d021d186cd4b057",
    "url": "/stockmoney/json/basic_net.json"
  },
  {
    "revision": "5130b782fbf4e14dac96526d74e0d829",
    "url": "/stockmoney/json/basic_net_cols.json"
  },
  {
    "revision": "f251875d4d4390fb56141e56861ca073",
    "url": "/stockmoney/json/basic_noi.json"
  },
  {
    "revision": "b6747dc815e1ddc6984f2dead151ed2d",
    "url": "/stockmoney/json/basic_noi_cols.json"
  },
  {
    "revision": "51b36d2981e141c8019a49a7a2d44760",
    "url": "/stockmoney/json/basic_opm.json"
  },
  {
    "revision": "bae859abfd5997540a5d203671f7adcf",
    "url": "/stockmoney/json/basic_opm_cols.json"
  },
  {
    "revision": "48a549ecb2de7210528ccef0d96909c9",
    "url": "/stockmoney/json/basic_opp.json"
  },
  {
    "revision": "11cab641e3a9e11110e065cce4803cfd",
    "url": "/stockmoney/json/basic_opp_cols.json"
  },
  {
    "revision": "97f481d450603f7528a7c05f12b52844",
    "url": "/stockmoney/json/basic_roe.json"
  },
  {
    "revision": "4701703fd18a070726f3f1b66dcfae27",
    "url": "/stockmoney/json/basic_roe_cols.json"
  },
  {
    "revision": "dec1c0331a151f47360fc244cd58acf0",
    "url": "/stockmoney/json/basic_rvn.json"
  },
  {
    "revision": "46157f87d921730cc7681107bb8119da",
    "url": "/stockmoney/json/basic_rvn_cols.json"
  },
  {
    "revision": "0ab327f0aa34dcefe0e94e1f7e333064",
    "url": "/stockmoney/json/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json/basic_yearw_cols.json"
  },
  {
    "revision": "19cd65e976edb711b702b9f2e2154a58",
    "url": "/stockmoney/json/chip_director.json"
  },
  {
    "revision": "6189411edab92642e3d64f71857c2a7a",
    "url": "/stockmoney/json/chip_director1.json"
  },
  {
    "revision": "9245b933efe32254018a0a6e9a6c8613",
    "url": "/stockmoney/json/chip_director1_cols.json"
  },
  {
    "revision": "d493c549d9c73ec41566540c6219ddf0",
    "url": "/stockmoney/json/chip_director3.json"
  },
  {
    "revision": "b856d752ee7572bba69b5bfefbe9e41b",
    "url": "/stockmoney/json/chip_director3_cols.json"
  },
  {
    "revision": "dca4e8a2850bdf733bb7a1c677a4f8fc",
    "url": "/stockmoney/json/chip_director5.json"
  },
  {
    "revision": "825ba91683006403a96e4ead7ebc2e2c",
    "url": "/stockmoney/json/chip_director5_cols.json"
  },
  {
    "revision": "9bbbf6600d4c03482470ae7a8ed48118",
    "url": "/stockmoney/json/chip_director_cols.json"
  },
  {
    "revision": "a8cc47c4c0ca0c1c12b6ad9a0b2e7d37",
    "url": "/stockmoney/json/chip_legal.json"
  },
  {
    "revision": "d7e02491040240f9cb7da3e58c364e5d",
    "url": "/stockmoney/json/chip_legal_cols.json"
  },
  {
    "revision": "af0c1e9e4a7286aa4124431379216401",
    "url": "/stockmoney/json/chip_trust.json"
  },
  {
    "revision": "5fd5d28bcd216b4388792d1f1ca56305",
    "url": "/stockmoney/json/chip_trust_cols.json"
  },
  {
    "revision": "7956e96b1bb64017c7a0a6a2ce29660b",
    "url": "/stockmoney/json/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json/deal_pct_cols.json"
  },
  {
    "revision": "63aaa6f7dec6ec45fd4cc24492283e66",
    "url": "/stockmoney/json/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json/deal_vol_cols.json"
  },
  {
    "revision": "696a12e333b6beaf9d9fb057a414f9d9",
    "url": "/stockmoney/json/dividend_cont.json"
  },
  {
    "revision": "e98f37eaa810fd912b66473ef4aec297",
    "url": "/stockmoney/json/dividend_cont_cols.json"
  },
  {
    "revision": "e7eac5bf0646990c7bb29db77b7ab44e",
    "url": "/stockmoney/json/dividend_stat.json"
  },
  {
    "revision": "a8e31e8c016e1026401782e34976f4fc",
    "url": "/stockmoney/json/dividend_stat_2015.json"
  },
  {
    "revision": "008c79d526737b517a9a742b04502b20",
    "url": "/stockmoney/json/dividend_stat_2015_cols.json"
  },
  {
    "revision": "36076e9dbf15c2bae4209377fdf1c24b",
    "url": "/stockmoney/json/dividend_stat_2016.json"
  },
  {
    "revision": "ec5a0a94673998b0bb4a63db93d08f4a",
    "url": "/stockmoney/json/dividend_stat_2016_cols.json"
  },
  {
    "revision": "81ab0bfe4dd73d7cfc54d164716590e9",
    "url": "/stockmoney/json/dividend_stat_2017.json"
  },
  {
    "revision": "e37fc91cd72912b24657ed675d9f1c8b",
    "url": "/stockmoney/json/dividend_stat_2017_cols.json"
  },
  {
    "revision": "8afaa100acbd5f18d805e39f2b2edafd",
    "url": "/stockmoney/json/dividend_stat_2018.json"
  },
  {
    "revision": "38050d84b8d337ce366fb397e8e206f7",
    "url": "/stockmoney/json/dividend_stat_2018_cols.json"
  },
  {
    "revision": "71f17a34456068b0be5133203fc933fc",
    "url": "/stockmoney/json/dividend_stat_2019.json"
  },
  {
    "revision": "7ec66cdc30aa0d150bc4f797bdc131c4",
    "url": "/stockmoney/json/dividend_stat_2019_cols.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json/dividend_stat_cols.json"
  },
  {
    "revision": "1639449c520585868236cf5648bcbedc",
    "url": "/stockmoney/json/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json/dividend_yield_cols.json"
  },
  {
    "revision": "cd644aa27ac790badbb887af8bc0d58c",
    "url": "/stockmoney/json/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json/export_director_cols.json"
  },
  {
    "revision": "efa2505f9b3dd06e1bbe4638e37b7819",
    "url": "/stockmoney/json/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json/export_incomerate_cols.json"
  },
  {
    "revision": "7aaa89ec423a7d2048420eab023b6bc4",
    "url": "/stockmoney/json/export_stockfish.json"
  },
  {
    "revision": "aa76bf1d9931072a3fe9c3e216868eac",
    "url": "/stockmoney/json/export_stockfish_cols.json"
  },
  {
    "revision": "8a488e1a492c4238d473e58527fbd417",
    "url": "/stockmoney/json/export_triplerate.json"
  },
  {
    "revision": "2f91c73c151fa60608962f562b8d2bc9",
    "url": "/stockmoney/json/export_triplerate_cols.json"
  },
  {
    "revision": "a1813d8f07978c207504fae5a864b9cf",
    "url": "/stockmoney/json/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json/export_water_cols.json"
  },
  {
    "revision": "7f2e5738289d2adcf0a4a6042f956489",
    "url": "/stockmoney/json/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json/export_yield_cols.json"
  },
  {
    "revision": "6dfe9160da6d173ba2266c4d7c78698b",
    "url": "/stockmoney/json/my_eps.json"
  },
  {
    "revision": "87b98bb7ccff2628d43fe83db7362e93",
    "url": "/stockmoney/json/my_eps_cols.json"
  },
  {
    "revision": "3788caf853f1e271eeaf4b117ceb4066",
    "url": "/stockmoney/json/tech_bch.json"
  },
  {
    "revision": "4ceab57a8c9a6cd7e19f2b097e934cc2",
    "url": "/stockmoney/json/tech_bch_cols.json"
  },
  {
    "revision": "a128494552d470088660defc879114e9",
    "url": "/stockmoney/json/tech_beta.json"
  },
  {
    "revision": "8f09f6a30643cd54d5275425bea06c52",
    "url": "/stockmoney/json/tech_beta_cols.json"
  },
  {
    "revision": "a4b61bff3ddc5ca0217d1eb7cfef3195",
    "url": "/stockmoney/json/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json/tech_kd_cols.json"
  },
  {
    "revision": "34f2c32100b93825599d339b10ebf221",
    "url": "/stockmoney/json/tech_ma.json"
  },
  {
    "revision": "0312283011ee3335e1c1333e9725ace1",
    "url": "/stockmoney/json/tech_ma_cols.json"
  },
  {
    "revision": "3017c01d02e18facbc12290554b35c7f",
    "url": "/stockmoney/json/triplerate_gross.json"
  },
  {
    "revision": "a1f2d79c6fe73dde70bbf435d804f0bc",
    "url": "/stockmoney/json/triplerate_gross_cols.json"
  },
  {
    "revision": "8623ebf4e4986f70d6ea3c146cb25002",
    "url": "/stockmoney/json/triplerate_net.json"
  },
  {
    "revision": "3ae803edeb09a2c3b1e41bdc3547b24b",
    "url": "/stockmoney/json/triplerate_net_cols.json"
  },
  {
    "revision": "c65b6e95a7d379c036afabeb526a10f6",
    "url": "/stockmoney/json/triplerate_opp.json"
  },
  {
    "revision": "cb11feabb57b83c1822e092e37e827c1",
    "url": "/stockmoney/json/triplerate_opp_cols.json"
  },
  {
    "revision": "ba1a624c4b728152e1c67536d0139bb2",
    "url": "/stockmoney/json/year_eps.json"
  },
  {
    "revision": "2b15a07789107906236c747487c05a91",
    "url": "/stockmoney/json/year_eps_cols.json"
  },
  {
    "revision": "bd9b687a43f6e3b3e7ed6f7b800bd896",
    "url": "/stockmoney/json/year_roe.json"
  },
  {
    "revision": "e86e0234f39eb6bd9f80c1e82378efc9",
    "url": "/stockmoney/json/year_roe_cols.json"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json_otc/.dummy"
  },
  {
    "revision": "b195b459fa8b5d52fb1be8aaa54fff42",
    "url": "/stockmoney/json_otc/basic_4season.json"
  },
  {
    "revision": "7818bc239fca153050632c96bc313191",
    "url": "/stockmoney/json_otc/basic_4season_cols.json"
  },
  {
    "revision": "2b1242919bc025b9594e6990cfe3dd6c",
    "url": "/stockmoney/json_otc/basic_asset.json"
  },
  {
    "revision": "1406be9d0913805dd67597aa2dfd1318",
    "url": "/stockmoney/json_otc/basic_asset_cols.json"
  },
  {
    "revision": "f694c2d38e2b20077e69ac782b84ef52",
    "url": "/stockmoney/json_otc/basic_cash.json"
  },
  {
    "revision": "04bb2bec2d19dec0c8161efa72b563b2",
    "url": "/stockmoney/json_otc/basic_cash_cols.json"
  },
  {
    "revision": "5e358603779c28715ce036e67c8a8b16",
    "url": "/stockmoney/json_otc/basic_debt.json"
  },
  {
    "revision": "fd6ab65abcfb8346ed3c5e5c4836b046",
    "url": "/stockmoney/json_otc/basic_debt_cols.json"
  },
  {
    "revision": "a6c2a7d63ec958549458979cc3ab7761",
    "url": "/stockmoney/json_otc/basic_eps.json"
  },
  {
    "revision": "60ffbc561f748b68b077331106cc2129",
    "url": "/stockmoney/json_otc/basic_eps_cols.json"
  },
  {
    "revision": "9420c38a60db24effd450dc8aaf2daed",
    "url": "/stockmoney/json_otc/basic_gross.json"
  },
  {
    "revision": "be61b0743adc6e592c793e52af41b32f",
    "url": "/stockmoney/json_otc/basic_gross_cols.json"
  },
  {
    "revision": "bbea36b7913043144a54f711c0ab27b4",
    "url": "/stockmoney/json_otc/basic_info.json"
  },
  {
    "revision": "1ff499c79686bcf288fd837929f7be08",
    "url": "/stockmoney/json_otc/basic_info_cols.json"
  },
  {
    "revision": "4697ce4192f3b623893ebc9f8a577683",
    "url": "/stockmoney/json_otc/basic_net.json"
  },
  {
    "revision": "2fef3c930562156bc41850cfad48c252",
    "url": "/stockmoney/json_otc/basic_net_cols.json"
  },
  {
    "revision": "18bc17c7e4644c4bd19cc761f087668a",
    "url": "/stockmoney/json_otc/basic_noi.json"
  },
  {
    "revision": "be7054ba8b4283935a39bad345de7515",
    "url": "/stockmoney/json_otc/basic_noi_cols.json"
  },
  {
    "revision": "baf704781b2af71b285594b4e6836462",
    "url": "/stockmoney/json_otc/basic_opm.json"
  },
  {
    "revision": "e1f593ba0adeee52e079ae927b85a2af",
    "url": "/stockmoney/json_otc/basic_opm_cols.json"
  },
  {
    "revision": "1ceddd49336a95f00f919dc8411cce8e",
    "url": "/stockmoney/json_otc/basic_opp.json"
  },
  {
    "revision": "3b41e1ba4c026743ab9110092a6dd466",
    "url": "/stockmoney/json_otc/basic_opp_cols.json"
  },
  {
    "revision": "314b3a6176936e723bd6c0e1f30cc43f",
    "url": "/stockmoney/json_otc/basic_roe.json"
  },
  {
    "revision": "7891e42d828740461173d2b50547166f",
    "url": "/stockmoney/json_otc/basic_roe_cols.json"
  },
  {
    "revision": "b45fbbec2ce88c3b57006792f14e6f3c",
    "url": "/stockmoney/json_otc/basic_rvn.json"
  },
  {
    "revision": "b9222614ba7424a5cbbc90ac35f44a14",
    "url": "/stockmoney/json_otc/basic_rvn_cols.json"
  },
  {
    "revision": "c7aa5aabe3db12a9dcb5de365e373a5e",
    "url": "/stockmoney/json_otc/basic_yearw.json"
  },
  {
    "revision": "482e8105f53432da8afea34dbb07810f",
    "url": "/stockmoney/json_otc/basic_yearw_cols.json"
  },
  {
    "revision": "93c3b3b70c8da1bf942254dfe50c27e0",
    "url": "/stockmoney/json_otc/chip_director.json"
  },
  {
    "revision": "f2a41935ca22ebc68d310bf1b1503f11",
    "url": "/stockmoney/json_otc/chip_director1.json"
  },
  {
    "revision": "e7e646389026bfc58eb752faced38c78",
    "url": "/stockmoney/json_otc/chip_director1_cols.json"
  },
  {
    "revision": "86d5962f63d594ba33bc151f64892924",
    "url": "/stockmoney/json_otc/chip_director3.json"
  },
  {
    "revision": "50881f06c52f548d39e7c0948950bc8f",
    "url": "/stockmoney/json_otc/chip_director3_cols.json"
  },
  {
    "revision": "030e34d698302b6834810856d72b3b1f",
    "url": "/stockmoney/json_otc/chip_director5.json"
  },
  {
    "revision": "ae7fb000b847c9efe4fa567813307ab3",
    "url": "/stockmoney/json_otc/chip_director5_cols.json"
  },
  {
    "revision": "52a39dc629036076936868846109ad85",
    "url": "/stockmoney/json_otc/chip_director_cols.json"
  },
  {
    "revision": "c8b215b0fefabf9a7767c58d3fa7e085",
    "url": "/stockmoney/json_otc/chip_legal.json"
  },
  {
    "revision": "ce3e2e389ce001669d83a166cf13471a",
    "url": "/stockmoney/json_otc/chip_legal_cols.json"
  },
  {
    "revision": "c5ecd329aba846f161ea02bc7582c074",
    "url": "/stockmoney/json_otc/chip_trust.json"
  },
  {
    "revision": "fecc398de2cf4696c3d156dd0da35961",
    "url": "/stockmoney/json_otc/chip_trust_cols.json"
  },
  {
    "revision": "933d463e293d0b48d2383d33f03f54ab",
    "url": "/stockmoney/json_otc/deal_pct.json"
  },
  {
    "revision": "3bbd12d830c3ad1d58f3c36e7981bd1e",
    "url": "/stockmoney/json_otc/deal_pct_cols.json"
  },
  {
    "revision": "3497ec0915b61dee025cf49fe0a0b518",
    "url": "/stockmoney/json_otc/deal_vol.json"
  },
  {
    "revision": "2ec2e6547c02c01d0fa1e761872de4bc",
    "url": "/stockmoney/json_otc/deal_vol_cols.json"
  },
  {
    "revision": "f216e4a32329a3e9a9e29926cbbca294",
    "url": "/stockmoney/json_otc/dividend_cont.json"
  },
  {
    "revision": "c334d619989eafca258b22740b1c347b",
    "url": "/stockmoney/json_otc/dividend_cont_cols.json"
  },
  {
    "revision": "e3d0e7e8d3637ba67c1656982cc2042d",
    "url": "/stockmoney/json_otc/dividend_stat.json"
  },
  {
    "revision": "f1afb5a94faca28123e09f0907a7dbae",
    "url": "/stockmoney/json_otc/dividend_stat_2015.json"
  },
  {
    "revision": "35f066a7202cd07a993661003df47e60",
    "url": "/stockmoney/json_otc/dividend_stat_2015_cols.json"
  },
  {
    "revision": "342a3369efd0e479522d8dc43663781a",
    "url": "/stockmoney/json_otc/dividend_stat_2016.json"
  },
  {
    "revision": "c9ff4726b591ae31ac0d01de3ee835e6",
    "url": "/stockmoney/json_otc/dividend_stat_2016_cols.json"
  },
  {
    "revision": "4dd37d85306da1e42d46622e48f438ed",
    "url": "/stockmoney/json_otc/dividend_stat_2017.json"
  },
  {
    "revision": "1de4f5ace8cafd98e8b0dbf7775d875a",
    "url": "/stockmoney/json_otc/dividend_stat_2017_cols.json"
  },
  {
    "revision": "53ab25cc857a7d8492c119eb0f8943c0",
    "url": "/stockmoney/json_otc/dividend_stat_2018.json"
  },
  {
    "revision": "dc63cd8bd6582abfb555dfa01892c183",
    "url": "/stockmoney/json_otc/dividend_stat_2018_cols.json"
  },
  {
    "revision": "d252f654416de168cf630ea9bfc97c58",
    "url": "/stockmoney/json_otc/dividend_stat_2019.json"
  },
  {
    "revision": "36fb977815f76ed16183470b9780dc64",
    "url": "/stockmoney/json_otc/dividend_stat_2019_cols.json"
  },
  {
    "revision": "0dc642fd410871db78b0deacbebee97a",
    "url": "/stockmoney/json_otc/dividend_stat_cols.json"
  },
  {
    "revision": "62187f125639db600e444d132ce1ef5c",
    "url": "/stockmoney/json_otc/dividend_yield.json"
  },
  {
    "revision": "272db52b89212f59145ffc9078a941bf",
    "url": "/stockmoney/json_otc/dividend_yield_cols.json"
  },
  {
    "revision": "59ee6accb00cb5043abcf0f3270991aa",
    "url": "/stockmoney/json_otc/export_director.json"
  },
  {
    "revision": "68e66348dff68fa2853def9f82468b4a",
    "url": "/stockmoney/json_otc/export_incomerate.json"
  },
  {
    "revision": "afd47797ab277ab46d122ae2d759c72b",
    "url": "/stockmoney/json_otc/export_stockfish.json"
  },
  {
    "revision": "d66a5594fc65924162cc91cd58299551",
    "url": "/stockmoney/json_otc/export_triplerate.json"
  },
  {
    "revision": "c561d664e842df9d4496b9349ed2e2de",
    "url": "/stockmoney/json_otc/export_water.json"
  },
  {
    "revision": "ec2d4c0c4a8417cc00341d00996b39a3",
    "url": "/stockmoney/json_otc/export_yield.json"
  },
  {
    "revision": "ccbe0b28915b78f4f5662604533d3f6c",
    "url": "/stockmoney/json_otc/my_eps.json"
  },
  {
    "revision": "03188534439e1c0e2b1b4a372be464fb",
    "url": "/stockmoney/json_otc/tech_bch.json"
  },
  {
    "revision": "b0486c8c236d548d9347a8fe4e60ae80",
    "url": "/stockmoney/json_otc/tech_bch_cols.json"
  },
  {
    "revision": "e478e5e5d3aa4ca0cc21ad6fde6ffdd3",
    "url": "/stockmoney/json_otc/tech_beta.json"
  },
  {
    "revision": "4bb937eaf819207728fd1032030d72a4",
    "url": "/stockmoney/json_otc/tech_beta_cols.json"
  },
  {
    "revision": "2d06bdb5cbbcb79d5a1d1f2c4e7ab7ac",
    "url": "/stockmoney/json_otc/tech_kd.json"
  },
  {
    "revision": "86ce12d8b638247a59212136bf8e2428",
    "url": "/stockmoney/json_otc/tech_kd_cols.json"
  },
  {
    "revision": "da29cc74550742b914a9077c9905c39a",
    "url": "/stockmoney/json_otc/tech_ma.json"
  },
  {
    "revision": "440e90cad9ff96c84cb4ee2d503f4c3c",
    "url": "/stockmoney/json_otc/tech_ma_cols.json"
  },
  {
    "revision": "5e502259d430a038c32e6a1650ce920c",
    "url": "/stockmoney/json_otc/triplerate_gross.json"
  },
  {
    "revision": "a6c2b21a55d4baebf600dc0a7e2d8109",
    "url": "/stockmoney/json_otc/triplerate_gross_cols.json"
  },
  {
    "revision": "5fd734009e5aa953de0bbeb46ae75f95",
    "url": "/stockmoney/json_otc/triplerate_net.json"
  },
  {
    "revision": "6cdfb4a24f2b08b4ab57e60aca53b700",
    "url": "/stockmoney/json_otc/triplerate_net_cols.json"
  },
  {
    "revision": "93f64f387f953b0d855545ba27026f89",
    "url": "/stockmoney/json_otc/triplerate_opp.json"
  },
  {
    "revision": "42badb336e1e8dd20952f85e472303a1",
    "url": "/stockmoney/json_otc/triplerate_opp_cols.json"
  },
  {
    "revision": "189071de3ac4969ac1f51672fe19e924",
    "url": "/stockmoney/json_otc/year_eps.json"
  },
  {
    "revision": "dfd54930980a6cf10269364fc85b639c",
    "url": "/stockmoney/json_otc/year_eps_cols.json"
  },
  {
    "revision": "bc126145722ce4b153846d51eba3b495",
    "url": "/stockmoney/json_otc/year_roe.json"
  },
  {
    "revision": "6ce1401d8ba383d8a183c19db3162928",
    "url": "/stockmoney/json_otc/year_roe_cols.json"
  },
  {
    "revision": "b96e0d5a5df171b63ae60164bac0e3af",
    "url": "/stockmoney/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/stockmoney/robots.txt"
  },
  {
    "revision": "6ab78fd7a3db857cf91e",
    "url": "/stockmoney/static/css/app.209721b9.css"
  },
  {
    "revision": "0b67f49ecef966899a76",
    "url": "/stockmoney/static/css/chunk-vendors.eae4093c.css"
  },
  {
    "revision": "ecb3bfc03db10b6f9d6e23e710d5c953",
    "url": "/stockmoney/static/img/logo.ecb3bfc0.png"
  },
  {
    "revision": "658800e4ddcdedaaa231",
    "url": "/stockmoney/static/js/about.6cc0e21f.js"
  },
  {
    "revision": "6ab78fd7a3db857cf91e",
    "url": "/stockmoney/static/js/app.406353d5.js"
  },
  {
    "revision": "0b67f49ecef966899a76",
    "url": "/stockmoney/static/js/chunk-vendors.e64b16c7.js"
  }
]);