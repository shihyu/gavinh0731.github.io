self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9cc4c11d06d01e51eddb298fcca20f23",
    "url": "/stockmoney/index.html"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json/.dummy"
  },
  {
    "revision": "05057c35086989901a8eef09e83eed81",
    "url": "/stockmoney/json/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json/basic_4season_cols.json"
  },
  {
    "revision": "0e8735bf9f6aa73dc38a6f51e2163ac1",
    "url": "/stockmoney/json/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json/basic_asset_cols.json"
  },
  {
    "revision": "07c9e36292f7c94cfa1fa54d356ef706",
    "url": "/stockmoney/json/basic_cash.json"
  },
  {
    "revision": "053548bac9e58be86426b78769dd3d15",
    "url": "/stockmoney/json/basic_cash_cols.json"
  },
  {
    "revision": "0fd54286ac25679b98e0c57d96561fbc",
    "url": "/stockmoney/json/basic_debt.json"
  },
  {
    "revision": "7eb498ae3e30e6352004b0880b10d9a9",
    "url": "/stockmoney/json/basic_debt_cols.json"
  },
  {
    "revision": "d5ff1c6f4cccc11b1542c8779028ed99",
    "url": "/stockmoney/json/basic_eps.json"
  },
  {
    "revision": "459c433847ba066c27d472f8dbf8542d",
    "url": "/stockmoney/json/basic_eps_cols.json"
  },
  {
    "revision": "22f16bdc9b0bfd114c43262bfe96f7c0",
    "url": "/stockmoney/json/basic_gross.json"
  },
  {
    "revision": "97f5651ca75998bf63291a7a25bf164d",
    "url": "/stockmoney/json/basic_gross_cols.json"
  },
  {
    "revision": "fdb13322220c880572417ed756ba98e2",
    "url": "/stockmoney/json/basic_info.json"
  },
  {
    "revision": "2dbdaa83e5d85419907f0945a8bbb99d",
    "url": "/stockmoney/json/basic_info_cols.json"
  },
  {
    "revision": "50a9cc9f6375854f32202453a34d29d2",
    "url": "/stockmoney/json/basic_noi.json"
  },
  {
    "revision": "2d214d9e84ecbcaefb5328042d9ec25c",
    "url": "/stockmoney/json/basic_noi_cols.json"
  },
  {
    "revision": "e50471165964163b56d6ac7583dd1fb6",
    "url": "/stockmoney/json/basic_opm.json"
  },
  {
    "revision": "7b1776516f489f8dd02b32dfc2199990",
    "url": "/stockmoney/json/basic_opm_cols.json"
  },
  {
    "revision": "b1a1b4a32a7c5e9307f4d7ae86e5f514",
    "url": "/stockmoney/json/basic_opp.json"
  },
  {
    "revision": "830b6965e011450f38d0b58cdd6f3560",
    "url": "/stockmoney/json/basic_opp_cols.json"
  },
  {
    "revision": "64193c3f92dc74e32947ec22fc056640",
    "url": "/stockmoney/json/basic_roe.json"
  },
  {
    "revision": "bdc8388c889e97636ffd242dcc42f81e",
    "url": "/stockmoney/json/basic_roe_cols.json"
  },
  {
    "revision": "2badaa4977278b7703577ab4a8b01cf3",
    "url": "/stockmoney/json/basic_rvn.json"
  },
  {
    "revision": "7d24e47ca9cb3056b704368cd474ee58",
    "url": "/stockmoney/json/basic_rvn_cols.json"
  },
  {
    "revision": "2024880bc54e216ab53eec509a8687b9",
    "url": "/stockmoney/json/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json/basic_yearw_cols.json"
  },
  {
    "revision": "611b1ca22e5201a7cbf6f9923730cbdf",
    "url": "/stockmoney/json/chip_director.json"
  },
  {
    "revision": "043c5efdfe0e99b58b06f049bc029857",
    "url": "/stockmoney/json/chip_director1.json"
  },
  {
    "revision": "9245b933efe32254018a0a6e9a6c8613",
    "url": "/stockmoney/json/chip_director1_cols.json"
  },
  {
    "revision": "6add84ea592333c0a4441bcd8ad8e729",
    "url": "/stockmoney/json/chip_director3.json"
  },
  {
    "revision": "b856d752ee7572bba69b5bfefbe9e41b",
    "url": "/stockmoney/json/chip_director3_cols.json"
  },
  {
    "revision": "1aead9a2ad847d823bbb5e641cd6777b",
    "url": "/stockmoney/json/chip_director5.json"
  },
  {
    "revision": "825ba91683006403a96e4ead7ebc2e2c",
    "url": "/stockmoney/json/chip_director5_cols.json"
  },
  {
    "revision": "9bbbf6600d4c03482470ae7a8ed48118",
    "url": "/stockmoney/json/chip_director_cols.json"
  },
  {
    "revision": "dacbf081f612b315f5bbd1ea3499506f",
    "url": "/stockmoney/json/chip_legal.json"
  },
  {
    "revision": "d7e02491040240f9cb7da3e58c364e5d",
    "url": "/stockmoney/json/chip_legal_cols.json"
  },
  {
    "revision": "a8b5dbf377c931213041644f58344a65",
    "url": "/stockmoney/json/chip_trust.json"
  },
  {
    "revision": "5fd5d28bcd216b4388792d1f1ca56305",
    "url": "/stockmoney/json/chip_trust_cols.json"
  },
  {
    "revision": "912fb51d6af18fe19016b990c1a1cb43",
    "url": "/stockmoney/json/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json/deal_pct_cols.json"
  },
  {
    "revision": "36b8b825224aa014d8bf5bae1c9e8c51",
    "url": "/stockmoney/json/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json/deal_vol_cols.json"
  },
  {
    "revision": "4c11d5fac2eb214dc236f63a297fc243",
    "url": "/stockmoney/json/dividend_cont.json"
  },
  {
    "revision": "e98f37eaa810fd912b66473ef4aec297",
    "url": "/stockmoney/json/dividend_cont_cols.json"
  },
  {
    "revision": "cf9e10c8fbffae052fa5b61860940708",
    "url": "/stockmoney/json/dividend_stat.json"
  },
  {
    "revision": "7b46c4ee9490fee469b1dd6e9cead7ea",
    "url": "/stockmoney/json/dividend_stat_2015.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2015_cols.json"
  },
  {
    "revision": "9dc9e7653404fe35351614cc426e0a05",
    "url": "/stockmoney/json/dividend_stat_2016.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2016_cols.json"
  },
  {
    "revision": "64a07dcec42af1d887d8facc88dd1f17",
    "url": "/stockmoney/json/dividend_stat_2017.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2017_cols.json"
  },
  {
    "revision": "c667fbd731d2df0a7b2e8ec4675446d9",
    "url": "/stockmoney/json/dividend_stat_2018.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2018_cols.json"
  },
  {
    "revision": "db776db8b9a98d7176be931a5da92dee",
    "url": "/stockmoney/json/dividend_stat_2019.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json/dividend_stat_2019_cols.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json/dividend_stat_cols.json"
  },
  {
    "revision": "ecd6b53995ddde12c8a0b91091a6440f",
    "url": "/stockmoney/json/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json/dividend_yield_cols.json"
  },
  {
    "revision": "095d7dbe1545944f90c8f699fd60d663",
    "url": "/stockmoney/json/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json/export_director_cols.json"
  },
  {
    "revision": "23ba027c2010a8f974c7144473f6a11f",
    "url": "/stockmoney/json/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json/export_incomerate_cols.json"
  },
  {
    "revision": "582d4bf2ebe2c05c8e16cead92f70bd1",
    "url": "/stockmoney/json/export_stockfish.json"
  },
  {
    "revision": "aa76bf1d9931072a3fe9c3e216868eac",
    "url": "/stockmoney/json/export_stockfish_cols.json"
  },
  {
    "revision": "35dcbf5cc2170f507edffeea327d493f",
    "url": "/stockmoney/json/export_triplerate.json"
  },
  {
    "revision": "a625f25eee5bf1c3f165bc86c455ce79",
    "url": "/stockmoney/json/export_triplerate_cols.json"
  },
  {
    "revision": "7404401cd5e4d98859e42a84d9d26fa0",
    "url": "/stockmoney/json/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json/export_water_cols.json"
  },
  {
    "revision": "a1741278e4f00c9866de6db03b0f674d",
    "url": "/stockmoney/json/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json/export_yield_cols.json"
  },
  {
    "revision": "f8ef0ceaadbf81ed5f034380bc8c249f",
    "url": "/stockmoney/json/my_eps.json"
  },
  {
    "revision": "87b98bb7ccff2628d43fe83db7362e93",
    "url": "/stockmoney/json/my_eps_cols.json"
  },
  {
    "revision": "99cc494522cf6ae647e51afbfbabbcb9",
    "url": "/stockmoney/json/tech_bch.json"
  },
  {
    "revision": "4ceab57a8c9a6cd7e19f2b097e934cc2",
    "url": "/stockmoney/json/tech_bch_cols.json"
  },
  {
    "revision": "05efc69171875d452c409fa800ef424e",
    "url": "/stockmoney/json/tech_beta.json"
  },
  {
    "revision": "8f09f6a30643cd54d5275425bea06c52",
    "url": "/stockmoney/json/tech_beta_cols.json"
  },
  {
    "revision": "c5d445a1f666e494340907e2fd42336f",
    "url": "/stockmoney/json/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json/tech_kd_cols.json"
  },
  {
    "revision": "1797eaf31e61b8e9a9f05867666759c5",
    "url": "/stockmoney/json/tech_ma.json"
  },
  {
    "revision": "0312283011ee3335e1c1333e9725ace1",
    "url": "/stockmoney/json/tech_ma_cols.json"
  },
  {
    "revision": "70ac67465d162af736336ae5b3be9601",
    "url": "/stockmoney/json/triplerate_gross.json"
  },
  {
    "revision": "d2b79335602da31a017595cf423cbb22",
    "url": "/stockmoney/json/triplerate_gross_cols.json"
  },
  {
    "revision": "6ddee21cde4709b10c4a3d57fc70946b",
    "url": "/stockmoney/json/triplerate_net.json"
  },
  {
    "revision": "2638ba811e1d34daa027d4fc646a6a7c",
    "url": "/stockmoney/json/triplerate_net_cols.json"
  },
  {
    "revision": "9b7480157d3b973303f8369e5317b8be",
    "url": "/stockmoney/json/triplerate_opp.json"
  },
  {
    "revision": "b46e0750be2c335a3f7fef2bf0415a3e",
    "url": "/stockmoney/json/triplerate_opp_cols.json"
  },
  {
    "revision": "d1396240247702f8859b0f059ed62f4d",
    "url": "/stockmoney/json/year_eps.json"
  },
  {
    "revision": "3d9a870404ac5e92a8bff33f14ccae58",
    "url": "/stockmoney/json/year_eps_cols.json"
  },
  {
    "revision": "9d8c8fccd9e337cafba2549a16623a9d",
    "url": "/stockmoney/json/year_roe.json"
  },
  {
    "revision": "2bf87cb246ceba3a7cd2ea5f067503f4",
    "url": "/stockmoney/json/year_roe_cols.json"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json_otc/.dummy"
  },
  {
    "revision": "bfadd0b9669a1ec367e44639400f6fc9",
    "url": "/stockmoney/json_otc/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json_otc/basic_4season_cols.json"
  },
  {
    "revision": "ab03ca4e4943a68d4dcf3e8117b98c70",
    "url": "/stockmoney/json_otc/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json_otc/basic_asset_cols.json"
  },
  {
    "revision": "c36d0b494d47471c28a2eff145444bcd",
    "url": "/stockmoney/json_otc/basic_cash.json"
  },
  {
    "revision": "49f47582123efd15a3a986bd7b5e7f8b",
    "url": "/stockmoney/json_otc/basic_cash_cols.json"
  },
  {
    "revision": "c78ba3824e40370de1d31b9c4124df3e",
    "url": "/stockmoney/json_otc/basic_debt.json"
  },
  {
    "revision": "6803f738d8fc309353416200de548281",
    "url": "/stockmoney/json_otc/basic_debt_cols.json"
  },
  {
    "revision": "a506f7e725997add70ef6117d4033bea",
    "url": "/stockmoney/json_otc/basic_eps.json"
  },
  {
    "revision": "6d401652a5f55fdbb84870b1f351b999",
    "url": "/stockmoney/json_otc/basic_eps_cols.json"
  },
  {
    "revision": "31caaadd9ed9aa16935feda01e8467e3",
    "url": "/stockmoney/json_otc/basic_gross.json"
  },
  {
    "revision": "3804d8049e37f6b1aa51a28f8fa12812",
    "url": "/stockmoney/json_otc/basic_gross_cols.json"
  },
  {
    "revision": "00561dac3c56987b0279907347accef9",
    "url": "/stockmoney/json_otc/basic_info.json"
  },
  {
    "revision": "2dbdaa83e5d85419907f0945a8bbb99d",
    "url": "/stockmoney/json_otc/basic_info_cols.json"
  },
  {
    "revision": "c7632457d6c8ef924692843d4db6a1c7",
    "url": "/stockmoney/json_otc/basic_noi.json"
  },
  {
    "revision": "802a70796bab7045f0fd5674b32498ab",
    "url": "/stockmoney/json_otc/basic_noi_cols.json"
  },
  {
    "revision": "277916cf8b3a07d16f92678bc27a9bef",
    "url": "/stockmoney/json_otc/basic_opm.json"
  },
  {
    "revision": "6ba5a5484a50b21dfc313d320718a74c",
    "url": "/stockmoney/json_otc/basic_opm_cols.json"
  },
  {
    "revision": "093257742088a943e7c532eb7d06a660",
    "url": "/stockmoney/json_otc/basic_opp.json"
  },
  {
    "revision": "d52828176d46c4d0c373ce9be6bc8f3f",
    "url": "/stockmoney/json_otc/basic_opp_cols.json"
  },
  {
    "revision": "e4432bfcf773c23e7543693d9cfa2a06",
    "url": "/stockmoney/json_otc/basic_roe.json"
  },
  {
    "revision": "9b84462db2024296201057718ccab94a",
    "url": "/stockmoney/json_otc/basic_roe_cols.json"
  },
  {
    "revision": "cf635c4ae287c2063fa1192fabd26825",
    "url": "/stockmoney/json_otc/basic_rvn.json"
  },
  {
    "revision": "a745a2ef2960952afc150d1f1a208ddf",
    "url": "/stockmoney/json_otc/basic_rvn_cols.json"
  },
  {
    "revision": "67ab7dae38680eecdfa175b9a107b36f",
    "url": "/stockmoney/json_otc/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json_otc/basic_yearw_cols.json"
  },
  {
    "revision": "ce3b39486f5c24a03a43ea0039118bd9",
    "url": "/stockmoney/json_otc/chip_director.json"
  },
  {
    "revision": "7af3e1c4075271063d81c8d470d6a52e",
    "url": "/stockmoney/json_otc/chip_director1.json"
  },
  {
    "revision": "f9146b966dfd77db0815d4d76be2f95a",
    "url": "/stockmoney/json_otc/chip_director1_cols.json"
  },
  {
    "revision": "e4e09776236a197abfe682195751b7f3",
    "url": "/stockmoney/json_otc/chip_director3.json"
  },
  {
    "revision": "2443007c508c710095c9852dcfbcbf90",
    "url": "/stockmoney/json_otc/chip_director3_cols.json"
  },
  {
    "revision": "a0532047ce866ac640c00a584492c4d0",
    "url": "/stockmoney/json_otc/chip_director5.json"
  },
  {
    "revision": "2899f8c6ca20e9574aeb80f81a52a0d4",
    "url": "/stockmoney/json_otc/chip_director5_cols.json"
  },
  {
    "revision": "51e09fcd7a526fc9bf57bd6136d0da91",
    "url": "/stockmoney/json_otc/chip_director_cols.json"
  },
  {
    "revision": "2db8d6c5ed510f9eae5efc41a6315f2e",
    "url": "/stockmoney/json_otc/chip_legal.json"
  },
  {
    "revision": "d7e02491040240f9cb7da3e58c364e5d",
    "url": "/stockmoney/json_otc/chip_legal_cols.json"
  },
  {
    "revision": "65ceb2f4be49c57acee8125b89676618",
    "url": "/stockmoney/json_otc/chip_trust.json"
  },
  {
    "revision": "fecc398de2cf4696c3d156dd0da35961",
    "url": "/stockmoney/json_otc/chip_trust_cols.json"
  },
  {
    "revision": "2ef28cb70318aa631ae5b9276a6aae60",
    "url": "/stockmoney/json_otc/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json_otc/deal_pct_cols.json"
  },
  {
    "revision": "8c556b876d48fcd95a6e72dc5952fc52",
    "url": "/stockmoney/json_otc/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json_otc/deal_vol_cols.json"
  },
  {
    "revision": "b8d711f298c5a954df91d9dca13b2a43",
    "url": "/stockmoney/json_otc/dividend_cont.json"
  },
  {
    "revision": "e98f37eaa810fd912b66473ef4aec297",
    "url": "/stockmoney/json_otc/dividend_cont_cols.json"
  },
  {
    "revision": "c17123a8ad26fe663f861b100b78b21f",
    "url": "/stockmoney/json_otc/dividend_stat.json"
  },
  {
    "revision": "21c6d862c4542447ccccfd08ff51bce9",
    "url": "/stockmoney/json_otc/dividend_stat_2015.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2015_cols.json"
  },
  {
    "revision": "d6c9d1101ef9f25794f0467f67dd9a17",
    "url": "/stockmoney/json_otc/dividend_stat_2016.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2016_cols.json"
  },
  {
    "revision": "531e4b866bc78364065f34d415dc117f",
    "url": "/stockmoney/json_otc/dividend_stat_2017.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2017_cols.json"
  },
  {
    "revision": "96fb1225ec93dfa7421a9d369ee8de90",
    "url": "/stockmoney/json_otc/dividend_stat_2018.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2018_cols.json"
  },
  {
    "revision": "2c47c220e75f515787167b98f504246d",
    "url": "/stockmoney/json_otc/dividend_stat_2019.json"
  },
  {
    "revision": "4305292348159384bdee05a10a8e0a79",
    "url": "/stockmoney/json_otc/dividend_stat_2019_cols.json"
  },
  {
    "revision": "00409984eab5803f4b79487d03e0091c",
    "url": "/stockmoney/json_otc/dividend_stat_cols.json"
  },
  {
    "revision": "612e068949f404871066a364606e8488",
    "url": "/stockmoney/json_otc/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json_otc/dividend_yield_cols.json"
  },
  {
    "revision": "8f6207eb4801c6a072798f91d26fa5e0",
    "url": "/stockmoney/json_otc/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json_otc/export_director_cols.json"
  },
  {
    "revision": "9715c6f612bd7ff33c036b7af6c4e163",
    "url": "/stockmoney/json_otc/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json_otc/export_incomerate_cols.json"
  },
  {
    "revision": "b4ba3e0cca3d4169b6cda2e782b52958",
    "url": "/stockmoney/json_otc/export_stockfish.json"
  },
  {
    "revision": "aa76bf1d9931072a3fe9c3e216868eac",
    "url": "/stockmoney/json_otc/export_stockfish_cols.json"
  },
  {
    "revision": "950e9ed04c8f4c8c5d274709e239952a",
    "url": "/stockmoney/json_otc/export_triplerate.json"
  },
  {
    "revision": "a625f25eee5bf1c3f165bc86c455ce79",
    "url": "/stockmoney/json_otc/export_triplerate_cols.json"
  },
  {
    "revision": "45e6aedae5609e61ec684ece99258c1a",
    "url": "/stockmoney/json_otc/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json_otc/export_water_cols.json"
  },
  {
    "revision": "495167dc4674a4ac6d6d8d5038dbef97",
    "url": "/stockmoney/json_otc/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json_otc/export_yield_cols.json"
  },
  {
    "revision": "5490c7412733503940ff48360cf81fbf",
    "url": "/stockmoney/json_otc/my_eps.json"
  },
  {
    "revision": "87b98bb7ccff2628d43fe83db7362e93",
    "url": "/stockmoney/json_otc/my_eps_cols.json"
  },
  {
    "revision": "a67db3ab05b7bbf2d1b69fbbfbf05de6",
    "url": "/stockmoney/json_otc/tech_bch.json"
  },
  {
    "revision": "4ceab57a8c9a6cd7e19f2b097e934cc2",
    "url": "/stockmoney/json_otc/tech_bch_cols.json"
  },
  {
    "revision": "c76d7709147352cc27605bd94c8f8323",
    "url": "/stockmoney/json_otc/tech_beta.json"
  },
  {
    "revision": "4bb937eaf819207728fd1032030d72a4",
    "url": "/stockmoney/json_otc/tech_beta_cols.json"
  },
  {
    "revision": "a967da2602a874cd9197fd1008f6f9c5",
    "url": "/stockmoney/json_otc/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json_otc/tech_kd_cols.json"
  },
  {
    "revision": "c427f3dedde3ec1987425ba5557d0bd3",
    "url": "/stockmoney/json_otc/tech_ma.json"
  },
  {
    "revision": "0312283011ee3335e1c1333e9725ace1",
    "url": "/stockmoney/json_otc/tech_ma_cols.json"
  },
  {
    "revision": "d17f8d4be176bbb5e6053440e81f95c0",
    "url": "/stockmoney/json_otc/triplerate_gross.json"
  },
  {
    "revision": "4bcfdf5fe95a850c0c6a91acfae5861b",
    "url": "/stockmoney/json_otc/triplerate_gross_cols.json"
  },
  {
    "revision": "463fb8434937ed2967aee506c3c1798d",
    "url": "/stockmoney/json_otc/triplerate_net.json"
  },
  {
    "revision": "cc1b7bfc745c16ad2d5a82bc30ac6459",
    "url": "/stockmoney/json_otc/triplerate_net_cols.json"
  },
  {
    "revision": "dab55d54eadf3979202c892c7de100b2",
    "url": "/stockmoney/json_otc/triplerate_opp.json"
  },
  {
    "revision": "a242562265859312dab0ae2024ad112c",
    "url": "/stockmoney/json_otc/triplerate_opp_cols.json"
  },
  {
    "revision": "bc23d5236d78e9dc73820b0bd288e602",
    "url": "/stockmoney/json_otc/year_eps.json"
  },
  {
    "revision": "715117352bfadb3b3e29af5b69690517",
    "url": "/stockmoney/json_otc/year_eps_cols.json"
  },
  {
    "revision": "d6b5adf5ff79cd2198a297c5d19ddf67",
    "url": "/stockmoney/json_otc/year_roe.json"
  },
  {
    "revision": "83295bc21b04c02556950838c0ffb858",
    "url": "/stockmoney/json_otc/year_roe_cols.json"
  },
  {
    "revision": "b96e0d5a5df171b63ae60164bac0e3af",
    "url": "/stockmoney/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/stockmoney/robots.txt"
  },
  {
    "revision": "01b3384e488c99aeff39",
    "url": "/stockmoney/static/css/app.62200570.css"
  },
  {
    "revision": "00a14ddebf3604813825",
    "url": "/stockmoney/static/css/chunk-vendors.eae4093c.css"
  },
  {
    "revision": "ecb3bfc03db10b6f9d6e23e710d5c953",
    "url": "/stockmoney/static/img/logo.ecb3bfc0.png"
  },
  {
    "revision": "85ce6e4334a2eeb8390e",
    "url": "/stockmoney/static/js/about.3644c617.js"
  },
  {
    "revision": "01b3384e488c99aeff39",
    "url": "/stockmoney/static/js/app.490fc55c.js"
  },
  {
    "revision": "00a14ddebf3604813825",
    "url": "/stockmoney/static/js/chunk-vendors.2d8e5b65.js"
  }
]);