self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8bb41dd16132f1e5fc75e82bfe96b1d3",
    "url": "/stockmoney/index.html"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json/.dummy"
  },
  {
    "revision": "9c9cdfe69dc6204d036a60bf2bb0c275",
    "url": "/stockmoney/json/basic_4season.json"
  },
  {
    "revision": "7b192e5d553d5006842b3df332653ab4",
    "url": "/stockmoney/json/basic_4season_cols.json"
  },
  {
    "revision": "7103f43903a66e636e491a7d0c941239",
    "url": "/stockmoney/json/basic_asset.json"
  },
  {
    "revision": "f1e74236d6ad6311f2b736c1662fb438",
    "url": "/stockmoney/json/basic_asset_cols.json"
  },
  {
    "revision": "5377d8be27834de90af348ad8abdcb2b",
    "url": "/stockmoney/json/basic_cash.json"
  },
  {
    "revision": "5248a9678d297cb99ea32474e7922b48",
    "url": "/stockmoney/json/basic_cash_cols.json"
  },
  {
    "revision": "2a323c2dcba25920a1c004ba08609d4f",
    "url": "/stockmoney/json/basic_debt.json"
  },
  {
    "revision": "eb3d811040821e36a36a43ff1e85abca",
    "url": "/stockmoney/json/basic_debt_cols.json"
  },
  {
    "revision": "22baafb2c456d291def0a274537755aa",
    "url": "/stockmoney/json/basic_eps.json"
  },
  {
    "revision": "2e29a140cecd7d5b5edf9639d83ed46b",
    "url": "/stockmoney/json/basic_eps_cols.json"
  },
  {
    "revision": "b5ce510219c476e09dca27da109066f8",
    "url": "/stockmoney/json/basic_gross.json"
  },
  {
    "revision": "ea6f6f52795a745e3ec28dc36eec97a5",
    "url": "/stockmoney/json/basic_gross_cols.json"
  },
  {
    "revision": "7892d6077422ae629c5b52e1c8fee101",
    "url": "/stockmoney/json/basic_info.json"
  },
  {
    "revision": "4a01d4330b10e31c6048acfe2d9dde98",
    "url": "/stockmoney/json/basic_info_cols.json"
  },
  {
    "revision": "673a09205982e055c1e5fb683d1c4a3e",
    "url": "/stockmoney/json/basic_net.json"
  },
  {
    "revision": "8d0543a639010808891dfc78397c83ce",
    "url": "/stockmoney/json/basic_net_cols.json"
  },
  {
    "revision": "33afc6d2a4cbcadac8cbac7e8371c613",
    "url": "/stockmoney/json/basic_noi.json"
  },
  {
    "revision": "923643fdb69cfa0a648e83789e855a5e",
    "url": "/stockmoney/json/basic_noi_cols.json"
  },
  {
    "revision": "1774e9f569758fb2977da831e8e34c64",
    "url": "/stockmoney/json/basic_opm.json"
  },
  {
    "revision": "fcedac2c0bf6fbe4ad382b12326c518e",
    "url": "/stockmoney/json/basic_opm_cols.json"
  },
  {
    "revision": "88846ef857f41137f724d33f16785051",
    "url": "/stockmoney/json/basic_opp.json"
  },
  {
    "revision": "2082811c9742a2cb6e122f3b289d72aa",
    "url": "/stockmoney/json/basic_opp_cols.json"
  },
  {
    "revision": "5fc00067fac386d148574b356f690597",
    "url": "/stockmoney/json/basic_roe.json"
  },
  {
    "revision": "b70080b5307d758e14c77896c42c3221",
    "url": "/stockmoney/json/basic_roe_cols.json"
  },
  {
    "revision": "0ba97b5a8f5c2fb9b89561f1baaba696",
    "url": "/stockmoney/json/basic_rvn.json"
  },
  {
    "revision": "c808ae75f2768124febc9177d26d5b68",
    "url": "/stockmoney/json/basic_rvn_cols.json"
  },
  {
    "revision": "c2b82ced5f3871676c23dcffe325d4c8",
    "url": "/stockmoney/json/basic_yearw.json"
  },
  {
    "revision": "930e467bf0315b27559e2cc6f97bd4d8",
    "url": "/stockmoney/json/basic_yearw_cols.json"
  },
  {
    "revision": "d92d7bfafa42ca12efe324c48679ebc3",
    "url": "/stockmoney/json/chip_borrow.json"
  },
  {
    "revision": "b9d898714914df8c330d1f25fd728bd4",
    "url": "/stockmoney/json/chip_borrow_cols.json"
  },
  {
    "revision": "761ebba7919d00e589957f4ebc14b8d2",
    "url": "/stockmoney/json/chip_director.json"
  },
  {
    "revision": "bfde5899424524993a8bec60fcb1551a",
    "url": "/stockmoney/json/chip_director1.json"
  },
  {
    "revision": "9245b933efe32254018a0a6e9a6c8613",
    "url": "/stockmoney/json/chip_director1_cols.json"
  },
  {
    "revision": "0ac9eca5443dfb19fe855d41f2e38e13",
    "url": "/stockmoney/json/chip_director3.json"
  },
  {
    "revision": "b856d752ee7572bba69b5bfefbe9e41b",
    "url": "/stockmoney/json/chip_director3_cols.json"
  },
  {
    "revision": "7a731bfc57fd25447451108bef3ce549",
    "url": "/stockmoney/json/chip_director5.json"
  },
  {
    "revision": "825ba91683006403a96e4ead7ebc2e2c",
    "url": "/stockmoney/json/chip_director5_cols.json"
  },
  {
    "revision": "9bbbf6600d4c03482470ae7a8ed48118",
    "url": "/stockmoney/json/chip_director_cols.json"
  },
  {
    "revision": "13c0bea704296a5c5fcdca2acf4ff011",
    "url": "/stockmoney/json/chip_foreign.json"
  },
  {
    "revision": "1f66416e66912403af00c4d2366c2741",
    "url": "/stockmoney/json/chip_foreign_cols.json"
  },
  {
    "revision": "48efdcce7490270b31d8ea29fe6323da",
    "url": "/stockmoney/json/chip_holder.json"
  },
  {
    "revision": "672717b58db691e5c491065fd3720da4",
    "url": "/stockmoney/json/chip_holder_cols.json"
  },
  {
    "revision": "f5a8a5ff549d8533e75bb39789cd2b4a",
    "url": "/stockmoney/json/chip_legal.json"
  },
  {
    "revision": "60a82514c04d8b46e234b6c3b7db8a4c",
    "url": "/stockmoney/json/chip_legal_cols.json"
  },
  {
    "revision": "c1afb05a9ddff04015eb9a17cf4c4f7d",
    "url": "/stockmoney/json/chip_loan.json"
  },
  {
    "revision": "f9dc3e02b8b829e17677de08ed985401",
    "url": "/stockmoney/json/chip_loan_cols.json"
  },
  {
    "revision": "3d96268b284f0e3e51941678d3ff5a32",
    "url": "/stockmoney/json/chip_trust.json"
  },
  {
    "revision": "0453c094ec1578d8b609550d9e477938",
    "url": "/stockmoney/json/chip_trust_cols.json"
  },
  {
    "revision": "c9e0357cce0afff38244b255a1ef3158",
    "url": "/stockmoney/json/deal_pct.json"
  },
  {
    "revision": "d5083fa9f7aed5854754ba6a5578fd7e",
    "url": "/stockmoney/json/deal_pct_cols.json"
  },
  {
    "revision": "80d123057a270eeba17be1eb3bf23019",
    "url": "/stockmoney/json/deal_vol.json"
  },
  {
    "revision": "e42c29acc4d6f30eaee01e7b17d21a04",
    "url": "/stockmoney/json/deal_vol_cols.json"
  },
  {
    "revision": "2eef8a30ba83374bc1a5b6cb676f2cf0",
    "url": "/stockmoney/json/dividend_cont.json"
  },
  {
    "revision": "3e8dc99836816cdedc952a126db1fa79",
    "url": "/stockmoney/json/dividend_cont_cols.json"
  },
  {
    "revision": "45b7228e78922343219dea67c5cda6b9",
    "url": "/stockmoney/json/dividend_stat.json"
  },
  {
    "revision": "c4cb9b49f43085a71a38a80d908cf2e1",
    "url": "/stockmoney/json/dividend_stat_2015.json"
  },
  {
    "revision": "008c79d526737b517a9a742b04502b20",
    "url": "/stockmoney/json/dividend_stat_2015_cols.json"
  },
  {
    "revision": "a19a6c3403a930edc7bd8e3668de036c",
    "url": "/stockmoney/json/dividend_stat_2016.json"
  },
  {
    "revision": "ec5a0a94673998b0bb4a63db93d08f4a",
    "url": "/stockmoney/json/dividend_stat_2016_cols.json"
  },
  {
    "revision": "2985d3399bd88de19e142bd52d482d4b",
    "url": "/stockmoney/json/dividend_stat_2017.json"
  },
  {
    "revision": "e37fc91cd72912b24657ed675d9f1c8b",
    "url": "/stockmoney/json/dividend_stat_2017_cols.json"
  },
  {
    "revision": "582ce2b58ed27616f7d3ed23b67cdee3",
    "url": "/stockmoney/json/dividend_stat_2018.json"
  },
  {
    "revision": "38050d84b8d337ce366fb397e8e206f7",
    "url": "/stockmoney/json/dividend_stat_2018_cols.json"
  },
  {
    "revision": "905fb3943b2d90b988cce20280f30c80",
    "url": "/stockmoney/json/dividend_stat_2019.json"
  },
  {
    "revision": "7ec66cdc30aa0d150bc4f797bdc131c4",
    "url": "/stockmoney/json/dividend_stat_2019_cols.json"
  },
  {
    "revision": "b97aef59a414fad0f6a4c2169005b66e",
    "url": "/stockmoney/json/dividend_stat_cols.json"
  },
  {
    "revision": "ca55922294232375f9d584be69da8c9c",
    "url": "/stockmoney/json/dividend_yield.json"
  },
  {
    "revision": "5bb9b10a808adb5442ae9a630e810111",
    "url": "/stockmoney/json/dividend_yield_cols.json"
  },
  {
    "revision": "4953ce6189d71520097670d4810ec955",
    "url": "/stockmoney/json/dk_dies.json"
  },
  {
    "revision": "0842de8223abec6d0d02135b89168710",
    "url": "/stockmoney/json/dk_dies_cols.json"
  },
  {
    "revision": "8063ed9901313ded7d7c8dea0fd176d7",
    "url": "/stockmoney/json/export_director.json"
  },
  {
    "revision": "89100efeca7bfb4d95efdab07df62a48",
    "url": "/stockmoney/json/export_director_cols.json"
  },
  {
    "revision": "02c24c6ce3cd0df05756e12ccf3bf231",
    "url": "/stockmoney/json/export_incomerate.json"
  },
  {
    "revision": "8a782513b99c4e31cf07aca4745c38e4",
    "url": "/stockmoney/json/export_incomerate_cols.json"
  },
  {
    "revision": "0eee7287dfe111c612beaa7daf07b30a",
    "url": "/stockmoney/json/export_stockfish.json"
  },
  {
    "revision": "24c365c317bd950273a6bbe79b14d791",
    "url": "/stockmoney/json/export_stockfish_cols.json"
  },
  {
    "revision": "cce24fde90d6b677114efcc1241d2ae4",
    "url": "/stockmoney/json/export_triplerate.json"
  },
  {
    "revision": "29e0c2731cf0823c503af4580b581346",
    "url": "/stockmoney/json/export_triplerate_cols.json"
  },
  {
    "revision": "6dabdd7ac0cf633bb50e01ca123d6822",
    "url": "/stockmoney/json/export_water.json"
  },
  {
    "revision": "1743dc326779ed0d0955118930c2fdc1",
    "url": "/stockmoney/json/export_water_cols.json"
  },
  {
    "revision": "388088f6f9559509d1beb37c09e9be80",
    "url": "/stockmoney/json/export_yield.json"
  },
  {
    "revision": "a8d642b8c2af03945412d130e7d18879",
    "url": "/stockmoney/json/export_yield_cols.json"
  },
  {
    "revision": "3b2b7c7afc62c32f10dd9d16c5e9580e",
    "url": "/stockmoney/json/my_basic.json"
  },
  {
    "revision": "5965e41c60b44c0344792bc7fcc8b5e3",
    "url": "/stockmoney/json/my_basic_cols.json"
  },
  {
    "revision": "927ea32d4a7b84367c02e66a441b4c06",
    "url": "/stockmoney/json/my_chip.json"
  },
  {
    "revision": "d7d8c9d66110686693e80e92aadcbdf1",
    "url": "/stockmoney/json/my_chip_cols.json"
  },
  {
    "revision": "5764f236b1f089db9a672237e2782c57",
    "url": "/stockmoney/json/my_eps.json"
  },
  {
    "revision": "87b98bb7ccff2628d43fe83db7362e93",
    "url": "/stockmoney/json/my_eps_cols.json"
  },
  {
    "revision": "101a8bf7bf9260be92bb39f7875374dd",
    "url": "/stockmoney/json/my_tech.json"
  },
  {
    "revision": "a5bb3253dc713d9680b919b48959022c",
    "url": "/stockmoney/json/my_tech_cols.json"
  },
  {
    "revision": "259dafaaee4e0f1c7b4bcc2f8a89cd64",
    "url": "/stockmoney/json/price_dpct.json"
  },
  {
    "revision": "111c1063358cf2cce62d1c4c3cf2a601",
    "url": "/stockmoney/json/price_dpct_cols.json"
  },
  {
    "revision": "b0922091bd7af5e149130b5de308481b",
    "url": "/stockmoney/json/price_high.json"
  },
  {
    "revision": "8f986523f915cd6a9dae0cd5f54f5d7f",
    "url": "/stockmoney/json/price_high_cols.json"
  },
  {
    "revision": "6b2d9db9519c5b1c1548a026919ebde6",
    "url": "/stockmoney/json/price_mpct.json"
  },
  {
    "revision": "19f8b091eacff631ac486f7a35596c56",
    "url": "/stockmoney/json/price_mpct_cols.json"
  },
  {
    "revision": "8063698f2eaae8643caedf8b13127d12",
    "url": "/stockmoney/json/price_wpct.json"
  },
  {
    "revision": "06e2f207dffd568d93360a54eff1629d",
    "url": "/stockmoney/json/price_wpct_cols.json"
  },
  {
    "revision": "a43494e183b6a79002d8ae4c4b270bc0",
    "url": "/stockmoney/json/tech_bch.json"
  },
  {
    "revision": "56d227c0fc6a9c5a25f2502cc26148ab",
    "url": "/stockmoney/json/tech_bch_cols.json"
  },
  {
    "revision": "3e1b9c4f13cdabea2c2b4a08c6da8cfa",
    "url": "/stockmoney/json/tech_beta.json"
  },
  {
    "revision": "8f09f6a30643cd54d5275425bea06c52",
    "url": "/stockmoney/json/tech_beta_cols.json"
  },
  {
    "revision": "5c80de4aa6085122a49ad160b87c9630",
    "url": "/stockmoney/json/tech_kd.json"
  },
  {
    "revision": "bc98c089d8c1e354c969654f84b61f56",
    "url": "/stockmoney/json/tech_kd_cols.json"
  },
  {
    "revision": "be53691d38ab63e836d39e00dff42f7d",
    "url": "/stockmoney/json/tech_ma.json"
  },
  {
    "revision": "5c125157702e4475325fc62420500833",
    "url": "/stockmoney/json/tech_ma_cols.json"
  },
  {
    "revision": "8f50ed29273ba1e935770f247129ced8",
    "url": "/stockmoney/json/triplerate_gross.json"
  },
  {
    "revision": "4bc9ab27f448d70d4828108cb64339b3",
    "url": "/stockmoney/json/triplerate_gross_cols.json"
  },
  {
    "revision": "fcb0a0c1e191c2696fa1258c1ce04629",
    "url": "/stockmoney/json/triplerate_net.json"
  },
  {
    "revision": "1c286965a413416277d8374332793187",
    "url": "/stockmoney/json/triplerate_net_cols.json"
  },
  {
    "revision": "5022b53c63116860e255a642eb4718c7",
    "url": "/stockmoney/json/triplerate_opp.json"
  },
  {
    "revision": "187f6dad1b5fecaa3c6469f20389bcb3",
    "url": "/stockmoney/json/triplerate_opp_cols.json"
  },
  {
    "revision": "975ee5d92bbb5de5e9b012065bb3e474",
    "url": "/stockmoney/json/year_eps.json"
  },
  {
    "revision": "af1fe609547ebeda2393758c62fa4312",
    "url": "/stockmoney/json/year_eps_cols.json"
  },
  {
    "revision": "3e5cddb4fd16e1e0cee4d52f26c5df62",
    "url": "/stockmoney/json/year_roe.json"
  },
  {
    "revision": "b5fcb82eea34f1f5695bc8bb1c721730",
    "url": "/stockmoney/json/year_roe_cols.json"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/stockmoney/json_otc/.dummy"
  },
  {
    "revision": "cf7e920f2b2187947799ae926ab8bb9f",
    "url": "/stockmoney/json_otc/basic_4season.json"
  },
  {
    "revision": "5af8e03d5ac2fd4ca03652dd2b98f6f0",
    "url": "/stockmoney/json_otc/basic_4season_cols.json"
  },
  {
    "revision": "af17db0e83c7e121194cd0f005f7b413",
    "url": "/stockmoney/json_otc/basic_asset.json"
  },
  {
    "revision": "b38212d12f678a74ad6a6565339df931",
    "url": "/stockmoney/json_otc/basic_asset_cols.json"
  },
  {
    "revision": "a484195ca5f515a857e1f9f35e1e6b96",
    "url": "/stockmoney/json_otc/basic_cash.json"
  },
  {
    "revision": "357f7a927f70253c924fb727df1b388a",
    "url": "/stockmoney/json_otc/basic_cash_cols.json"
  },
  {
    "revision": "8def521160ff5eb9f56130e013c2d1f5",
    "url": "/stockmoney/json_otc/basic_debt.json"
  },
  {
    "revision": "c972a7abb6ef4c454e9215f1124405b7",
    "url": "/stockmoney/json_otc/basic_debt_cols.json"
  },
  {
    "revision": "093b7575a256461efbbcb23ffbd0fea7",
    "url": "/stockmoney/json_otc/basic_eps.json"
  },
  {
    "revision": "98aa6bc11850757453b5a7abd890e9ef",
    "url": "/stockmoney/json_otc/basic_eps_cols.json"
  },
  {
    "revision": "107fa94908ad4a8ba9e8e4e4c7c31905",
    "url": "/stockmoney/json_otc/basic_gross.json"
  },
  {
    "revision": "c062f9170060f083e7f9d17df187359d",
    "url": "/stockmoney/json_otc/basic_gross_cols.json"
  },
  {
    "revision": "a85f507b9bb2ea37bba98ac7bfbd7d7e",
    "url": "/stockmoney/json_otc/basic_info.json"
  },
  {
    "revision": "6f99a8a60e35b64e93e4e87ccbc4e5dd",
    "url": "/stockmoney/json_otc/basic_info_cols.json"
  },
  {
    "revision": "f0a37d1e37c67093366a2a237e1c527e",
    "url": "/stockmoney/json_otc/basic_net.json"
  },
  {
    "revision": "31139ed997fa0d6964e1505ae3eb9070",
    "url": "/stockmoney/json_otc/basic_net_cols.json"
  },
  {
    "revision": "c568237728254e724f5f6be27a05879d",
    "url": "/stockmoney/json_otc/basic_noi.json"
  },
  {
    "revision": "1d819243a56a99ac6f761a7c9e99f464",
    "url": "/stockmoney/json_otc/basic_noi_cols.json"
  },
  {
    "revision": "91030c96a186999ce3c629e99acd4d8c",
    "url": "/stockmoney/json_otc/basic_opm.json"
  },
  {
    "revision": "c6a25a329bcadad7297ef83c5e7ca32d",
    "url": "/stockmoney/json_otc/basic_opm_cols.json"
  },
  {
    "revision": "d8d2c3c341d6fb071cce534767e3affb",
    "url": "/stockmoney/json_otc/basic_opp.json"
  },
  {
    "revision": "15898cf47a332f7bdc456e852da40c37",
    "url": "/stockmoney/json_otc/basic_opp_cols.json"
  },
  {
    "revision": "ef65716ab1a56e895c256b13276ec3f8",
    "url": "/stockmoney/json_otc/basic_roe.json"
  },
  {
    "revision": "14783737bcac6e9d1f53a6115f8195db",
    "url": "/stockmoney/json_otc/basic_roe_cols.json"
  },
  {
    "revision": "1f09b9914c32502c8c771f917bb9cead",
    "url": "/stockmoney/json_otc/basic_rvn.json"
  },
  {
    "revision": "27363f6d5a92d137ba78284acfe10e51",
    "url": "/stockmoney/json_otc/basic_rvn_cols.json"
  },
  {
    "revision": "41298eaa12ff49f3837e69ca8f690a64",
    "url": "/stockmoney/json_otc/basic_yearw.json"
  },
  {
    "revision": "37afed6bf332938bf457759590f15e20",
    "url": "/stockmoney/json_otc/basic_yearw_cols.json"
  },
  {
    "revision": "f6d34a06c1e612a43301f43dc352ab34",
    "url": "/stockmoney/json_otc/chip_borrow.json"
  },
  {
    "revision": "5a8bd57521f8a67e6f158eda3faacf21",
    "url": "/stockmoney/json_otc/chip_borrow_cols.json"
  },
  {
    "revision": "567e269ce77fdf0d9848f3956fd4aa82",
    "url": "/stockmoney/json_otc/chip_director.json"
  },
  {
    "revision": "daf8e9ea8496360a65445c20e2f69730",
    "url": "/stockmoney/json_otc/chip_director1.json"
  },
  {
    "revision": "8e7a0bacff28aa1cf9f5825c7712c937",
    "url": "/stockmoney/json_otc/chip_director1_cols.json"
  },
  {
    "revision": "a8d25e84eaabad2e1de4631cdc153eee",
    "url": "/stockmoney/json_otc/chip_director3.json"
  },
  {
    "revision": "cb725822bf310830ac86771e76bbf7e5",
    "url": "/stockmoney/json_otc/chip_director3_cols.json"
  },
  {
    "revision": "389148f0de1852bca9e7fc52169508cf",
    "url": "/stockmoney/json_otc/chip_director5.json"
  },
  {
    "revision": "9e1f67c918b55fd9c2153dc91b5ea992",
    "url": "/stockmoney/json_otc/chip_director5_cols.json"
  },
  {
    "revision": "79dce6a98cc61675f28207bb8ee66d68",
    "url": "/stockmoney/json_otc/chip_director_cols.json"
  },
  {
    "revision": "2c69cd91cdfd6677871d765028ffb484",
    "url": "/stockmoney/json_otc/chip_foreign.json"
  },
  {
    "revision": "e59f62dd4b9a788009bac352d7e91c12",
    "url": "/stockmoney/json_otc/chip_foreign_cols.json"
  },
  {
    "revision": "163f25fc3afd61fbef43334bccd74c3b",
    "url": "/stockmoney/json_otc/chip_holder.json"
  },
  {
    "revision": "0d80a0b66a710be5c8449613ed1abad2",
    "url": "/stockmoney/json_otc/chip_holder_cols.json"
  },
  {
    "revision": "a9a4d42f807061e3ad514aa16dfa42f0",
    "url": "/stockmoney/json_otc/chip_legal.json"
  },
  {
    "revision": "56a5a51151871b1624874a4fe5a82f83",
    "url": "/stockmoney/json_otc/chip_legal_cols.json"
  },
  {
    "revision": "9336d318f0bdd67f8fc9f99b7706a022",
    "url": "/stockmoney/json_otc/chip_loan.json"
  },
  {
    "revision": "ee402593614d4650e99e562d17e63538",
    "url": "/stockmoney/json_otc/chip_loan_cols.json"
  },
  {
    "revision": "41b6bf84b70f8b64c8d29fbe116138cd",
    "url": "/stockmoney/json_otc/chip_trust.json"
  },
  {
    "revision": "4466ee075166bd957824b4a6d6c6ddbe",
    "url": "/stockmoney/json_otc/chip_trust_cols.json"
  },
  {
    "revision": "4737a2cf3d8cd4592e995fc28b71bb0d",
    "url": "/stockmoney/json_otc/deal_pct.json"
  },
  {
    "revision": "6aa4eed51cba9dc1dc746762256d9659",
    "url": "/stockmoney/json_otc/deal_pct_cols.json"
  },
  {
    "revision": "5f4fbe2fbe9430b01a44c668c02e3810",
    "url": "/stockmoney/json_otc/deal_vol.json"
  },
  {
    "revision": "b27cd4bd88359e51326cd3dab8215f69",
    "url": "/stockmoney/json_otc/deal_vol_cols.json"
  },
  {
    "revision": "c2e976e711599ad03a8bca19aedcf754",
    "url": "/stockmoney/json_otc/dividend_cont.json"
  },
  {
    "revision": "d770b65af07d9d64a25e81b34c57086f",
    "url": "/stockmoney/json_otc/dividend_cont_cols.json"
  },
  {
    "revision": "45eb4ddfcb724b2cd82a5f51f9c1e0e1",
    "url": "/stockmoney/json_otc/dividend_stat.json"
  },
  {
    "revision": "a6fb375370d4c97ddef59b6d46945ee4",
    "url": "/stockmoney/json_otc/dividend_stat_2015.json"
  },
  {
    "revision": "cbec2feb676f6a6aa3b239e88e6d6a2c",
    "url": "/stockmoney/json_otc/dividend_stat_2015_cols.json"
  },
  {
    "revision": "31454e7d003dfc9ef1236f5fbb5ef53c",
    "url": "/stockmoney/json_otc/dividend_stat_2016.json"
  },
  {
    "revision": "6e18d58a36f9fc2a33f01cedfe00600b",
    "url": "/stockmoney/json_otc/dividend_stat_2016_cols.json"
  },
  {
    "revision": "2ae6b69cd4ca96eee2bfc7ed73e79a55",
    "url": "/stockmoney/json_otc/dividend_stat_2017.json"
  },
  {
    "revision": "297d5aebd0f10fcde9bb1a0e4ac5182e",
    "url": "/stockmoney/json_otc/dividend_stat_2017_cols.json"
  },
  {
    "revision": "284de5e09d4655ae3c02960833408889",
    "url": "/stockmoney/json_otc/dividend_stat_2018.json"
  },
  {
    "revision": "260b5376813e3734a06dab71d8b9bd8a",
    "url": "/stockmoney/json_otc/dividend_stat_2018_cols.json"
  },
  {
    "revision": "9f8dddf713fb0971c6be827408a676f6",
    "url": "/stockmoney/json_otc/dividend_stat_2019.json"
  },
  {
    "revision": "6050c49dcd02fe1bf54be9c00f3014eb",
    "url": "/stockmoney/json_otc/dividend_stat_2019_cols.json"
  },
  {
    "revision": "9b4c4be9545c11e770cbe8be386f94cb",
    "url": "/stockmoney/json_otc/dividend_stat_cols.json"
  },
  {
    "revision": "7eebcc05bdabb6fc774762b2c5235c7d",
    "url": "/stockmoney/json_otc/dividend_yield.json"
  },
  {
    "revision": "ecb2998fde71d849b8992a7b6c4e2e3d",
    "url": "/stockmoney/json_otc/dividend_yield_cols.json"
  },
  {
    "revision": "7070d461fca9f57f911b200dd2fc5bd8",
    "url": "/stockmoney/json_otc/export_director.json"
  },
  {
    "revision": "dc52c2befa171fe92e40ed06676523e8",
    "url": "/stockmoney/json_otc/export_director_cols.json"
  },
  {
    "revision": "bf4091968a9416ed62033f7746eeee19",
    "url": "/stockmoney/json_otc/export_incomerate.json"
  },
  {
    "revision": "2116156f68a32ef6181f50b61bd79ad3",
    "url": "/stockmoney/json_otc/export_incomerate_cols.json"
  },
  {
    "revision": "cd31b8a4e6ae79c8381334b713671557",
    "url": "/stockmoney/json_otc/export_stockfish.json"
  },
  {
    "revision": "192fef50d1b0b739db62b78e28521927",
    "url": "/stockmoney/json_otc/export_stockfish_cols.json"
  },
  {
    "revision": "06644a4d0d24006b9520f689110d209f",
    "url": "/stockmoney/json_otc/export_triplerate.json"
  },
  {
    "revision": "a625f25eee5bf1c3f165bc86c455ce79",
    "url": "/stockmoney/json_otc/export_triplerate_cols.json"
  },
  {
    "revision": "962233c053e6db9fe7b8fc8ba435e819",
    "url": "/stockmoney/json_otc/export_water.json"
  },
  {
    "revision": "1bf6d50b53aedc747b686d0267663d32",
    "url": "/stockmoney/json_otc/export_water_cols.json"
  },
  {
    "revision": "c55c440719a695161addc6d1fe124f60",
    "url": "/stockmoney/json_otc/export_yield.json"
  },
  {
    "revision": "49e7cdd201cc3d5a6cd680c3a5aa3c7f",
    "url": "/stockmoney/json_otc/my_basic.json"
  },
  {
    "revision": "12af128c5c8cb61ac4c2042aefe1f0cf",
    "url": "/stockmoney/json_otc/my_eps.json"
  },
  {
    "revision": "ee41870e2a556afa1b4a4cb967744e6d",
    "url": "/stockmoney/json_otc/my_eps_cols.json"
  },
  {
    "revision": "630a88ee7de82296146eff468a8c49f7",
    "url": "/stockmoney/json_otc/price_dpct.json"
  },
  {
    "revision": "4a8550ef29380c4fa8d8ac437919bf01",
    "url": "/stockmoney/json_otc/price_dpct_cols.json"
  },
  {
    "revision": "231a3a34d812a983405557e28e479989",
    "url": "/stockmoney/json_otc/price_mpct.json"
  },
  {
    "revision": "f49e4c8c592ee192541945e62871c3d3",
    "url": "/stockmoney/json_otc/price_mpct_cols.json"
  },
  {
    "revision": "9c2a706f086b65764e7286716ae62c0f",
    "url": "/stockmoney/json_otc/price_wpct.json"
  },
  {
    "revision": "5274839ff9361763e75b70bb12e266d6",
    "url": "/stockmoney/json_otc/price_wpct_cols.json"
  },
  {
    "revision": "6a3af37bb57d9abe72d779f03fe2ad61",
    "url": "/stockmoney/json_otc/tech_bch.json"
  },
  {
    "revision": "1f3501a7241684346326f6b20fef29ab",
    "url": "/stockmoney/json_otc/tech_bch_cols.json"
  },
  {
    "revision": "62198142da2ae2f1c4f18bbd98e59c79",
    "url": "/stockmoney/json_otc/tech_beta.json"
  },
  {
    "revision": "1d1993c61608814513697231793da5ff",
    "url": "/stockmoney/json_otc/tech_beta_cols.json"
  },
  {
    "revision": "faaf11845682fb2d1176b7e5618159e6",
    "url": "/stockmoney/json_otc/tech_kd.json"
  },
  {
    "revision": "4f5d6ca8656dd449a555f2892c29746e",
    "url": "/stockmoney/json_otc/tech_kd_cols.json"
  },
  {
    "revision": "65f85b9cea1e4e6b027f201505a46ae1",
    "url": "/stockmoney/json_otc/tech_ma.json"
  },
  {
    "revision": "d6c2c2c917b71f3b85765373cb229222",
    "url": "/stockmoney/json_otc/tech_ma_cols.json"
  },
  {
    "revision": "c14bd0958e3d029b7dd08b5cec432f3e",
    "url": "/stockmoney/json_otc/triplerate_gross.json"
  },
  {
    "revision": "f9a7eac36d4043f5656740b2624ccc55",
    "url": "/stockmoney/json_otc/triplerate_gross_cols.json"
  },
  {
    "revision": "43d39555eb3a1cf9d5ba12714246b91f",
    "url": "/stockmoney/json_otc/triplerate_net.json"
  },
  {
    "revision": "98faf05c8ac645b6ba17ab4b06d4b699",
    "url": "/stockmoney/json_otc/triplerate_net_cols.json"
  },
  {
    "revision": "5f18e2d3bdf82a1b448def5315054f65",
    "url": "/stockmoney/json_otc/triplerate_opp.json"
  },
  {
    "revision": "f82401c5ee92fdc3aabf57829c7a7097",
    "url": "/stockmoney/json_otc/triplerate_opp_cols.json"
  },
  {
    "revision": "d677faf672a25c5e63bf714adba247fa",
    "url": "/stockmoney/json_otc/year_eps.json"
  },
  {
    "revision": "357ab3f83729897ad75c09a30018dcad",
    "url": "/stockmoney/json_otc/year_eps_cols.json"
  },
  {
    "revision": "6c8e7bc656fca0e6f4b26302f300a944",
    "url": "/stockmoney/json_otc/year_roe.json"
  },
  {
    "revision": "8424c799618c180d215cbc433303cdd8",
    "url": "/stockmoney/json_otc/year_roe_cols.json"
  },
  {
    "revision": "b96e0d5a5df171b63ae60164bac0e3af",
    "url": "/stockmoney/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/stockmoney/robots.txt"
  },
  {
    "revision": "b7a6407109414ba50899",
    "url": "/stockmoney/static/css/app.70e1ff39.css"
  },
  {
    "revision": "a7bd39673262647df6da",
    "url": "/stockmoney/static/css/chunk-vendors.eae4093c.css"
  },
  {
    "revision": "ecb3bfc03db10b6f9d6e23e710d5c953",
    "url": "/stockmoney/static/img/logo.ecb3bfc0.png"
  },
  {
    "revision": "658800e4ddcdedaaa231",
    "url": "/stockmoney/static/js/about.6cc0e21f.js"
  },
  {
    "revision": "b7a6407109414ba50899",
    "url": "/stockmoney/static/js/app.7ef236d1.js"
  },
  {
    "revision": "a7bd39673262647df6da",
    "url": "/stockmoney/static/js/chunk-vendors.1f857820.js"
  }
]);